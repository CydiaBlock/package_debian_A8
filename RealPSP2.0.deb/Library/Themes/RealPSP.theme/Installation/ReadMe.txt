PSP Theme
-3.0 User uninstall Five Icon Dock
-Install Five Column Springboard, BlankNull and FiveIRows
-Install Springjumps, Categories and iBlank
-Activate Page 0-4 in Springjumps
-SSH your iPhone/iPod and copy the content of the Jumps folder to your Applications folder
-Create "Games" and "Apps" with Categories
-Put all your games in the Games folder
-Put all your apps in the Apps folder without App Store, Apps, BossPrefs, Calculator, Chat Program (Nimbuzz, Skype, IM+), Clock, Contacts, Cydia, Finder, Games, iPod, iTunes, Mail, Maps, Notes, Photos, Safari, Settings, Stocks, Terminal, Weather, Winterboard and YouTube (You don�t must have all of them)
-Create 85 blanks with iBlank
-Sort the Icons like on the Pictures
-For the Statusbar follow this instruction 
http://touch-mania.com/2009/01/05/tutorial-springboard-im-querformat/ (german)
http://www.ipodtouchfans.com/forums/showthread.php?t=127008&highlight=landscape+status+bar (english)