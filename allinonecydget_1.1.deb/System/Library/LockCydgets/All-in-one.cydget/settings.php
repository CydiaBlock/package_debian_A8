<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>
<br>
<br>All-in-one Version 1.1
<br>"All-in-one" is built by Macusercom
<br><a href="faq.php"><font size="4">FAQ</font></a>
<br><a href="contact.php"><font size="4">Contact (please read FAQ first)</font></a>
<br>&copy;2009-2010 by Macusercom

</CENTER>
</body>
</html>

