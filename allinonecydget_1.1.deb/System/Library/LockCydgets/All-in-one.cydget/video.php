<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>

<a href="javascript:history.back()"onMouseOver="window.status='Zurück';return true;" onMouseOut="window.status=''"><font color="white"><font size="6">&laquo;Back</font></font></a> 

<table><tr><td>

<a href="youtube.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/youtube.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Youtube</font></font></CENTER>

<br>



<br>


<br>

</td>


<td width="5px"></td>


<td>

<a href="myvideo.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/myvideo.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">MyVideo</font></font></CENTER>

<br>




<br>

<br>

</td>

<td width="5px"></td>


<td>

<a href="clipfish.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/clipfish.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Clipfish</font></font></CENTER>

<br>



<br>


<br>

</td>


<td width="5px"></td>


<td>

<div style="width:60px"></div>

<br>



<br>


<br>

</td></tr></table>
</CENTER>
</body>
</html>
