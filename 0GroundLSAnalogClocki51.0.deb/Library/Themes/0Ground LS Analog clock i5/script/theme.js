/****************************
*	  Basic_theme	    *
*   Version 2.0 05.08.2012  *
*     created by oldster    *
*    http://itheming.de/    *
****************************/
var obj = {error:false, errorString:null};

function updateDisplay() {

document.getElementById("status").innerHTML = "updateDisplay";	
// weather
	document.getElementById("city").innerHTML =obj.city;
	document.getElementById("temp").innerHTML = obj.temp + "°";	
	document.getElementById("icon").src="icon/"+obj.icon+".png";





if(language !="en") 
document.getElementById("description").innerHTML = weatherNow[obj.icon];
else document.getElementById("description").innerHTML = obj.description;
	

	
	    
	
	
	// forecast
	document.getElementById("Today").innerHTML = ForecastDayNames(obj.Today);
	document.getElementById("TodayLo").innerHTML = obj.TodayLo + "°" + "/";
	document.getElementById("TodayHi").innerHTML = obj.TodayHi + "°";
	document.getElementById("TodayCode").src="icon/"+obj.TodayCode+".png";
	document.getElementById("Day1").innerHTML = ForecastDayNames(obj.Day1);
	document.getElementById("Day1Lo").innerHTML = obj.Day1Lo + "°" + "/";
	document.getElementById("Day1Hi").innerHTML = obj.Day1Hi + "°";
	document.getElementById("Day1Code").src="icon/"+obj.Day1Code+".png";
	document.getElementById("Day2").innerHTML = ForecastDayNames(obj.Day2);
	document.getElementById("Day2Lo").innerHTML = obj.Day2Lo + "°" + "/";
	document.getElementById("Day2Hi").innerHTML = obj.Day2Hi + "°";
	document.getElementById("Day2Code").src="icon/"+obj.Day2Code+".png";
	document.getElementById("Day3").innerHTML = ForecastDayNames(obj.Day3);
	document.getElementById("Day3Lo").innerHTML = obj.Day2Lo + "°" + "/";
	document.getElementById("Day3Hi").innerHTML = obj.Day2Hi + "°";
	document.getElementById("Day3Code").src="icon/"+obj.Day3Code+".png";
	document.getElementById("Day4").innerHTML = ForecastDayNames(obj.Day4);
	document.getElementById("Day4Lo").innerHTML = obj.Day2Lo + "°" + "/";
	document.getElementById("Day4Hi").innerHTML = obj.Day2Hi + "°";
	document.getElementById("Day4Code").src="icon/"+obj.Day4Code+".png";
	
	
	　
}

setInterval( function time() {
document.getElementById("status").innerHTML = "function time";
if(gps_weather) read_myLocation_txt();

var date = new Date().getDate();
var day = new Date().getDay();
var month = new Date().getMonth();
var year = new Date().getFullYear();
var mins = new Date().getMinutes();
var hours = new Date().getHours();
var am_pm	 = "";


if(language == "en") {
document.getElementById("calendar").innerHTML= this_weekday_name_array[day] + ", " + 
this_month_name_array[month]+ " " +	this_date_name_array[date];
document.getElementById("year").innerHTML= year;
}
else {
document.getElementById("calendar").innerHTML= this_weekday_name_array[day] + ", " + 
this_date_name_array[date] + " " + this_month_name_array[month];
document.getElementById("year").innerHTML= year;
}
	
	mins = ( mins < 10 ? "0" : "" ) + mins;

	hours = ( hours < 10 ? "0" : "" ) + hours;


	if(hour24)document.getElementById("digiclock").innerHTML= hours + ":" + mins ;

	else {

		am_pm = ( hours < 12 ) ? "AM" : "PM";

		hours = ( hours > 12 ) ? hours - 12 : hours;

		hours = ( hours == 0 ) ? 12 : hours;

		document.getElementById('digiclock').innerHTML  = hours + ":" + mins + "<font size='2'>" + am_pm + "</font>";		

	}
	
	
	
	var currentTime = new Date ();
	if (locale != woeid && woeid != "") {
	  locale = woeid;
	  readWeather();    
	}
	if (lastWeather == 0){
	  readWeather();
	  lastWeather = currentTime.getTime();
	}
	else{
	  if (currentTime.getTime() - lastWeather >= nextWeather){
	    lastWeather = currentTime.getTime();
		readWeather();
	  }
	}	
		
	}, 1000 );
	
/****************************
*      classic weather	    *
*	  by oldster	    *
*   Version 1.0 31.05.2012  *
*    http://itheming.de/    *
****************************/
var lastWeather = 0;
//var nextWeather = 15*60*1000;


function readWeather() {
	document.getElementById("status").innerHTML = "readWeather";
	url="http://weather.yahooapis.com/forecastrss?w="+locale+"&u="+weather_unit;
	// original source code from http://www.w3schools.com/ajax/ajax_xmlhttprequest_create.asp
	var xmlhttp;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else {// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}	
	xmlhttp.onreadystatechange=function() {
		if (xmlhttp.readyState==4 && xmlhttp.status == 200) {
		xmlDoc=xmlhttp.responseXML;
			writeWeather(xmlDoc);
		}
	}
	xmlhttp.overrideMimeType("text/xml");
	xmlhttp.open("GET",url,true);
	xmlhttp.send(null);
}

function writeWeather(xmlDoc) {
	document.getElementById("status").innerHTML = "writeWeather";
	var effectiveRoot = findChild(findChild(xmlDoc, "rss"), "channel");
	// make location id for weather forecast
	var yahoo_link	  = effectiveRoot.getElementsByTagName("link");
	var dummy	  = yahoo_link[0].childNodes[0].nodeValue;
	var dummy1	  = dummy.split('forecast/')[1];
	var dummy2	  = dummy1.split('_')[0];
	var loc_forecast  = dummy2;
	
	// The location of this forecast
	obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
	// Units for various aspects of the forecast
	obj.tempunit = findChild(effectiveRoot, "yweather:units").getAttribute("temperature");
	obj.visibilityunit = findChild(effectiveRoot, "yweather:units").getAttribute("distance");
	obj.pressureunit = findChild(effectiveRoot, "yweather:units").getAttribute("pressure");
	obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");
	// Forecast information about wind
	obj.chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
	obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
	obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");
	// Forecast information about current atmospheric pressure, humidity, and visibility
	obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");	  
	obj.visibility = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("visibility");
	obj.pressure = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("pressure");
	obj.rising = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("rising");
	// Forecast information about current astronomical conditions
	obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
	obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
	// The current weather conditions
	conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
	obj.description = conditionTag.getAttribute("text");
	obj.icon = conditionTag.getAttribute("code");	
	obj.temp = conditionTag.getAttribute("temp");
	obj.date = conditionTag.getAttribute("date");

	read4DaysWeather(loc_forecast); 
	
}
/* 
function findChild (element, nodeName)
{
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
       if (child.nodeName == nodeName)
		return child;
	}
	return null;
}
*/
function read4DaysWeather(loc_forecast) {
	document.getElementById("status").innerHTML = "read4DaysWeather";
	url="http://xml.weather.yahoo.com/forecastrss/"+loc_forecast+"&u="+weather_unit+"&d=5.xml";
	// original source code from http://www.w3schools.com/ajax/ajax_xmlhttprequest_create.asp
	var xml_request;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xml_request=new XMLHttpRequest();
	}
	else {// code for IE6, IE5
		xml_request=new ActiveXObject("Microsoft.XMLHTTP");
	}	
	xml_request.onreadystatechange=function() {
		if (xml_request.readyState==4 && xml_request.status == 200) {
		xmlDoc2=xml_request.responseXML;
			write4DaysWeather(xmlDoc2);
			
		}
	}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET",url,true);
	xml_request.send(null);
}

function write4DaysWeather(xmlDoc2) {
	document.getElementById("status").innerHTML = "write4DaysWeather";
	obj.Today = xmlDoc2.getElementsByTagName("forecast")[0].getAttribute("day");
	obj.TodayHi = xmlDoc2.getElementsByTagName("forecast")[0].getAttribute("high");
	obj.TodayLo = xmlDoc2.getElementsByTagName("forecast")[0].getAttribute("low");
	obj.TodayCode = xmlDoc2.getElementsByTagName("forecast")[0].getAttribute("code");

	obj.Day1 = xmlDoc2.getElementsByTagName("forecast")[1].getAttribute("day");
	obj.Day1Hi = xmlDoc2.getElementsByTagName("forecast")[1].getAttribute("high");
	obj.Day1Lo = xmlDoc2.getElementsByTagName("forecast")[1].getAttribute("low");
	obj.Day1Code = xmlDoc2.getElementsByTagName("forecast")[1].getAttribute("code");
	obj.Day1Date = xmlDoc2.getElementsByTagName("forecast")[1].getAttribute("date");
	
	obj.Day2 = xmlDoc2.getElementsByTagName("forecast")[2].getAttribute("day");
	obj.Day2Hi = xmlDoc2.getElementsByTagName("forecast")[2].getAttribute("high");
	obj.Day2Lo = xmlDoc2.getElementsByTagName("forecast")[2].getAttribute("low");
	obj.Day2Code = xmlDoc2.getElementsByTagName("forecast")[2].getAttribute("code");
	obj.Day2Date = xmlDoc2.getElementsByTagName("forecast")[2].getAttribute("date");

	obj.Day3 = xmlDoc2.getElementsByTagName("forecast")[3].getAttribute("day");
	obj.Day3Hi = xmlDoc2.getElementsByTagName("forecast")[3].getAttribute("high");
	obj.Day3Lo = xmlDoc2.getElementsByTagName("forecast")[3].getAttribute("low");
	obj.Day3Code = xmlDoc2.getElementsByTagName("forecast")[3].getAttribute("code");
	obj.Day3Date = xmlDoc2.getElementsByTagName("forecast")[3].getAttribute("date");

	obj.Day4 = xmlDoc2.getElementsByTagName("forecast")[4].getAttribute("day");
	obj.Day4Hi = xmlDoc2.getElementsByTagName("forecast")[4].getAttribute("high");
	obj.Day4Lo = xmlDoc2.getElementsByTagName("forecast")[4].getAttribute("low");
	obj.Day4Code = xmlDoc2.getElementsByTagName("forecast")[4].getAttribute("code");
	obj.Day4Date = xmlDoc2.getElementsByTagName("forecast")[4].getAttribute("date");

	updateDisplay();
}



function ForecastMonthNames(mon){
    switch (mon) {
	case "Mar": { return "Mär"}
	case "May": { return "Mai" }
	case "Oct": { return "Okt" }
	case "Dec": { return "Dez" }
}
    return mon;
}
function timeKorr(time){
	if(weather_unit == 'c') {
		var help = time.split(" ");
		if (help[1] == "pm") {
			h3 = help[0].split(":")[0]*1+12;
			h4 = help[0].split(":")[1];
			return h3 + ":" + h4;
		}
		else { return help[0];}
	}

}


/****************************
*	  gpsLocation	    *
*   Version 1.0 04.08.2012  *
*     created by oldster    *
*    http://itheming.de/    *
****************************/
var woeid = "";
var old_latitude = "";
var old_longitude = "";
	
function read_myLocation_txt() {
	document.getElementById("status").innerHTML = "read_myLocation_txt";
	// original source code from http://www.w3schools.com/ajax/ajax_xmlhttprequest_create.asp
	var xmlhttp = null;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else {// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}	
	xmlhttp.onreadystatechange=function() {
		if (xmlhttp.readyState==4 ) {
			var geolocation = xmlhttp.responseText;
			var latlong = geolocation.split(' ');
			var latitude=(latlong[0]).split('=')[1];
			var longitude=(latlong[1]).split('=')[1];
			if(latitude!=old_latitude || longitude!=old_longitude) {
				old_latitude=latitude;
				old_longitude=longitude;
				read_geoData(latitude,longitude);
			}
	}
	}
	xmlhttp.overrideMimeType("text/xml");
	//xmlhttp.open("GET",'myLocation.txt',true); // Demo Mode
	xmlhttp.open("GET",'../../../../var/mobile/Documents/myLocation.txt',true); 
	xmlhttp.send(null);
}


function read_geoData(latitude,longitude) {
	document.getElementById("status").innerHTML = "read_geoData";
	var url = 'http://query.yahooapis.com/v1/public/yql?q=select * from geo.placefinder where text="'+latitude+','+longitude+'" and gflags="R"';
	// original source code from http://www.w3schools.com/ajax/ajax_xmlhttprequest_create.asp
	var xmlhttp;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else {// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}	
	xmlhttp.onreadystatechange=function() {
		if (xmlhttp.readyState==4 && xmlhttp.status == 200) {
		xmlDoc=xmlhttp.responseXML;
			write_geoData(xmlDoc);
		}
	}
	xmlhttp.overrideMimeType("text/xml");
	xmlhttp.open("GET",url,true);
	xmlhttp.send(null);
}

function write_geoData(xmlDoc) {
	document.getElementById("status").innerHTML = "write_geoData";
	var effectiveRoot = findChild(findChild(findChild(xmlDoc, "query"), 'results'), 'Result');
//	obj.quality	  = resultElement(effectiveRoot.getElementsByTagName("quality"));
//	obj.latitude	  = resultElement(effectiveRoot.getElementsByTagName("latitude"));
//	obj.longitude	  = resultElement(effectiveRoot.getElementsByTagName("longitude"));
//	obj.radius	  = resultElement(effectiveRoot.getElementsByTagName("radius"));
//	obj.name	  = resultElement(effectiveRoot.getElementsByTagName("name"));
//	obj.line1	  = resultElement(effectiveRoot.getElementsByTagName("line1"));
//	obj.line2	  = resultElement(effectiveRoot.getElementsByTagName("line2"));
//	obj.line3	  = resultElement(effectiveRoot.getElementsByTagName("line3"));
//	obj.line4	  = resultElement(effectiveRoot.getElementsByTagName("line4"));
//	obj.house	  = resultElement(effectiveRoot.getElementsByTagName("house"));
//	obj.street	  = resultElement(effectiveRoot.getElementsByTagName("street"));
//	obj.postal	  = resultElement(effectiveRoot.getElementsByTagName("postal"));
//	obj.neighborhood  = resultElement(effectiveRoot.getElementsByTagName("neighborhood")); 
//	obj.city2	  = resultElement(effectiveRoot.getElementsByTagName("city"));
//	obj.county	  = resultElement(effectiveRoot.getElementsByTagName("county"));
//	obj.state	  = resultElement(effectiveRoot.getElementsByTagName("state"));
//	obj.country	  = resultElement(effectiveRoot.getElementsByTagName("country"));
//	obj.countrycode   = resultElement(effectiveRoot.getElementsByTagName("countrycode"));
//	obj.statecode	  = resultElement(effectiveRoot.getElementsByTagName("statecode"));
	obj.woeid	  = resultElement(effectiveRoot.getElementsByTagName("woeid"));
//	obj.woetype	  = resultElement(effectiveRoot.getElementsByTagName("woetype"));
//	obj.uzip	  = resultElement(effectiveRoot.getElementsByTagName("uzip")); 

	woeid = obj.woeid;
	
}

function findChild (element, nodeName)
{
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
       if (child.nodeName == nodeName)
		return child;
	}
	return null;
}

function resultElement(element) {
	var result = "no result";
	if(element[0].childNodes.length > 0) result = element[0].childNodes[0].nodeValue;
	return result;
}


