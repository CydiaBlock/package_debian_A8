/****************************
*     theme translation     *
*   Version 1.0 01.05.2013  *
*     created by oldster    *
*    http://itheming.de/    *
****************************/
switch (language) {
	case "en": { 
		var this_date_name_array = ["0", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th",
		"8th", "9th", "10th","11th", "12th", "13th", "14th", "15th", "16th", "17th", "18th", "19th",
		"20th","21st", "22nd", "23rd", "24th", "25th", "26th", "27th" ,"28th", "29th" ,"30th", "31st"]
		var this_weekday_name_array=["Sun","Mon","Tue","Wedn","Thu","Fri",
		"Sat"];
		var this_month_name_array=["January","February","March","April","May","June","July","August",
		"September","October","November","December"];
		var windDirection =['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW',
		'W', 'WNW', 'NW', 'NNW', 'N'];
		break;
	 }
	case "de": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		var this_weekday_name_array=["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag",	
		"Samstag"];
		var this_month_name_array=["Januar","Februar","M�rz","April","Mai","Juni","Juli","August",
		"September","Oktober","November","Dezember"];
		var weatherNow =["Tornado","Tropischer Sturm","Orkan","Heftiges Gewitter","Gewitter",
		"Regen und Schnee","Regen und Eisregen","Schnee und Eisregen","Gefrierender Nieselregen",
		"Nieselregen","Gefrierender Regen","Schauer","Schauer","Schneeschauer","Leichte Schneeschauer",
		"St�rmiger Schneefall","Schnee","Hagel","Eisregen","Staub","Neblig","Dunst","Staubig","St�rmisch",
		"Windig","Kalt","Bew&ouml;lkt","Gr&ouml;�tenteils bew&ouml;lkt","Gr&ouml;�tenteils bew&ouml;lkt","Teilweise bew&ouml;lkt",
		"Teilweise bew&ouml;lkt","Klar","Sonnig","Sch&ouml;n","Sch&ouml;n","Regen und Hagel","Hei�","Einzelne Gewitter",
		"Vereinzelte Gewitter","Vereinzelte Gewitter","Vereinzelte Schauer","Starker Schneefall",
		"Vereinzelte Schneeschauer","Starker Schneefall","Teilweise bew&ouml;lkt","Sp&auml;ter Schauer",
		"Schneeschauer","Einzelne Gewitterschauer","N/A"];
		var windDirection =['N', 'NNO', 'NO', 'ONO', 'O', 'OSO', 'SO', 'SSO', 'S', 'SSW', 'SW', 'WSW',
		'W', 'WNW', 'NW', 'NNW', 'N'];
		break;	
	}
	case "fr": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		var this_weekday_name_array=["dimanche","lundi","mardi","mercredi","jeudi","vendredi",	
		"samedi"];
		var this_month_name_array=["janvier","f�vrier","mars","avril","mai","juin","juillet","ao�t",
		"septembre","octobre","novembre","d�cembre"];
		var weatherNow =["Tornade","Orage Tropical","Ouragan","Orages","Orages","Pluie et Neige",
		"Pluie et Verglas","Neige et Verglas","Brouillard Vergla�ant","Pluie","Pluie Vergla�ante",
		"Averses","Averses","Bourrasques de neige","Petites chutes de neige","Chutes de neige - Vent",
		"Neige","Gr�le","Verglas","Non communiqu�","Brumeux","Brume","Non communiqu�","Non communiqu�",
		"Vent","Froid","Nuageux","Tr�s Nuageux","Nuageux","Passages nuageux","Passages nuageux",
		"Ciel Clair","Ensoleill�","Clair","Beau Temps","Pluie et Gr�le m�lang�es","Tr�s Chaud",
		"Passages nuageux avec orages","Orages et �claircies","Orages et �claircies",
		"Pluies et �claircies","Chute de neige importante","Petite chutes de neige",
		"Chute de neige importante","Partiellement couvert","Tonnerre","Chutes de neige",
		"Tonnerre et �claircies","Pas d'info",]; 
		var windDirection =['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO',
		'O', 'ONO', 'NO', 'NNO', 'N'];
		break;
	}
	case "it": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		var this_weekday_name_array=["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];
		var this_month_name_array=["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio",		                                    "Agoste","Settembre","Ottobre","Novembre","Dicembre"];
		var weatherNow =["Soleggiato","Pioggerella","Forti nevicate","Forti piogge","Vevischio","Misto pioggia e neve","Sereno","Molto soleggiato","Parzialmente soleggiato","Nuvoloso a tratti","Sole coperto","Nebbia","Molto nuvoloso","Nuvoloso","Nebbia","Diluvio","Soleggiato con pioggia","Fulmini","Tuoni","Molto Nuvoloso con pioggia e fulmini","Possibili Piogge","Pioggia leggera","Pioggia","Nevischio","Nuvoloso con nevischio","Parzialmente soleggiato con neve","Raffiche di neve","Precipitazioni nevose","Neve","Molto nuvoloso con neve","Ghiaccio","Nevischio","Grandine","Pioggia e neve","Caldo","Freddo","Ventoso","Sereno","Molto sereno","Parzialmente nuvoloso","Velato","Cielo velato","Nuvoloso a tratti","Parzialmente nuvoloso con raffiche","Nebbiolina","Neve leggiera","Poca neve","Forti precipitazioni","Freddino","Misto pioggia e nevischio","Misto neve e nevischio","Tuoni e fulmini","Uragano","Tempesta tropicale","Tornado","Grandine","Vento e neve","Grandine","Polvere","Humeado","Tempesa","misto neve e grandine","Fulmini isolati","Temporali isolati","Tempesta di fulmini","Tempesta di pioggia","Neve sparsa","Pioggia leggera con fulmini","No disponible","Troppa neve","Piccole precipitazioni","Tuoni","Molto nuvoloso con vento","Tormenta","Pioggia e vento","Arena","Tormenta ventosa",]; 
		var windDirection =['N', 'N-NO', 'NO', 'O-NO', 'O', 'O-SO', 'SO', 'S-SO', 'S', 'S-SE', 'SE', 'E-SE', 'E', 'E-NE', 'NE', 'N-NE', 'N'];
		break;
}
	case "sp": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		var this_weekday_name_array=["domingo","lunes","martes","mi�rcoles","jueves","viernes","s�bado"];
		var this_month_name_array=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Juliot","Agosto","Septiembre"," Octubre","Novimbre","Decimbre"];
		
		var weatherNow =["Soleado","Llovizna","Nieve fuerte","Luvia fuerte","Lluvia y nieve","Mezcla de lluvia y nieve","Despejado","Mayormente soleado","Parcialmente soleado","Intermitente nublado","Sol brumoso","Bruma","Mayormente nublado","Nublado","Niebla","Chubascos","Parcialmente soleado con chubascos","Tormentas electricas","Tormenta electrica","Mayormente nublado con tormentas de chubascos","Parcialmente soleado con tormentas de chubascos","Lluvia ligera","Lluvia","Rafagas","Mayormente nublado con rafagas","Parcialmente soleado con rafagas","Rafagas de nieve","Precipitaciones de nieve","Nieve","Mayormente nublado con nieve","Hielo","Aguanieve","Lluvia bajo cero","Mezcla de lluvia y nieve","Caluroso","Frio","Vientoso","Despejado","Mayormente despejado","Parcialmente despejado","Bruma","Parcialmente nublado con chubascos","Mayormente nublado con chubascos","Parcialmente nublado con tormentas de chubascos","Neblina","Nieve ligera","Ligeras precipitaciones de nieve","Precipitaciones de lluvia","Bruma","Mezcla de lluvia y aguanieve","Mezcla de nieve y aguanieve","Tormentas electricas severas","Huracan","Tormenta tropical","Tornado","Llovizna helada","Viento y nieve","Granizo","Polvareda","Humeado","Tempestuoso","Mezcla de lluvia y granizo","Tormentas electricas aisladas","Tormentas aisladas","Tormentas electricas dispersas","Chubascos dispersos","Precipitaciones de nieve dispersas","LLuvia y tormenta ligera","No disponible","Acumulacion de nieve y viento","Precipitaciones de lluvia ligera","Truenos","Mayormente nublado y ventoso","Tormentas de arena","Chubascos y viento","Arena","Tormentas de arena y ventoso",]; 

		 
		var windDirection =['N', 'N-NO', 'NO', 'O-NO', 'O', 'O-SO', 'SO', 'S-SO', 'S', 'S-SE', 'SE', 'E-SE', 'E', 'E-NE', 'NE', 'N-NE', 'N'];
		break;		
	}
}

function ForecastDayNames(day){
	switch (language) {
		case "de": {
			switch (day) {
				case "Mon": { return "Mo" }
				case "Tue": { return "Di" }
				case "Wed": { return "Mi" }
				case "Thu": { return "Do" }
				case "Fri": { return "Fr" }
				case "Sat": { return "Sa" }
				case "Sun": { return "So" }
			}
		}
		case "fr": {
			switch (day) {
				case "Mon": { return "lun" }
				case "Tue": { return "mar" }
				case "Wed": { return "mer" }
				case "Thu": { return "jeu" }
				case "Fri": { return "ven" }
				case "Sat": { return "sam" }
				case "Sun": { return "dim" }
			}
		}
		case "it": {
			switch (day) {
				case "Mon": { return "Lun" }
				case "Tue": { return "Mar" }
				case "Wed": { return "Mer" }
				case "Thu": { return "Gio" }
				case "Fri": { return "Ven" }
				case "Sat": { return "Sab" }
				case "Sun": { return "Dom" }
			}
		}
		case "sp": {
			switch (day) {
				case "Mon": { return "dom" }
				case "Tue": { return "lun" }
				case "Wed": { return "mar" }
				case "Thu": { return "mi�" }
				case "Fri": { return "jue" }
				case "Sat": { return "vie" }
				case "Sun": { return "s�b" }
			}
		}
	}
	return day;
}

