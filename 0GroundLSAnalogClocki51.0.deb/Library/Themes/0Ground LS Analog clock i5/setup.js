/****************************

*	  Basic_theme	    *

*   Version 2.0 05.08.2012  *

*     created by oldster    *

*    http://itheming.de/    *

****************************/



var locale		 = 0;	    // WOEID - only numbers

var nextWeather =15*60*1000; // 15 = mins

var gps_weather  = true;     // false = No GPS Weather

var weather_unit = 'c';      // c = CELSIUS  - f = FAHRENHEIT 

var language ='en'; // en-English, de-Deutsch, fr-France,  it-Italian,	sp-Spanisch

var hour24		 = true;     // false = 12h am/pm

