# Rock Update SB 4.0
# Copyright (C) 2010  Rock Your Phone
#!/bin/bash
# Give time for SB to start too
sleep 10
/var/mobile/Library/RYP/install/updateSB
rm /System/Library/LaunchDaemons/com.rockyourphone.initialSB.plist
 
