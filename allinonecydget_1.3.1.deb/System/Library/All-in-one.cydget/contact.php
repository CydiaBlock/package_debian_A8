<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style3.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="javascript:history.back()"onMouseOver="window.status='Zurück';return true;" onMouseOut="window.status=''"><font color="black"><font size="6">&laquo;Back</font></font></a> 
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>
<br>
If you miss something like a Website, a Link, etc. contact me and I will add your URL. Flickr, MSN and Google have problems, so I can't add them. Use this E-Mail for contact, support, ideas and other things you wanna tell me:
<br><a href="mailto:support@macusercom.com?subject="All in one V1.0 Support">support@macusercom.com</a>
</CENTER>
</body>
</html>

