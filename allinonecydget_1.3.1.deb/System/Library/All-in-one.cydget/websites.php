<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>

<a href="javascript:history.back()"onMouseOver="window.status='Zurück';return true;" onMouseOut="window.status=''"><font color="white"><font size="6">&laquo;Back</font></font></a> 

<table><tr><td valign="top">
<a href="apple.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/apple.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Apple</font></font></CENTER>


<br>



<br>



<br>

</td>


<td width="5px"></td>


<td valign="top">

<div style="width:60px"></div>

<br>



<br>

<br>

</td>

<td width="5px"></td>


<td valign="top">

<div style="width:60px"></div>

<br>


<br>


<br>

</td>


<td width="5px"></td>


<td valign="top">

<div style="width:60px"></div>

<br>



<br>


<br>

</td></tr></table>

<div style="height:110px"></div>

<font color="white"><font size="4px">Do you want your website here? Contact me! Go to Home and tab About to see my E-Mail adress!</font></font>
</CENTER>
</body>
</html>
