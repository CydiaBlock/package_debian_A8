var MainColor = "Black";
var SecondaryColor = "Orange";
var AlignLeft = false;
var ZoomLevel = 70;
