var gl = localStorage.getItem('gl');

if(gl!=null){


$("<iframe></iframe>").attr('id','groovyLock' ).appendTo('body');  // here we make an iframe with id appending it to the body

$("#groovyLock").attr('src','file:///var/mobile/Library/GroovyLock/'+gl+'/LockBackground.html').appendTo('groovyLock');  // append url

$("#groovyLock").attr('style','left:0px;top:0px;border:none;background-color: transparent;visibility:hidden;width:320px;z-index:1;height:480px;display:inline-block;position:absolute;' ).appendTo('groovyLock');  // append css styles




image="img/replace.png";
size="320";
document.getElementById("wallpaperclone").innerHTML = '<img width='+size+' src='+image+'>'
document.getElementById("wallpaperclone2").innerHTML = '<img width='+size+' src='+image+'>'
document.getElementById("wallpaperclone3").innerHTML = '<img width='+size+' src='+image+'>'
document.getElementById("wallpaperclone4").innerHTML = '<img width='+size+' src='+image+'>'


$('.fulltime').css('display','none');
$('#tempimg').css('display','none');
$('.desc').css('display','none');
$('.temptoday').css('display','none');
$('.backshelf').css('display','none');
$('#wallpaperclone3').css('display','none');


$("#groovyLock").attr('onLoad','visible()' ).appendTo('groovyLock'); 

}



function visible(){
  $("#groovyLock").css('visibility', 'visible');
}

function loadgroovy(){

if(confirm('Use previous GroovyLock?')){
GroovyLock();
}

else{  localStorage.removeItem('gl'); GroovyLock();}

GroovyLock();
}





function GroovyLock(){
 var gl = localStorage.getItem('gl');

 if(gl==null){
  gl = prompt("Name of GroovyLock","");
  gl = gl;
  localStorage.setItem('gl', gl);
 }
 location.reload();

}

function killgroovy(){
  localStorage.removeItem('gl');
  location.reload();
}

