
$(window).load(function () {
    $(function () {
        //Enable swiping...
        var addSwipeTo = function (selector) {
            $(selector).swipe("destroy");
            $(selector).swipe({
                //Generic swipe handler for all directions
                swipe: function (event, direction, distance, duration, fingerCount) {
                  
  
                    
                    if (distance >= "180") {
                      
                    }
                    if (direction == "left") {

                        if($( "#leftpanel" ).hasClass( "go" )){
                            leftin();
                        }
                        else{
                            rightout();
                        }
                    
                    
                        //createweathermenu();
                    }
                    if (direction == "right") {
                       
                        if($('#righttouch').css('left')=="300px"){
                            leftout();
                        }
                        else{
                            rightin();
                        }
                   
                        
                    }

                    if(direction=="up"){
                        anibottom();
                   
                    }
                    if(direction=="down"){
                        anitop();
                    
                    }
                },
                //Default is 75px, set to 0 for demo so any distance triggers swipe
                threshold: 0,
                excludedElements:$.fn.swipe.defaults.excludedElements+", .noswipe"
            });
        };
        addSwipeTo("#wallpaper");
        addSwipeTo("#leftbar");
        addSwipeTo("#rightbar");

   

    });
});
