
load();
function load(){

var getitems = localStorage.getItem("userbg");

if(getitems!=null){

$('#wallpaper').css('background-image', 'url(' + getitems + ')');

document.getElementById("wallpaperclone").innerHTML = '<img src='+ getitems+' width="320">'
document.getElementById("wallpaperclone2").innerHTML = '<img src='+ getitems+' width="320">'
document.getElementById("wallpaperclone3").innerHTML = '<img src='+ getitems+' width="320">'
document.getElementById("wallpaperclone4").innerHTML = '<img src='+ getitems+' width="320">'
}

}

  function handleFileSelect(evt) {

     var files = evt.target.files;   // FileList object
    // For Testing these will lock up your phone 
    //alert(evt.target.value);      //Gives fake path
    //alert(JSON.stringify(files)); //Gives name date size, fake for security reasons
    // Loop through the FileList and render image files as thumbnails.
    for (var i = 0, f; f = files[i]; i++) {

      var info = new FileReader(); //make reader to buffer

    info.onload = (function(theFile) {
      $('#files').css('display','none');
       return function(e) {

        //alert(JSON.stringify(e.target.result));  
      var encrypt = JSON.stringify(e.target.result);

    var span = document.createElement('span');  
     span.innerHTML = ['<img class="thumb" id="son" src="', e.target.result,'" />'].join('');
   
   first = e.target.result;
   localStorage.setItem('userbg', first);
   var getitems = localStorage.getItem("userbg");

location.reload();


//if(getitems != null){alert("success");}
//else{alert("cannot save file to storage")}


$('#wallpaper').css('background-image', 'url(' + getitems + ')');

      document.getElementById('list').insertBefore(span, null);
        };
      })(f)
      info.readAsDataURL(f);
    }
  }
document.getElementById('files').addEventListener('change', handleFileSelect, false); 







if (navigator.platform === 'iPad') {
$('#circle').css('display','none');


}