<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>

<a href="javascript:history.back()"onMouseOver="window.status='Zurück';return true;" onMouseOut="window.status=''"><font color="white"><font size="6">&laquo;Back</font></font></a> 

<table><tr><td valign="top">

<a href="wikipedia.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/wikipedia.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Wikipedia</font></font></CENTER>

<br>

<a href="apple.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/apple.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Apple</font></font></CENTER>

<br>


<br>

</td>


<td width="5px"></td>


<td valign="top">

<a href="amazon.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/amazon.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Amazon</font></font></CENTER>

<br>

<a href="converter.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/converter.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Converter</font></font></CENTER>

<br>

<br>

</td>

<td width="5px"></td>


<td valign="top">

<a href="ebay.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/ebay.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">eBay</font></font></CENTER>


<br>



<br>


<br>

</td>


<td width="5px"></td>


<td valign="top">

<a href="bloomberg.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/bloomberg.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Bloomberg</font></font></CENTER>

<br>



<br>


<br>

</td></tr></table>
</CENTER>
</body>
</html>
