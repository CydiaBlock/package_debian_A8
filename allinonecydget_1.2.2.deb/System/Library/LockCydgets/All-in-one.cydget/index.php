<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<table><tr><td>
<a href="browser.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/safari.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Browser</font></font></CENTER>

<br>

<a href="news.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/news.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">News</font></font></CENTER>

<br>

<a href="bing.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/bing.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Bing Search</font></font></CENTER>






</td>


<td width="5px"></td>


<td>
<a href="maps.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/map.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Maps</font></font></CENTER>

<br>

<a href="network.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/network.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Network</font></font></CENTER>


<br>

<a href="macusercom.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/macusercom.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Macusercom</font></font></CENTER>


</td>





<td width="5px"></td>


<td>
<a href="weather.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/weather.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Weather</font></font></CENTER>

<br>

<a href="services.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/services.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Online Sevices</font></font></CENTER>

<br>

<a href="apfelzone.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/apfelzone.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Apfel Zone</font></font></CENTER>
</td>





<td width="5px"></td>


<td>
<a href="yahoo.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/yahoo.png" width="64px" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Yahoo Search</font></font></CENTER>

<br>

<a href="video.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/video.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Video</font></font></CENTER>

<br>

<a href="settings.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/settings.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">About</font></font></CENTER>




</td></tr></table>
<div style="height:77px"></div>
<font color="white">Please Donate if you like the Cydget (About)</font>
<br><font color="white">&copy;2009-2010 by Macusercom</font>
</CENTER>
</body>
</html>
