<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style3.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="javascript:history.back()"onMouseOver="window.status='Zurück';return true;" onMouseOut="window.status=''"><font color="black"><font size="6">&laquo;Back</font></font></a> 
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>
<br>
<b><u>I can't see/or have a problems with the design form a site!</u></b>
<br>This is a web based application. You need internet connection to see the sites. If you can't load a side (only white background) then contact me. If you have problems with login or sites are not correct in the design, it's not my fault. It's a problem by Cydget or from the website. Amazon Site is too wide and Wikipedia can have issues and if oyu tab the letters they won't grow.
<br><br>
<b><u>My SpringBoard crashed!</u></b>
<br>This could be sometimes on the "Browser". If your SpringBoard crashed on another way please contact me.
<br><br>
<b><u>I have a trnasparent rectangle on the top!</u></b>
<br>This is normal. When you press the "back" Text or "Home" Text you will see this. Scroll or touch the display and it's away.
<br><br>
<b><u>I can't delete it!</u></b>
<br>Cydia, Rock App&Co. can delete it, but you can delete it by yourself. If Cydia,Rock App&Co. doesn't delete this cydget download "iFile" and go to System>Library>LockCydgets and select "All-in-one.cydget" and delete it.
<br><br>
<b><u>Things they can't appear in All-in-One Cydget</u></b>
<br>We can't give Google or Flickr into this Cydget, because they don't appear. They don't have a real background, so they have issues. It's nonsense to give a thing into a Cydget which is not working. I am really sorry about that, but Saurik has to update Cydget.
<br><br>
<b><u>This Cydget has a new name!</u></b>
<br>Yes. The "new" name is All-in-One2.0, becuase of the new 2.0 Version.

</CENTER>
</body>
</html>
