<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>

<a href="javascript:history.back()"onMouseOver="window.status='Zurück';return true;" onMouseOut="window.status=''"><font color="white"><font size="6">&laquo;Back</font></font></a> 

<table><tr><td>

<a href="facebook.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/facebook.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Facebook</font></font></CENTER>

<br>

<a href="studivz.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/studivz.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">StudiVZ</font></font></CENTER>

<br>


<br>

</td>


<td width="5px"></td>


<td>

<a href="twitter.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/twitter.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Twitter</font></font></CENTER>

<br>

<a href="schuelervz.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/schuelervz.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Sch&uuml;lerVZ</font></font></CENTER>

<br>

<br>

</td>

<td width="5px"></td>


<td>

<a href="myspace.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/myspace.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">MySpace</font></font></CENTER>

<br>

<a href="linkedin.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/linkedin.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">LinkedIn</font></font></CENTER>

<br>


<br>

</td>


<td width="5px"></td>


<td valign="top">

<a href="netlog.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/netlog.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Netlog</font></font></CENTER>

<br>



<br>


<br>

</td></tr></table>
</CENTER>
</body>
</html>
