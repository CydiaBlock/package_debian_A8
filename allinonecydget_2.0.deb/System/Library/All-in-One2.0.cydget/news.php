<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>

<a href="javascript:history.back()"onMouseOver="window.status='Zurück';return true;" onMouseOut="window.status=''"><font color="white"><font size="6">&laquo;Back</font></font></a> 

<table><tr><td valign="top">
<a href="bbc.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/bbc.jpg" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">BBC (EN)</font></font></CENTER>

<br>

<a href="yahooit.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/yahoo.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Yahoo (IT)</font></font></CENTER>

<br>

<a href="sky.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/skynews.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Sky News</font></font></CENTER>

<br>

</td>


<td width="5px"></td>


<td valign="top">
<a href="cnn.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/cnn.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">CNN (US)</font></font></CENTER>

<br>

<a href="yahoofr.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/yahoo.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Yahoo (FR)</font></font></CENTER>

<br>

<br>

</td>

<td width="5px"></td>


<td valign="top">
<a href="ntv.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/ntv.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">N-TV (D)</font></font></CENTER>

<br>

<a href="yahooes.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/yahoo.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Yahoo (ES)</font></font></CENTER>

<br>


<br>

</td>


<td width="5px"></td>


<td valign="top">

<a href="krone.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/krone.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Krone (A)</font></font></CENTER>

<br>

<a href="yahooca.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/yahoo.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Yahoo (CA)</font></font></CENTER>

<br>


<br>

</td></tr></table>
</CENTER>
</body>
</html>
