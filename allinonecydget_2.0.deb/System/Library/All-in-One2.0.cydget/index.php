<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>



<body>
<CENTER>

<table>
<td bgcolor="black" height="45">
<img src="dg8.gif" width="25px"  name="hr1"><img 
src="dg8.gif" width="25px"  name="hr2"><img 
src="dgc.gif" width="12px"  name="c"><img 
src="dg8.gif" width="25px"  name="mn1"><img 
src="dg8.gif" width="25px"  name="mn2"><img 
src="dgc.gif" width="12px"  name="c"><img 
src="dg8.gif" width="25px"  name="se1"><img 
src="dg8.gif" width="25px" name="se2"><img 
src="dgpm.gif" width="25px"  name="ampm">
</td></table>

<script type="text/javascript"><!-- start
// created: 2000-2004 ricocheting.com
// http://www.ricocheting.com/js/

dg0 = new Image();dg0.src = "dg0.gif";
dg1 = new Image();dg1.src = "dg1.gif";
dg2 = new Image();dg2.src = "dg2.gif";
dg3 = new Image();dg3.src = "dg3.gif";
dg4 = new Image();dg4.src = "dg4.gif";
dg5 = new Image();dg5.src = "dg5.gif";
dg6 = new Image();dg6.src = "dg6.gif";
dg7 = new Image();dg7.src = "dg7.gif";
dg8 = new Image();dg8.src = "dg8.gif";
dg9 = new Image();dg9.src = "dg9.gif";
dgam= new Image();dgam.src= "dgam.gif";
dgpm= new Image();dgpm.src= "dgpm.gif";
dgc = new Image();dgc.src = "dgc.gif";

function dotime(){ 
theTime=setTimeout('dotime()',1000);
d = new Date();
hr= d.getHours()+100;
mn= d.getMinutes()+100;
se= d.getSeconds()+100;
if(hr==100){hr=112;am_pm='am';}
else if(hr<112){am_pm='am';}
else if(hr==112){am_pm='pm';}
else if(hr>112){am_pm='pm';hr=(hr-12);}
tot=''+hr+mn+se;
document.hr1.src = 'dg'+tot.substring(1,2)+'.gif';
document.hr2.src = 'dg'+tot.substring(2,3)+'.gif';
document.mn1.src = 'dg'+tot.substring(4,5)+'.gif';
document.mn2.src = 'dg'+tot.substring(5,6)+'.gif';
document.se1.src = 'dg'+tot.substring(7,8)+'.gif';
document.se2.src = 'dg'+tot.substring(8,9)+'.gif';
document.ampm.src= 'dg'+am_pm+'.gif';}
dotime();
//end -->
</script>


<script>

/*Current date script credit: 
JavaScript Kit (www.javascriptkit.com)
Over 200+ free scripts here!
*/

var mydate=new Date()
var year=mydate.getYear()
if (year < 1000)
year+=1900
var day=mydate.getDay()
var month=mydate.getMonth()+1
if (month<10)
month="0"+month
var daym=mydate.getDate()
if (daym<10)
daym="0"+daym
document.write("<small><font color='c7c034' font size='4px' face='Arial'><b>"+month+"/"+daym+"/"+year+"</b></font></small>")


</script>








<table><tr><td>
<a href="browser.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/safari.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Browser</font></font></CENTER>

<br>

<a href="news.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/news.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">News</font></font></CENTER>

<br>

<a href="video.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/video.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Video</font></font></CENTER>






</td>


<td width="5px"></td>


<td>
<a href="maps.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/map.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Maps</font></font></CENTER>

<br>

<a href="network.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/network.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Network</font></font></CENTER>


<br>

<a href="macusercom.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/macusercom.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Follow Me!</font></font></CENTER>


</td>





<td width="5px"></td>


<td>
<a href="weather.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/weather.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Weather</font></font></CENTER>

<br>

<a href="services.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/services.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Sevices</font></font></CENTER>

<br>

<a href="apfelzone.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/apfelzone.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Win Kaspersky</font></font></CENTER>
</td>





<td width="5px"></td>


<td>
<a href="yahoo.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/yahoo.png" width="64px" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Yahoo Search</font></font></CENTER>

<br>

<a href="websites.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/websites.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Websites</font></font></CENTER>

<br>

<a href="settings.php">
<img src="file:///System/Library/LockCydgets/All-in-One2.0.cydget/images/settings.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">About</font></font></CENTER>




</td></tr></table>


<div style="height:3px"></div>
<font color="white">Please Donate if you like the Cydget (About)</font>
<br><font color="white">&copy;2009-2010 by Macusercom</font>
</CENTER>
</body>
</html>
