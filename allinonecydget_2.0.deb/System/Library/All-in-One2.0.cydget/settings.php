<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style3.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>

<br>All-in-one Version 2.0
<br>"All-in-one" is built by Macusercom
<br><a href="faq.php"><font size="4">FAQ</font></a>
<br><a href="contact.php"><font size="4">Contact (please read FAQ first)</font></a>
<br>&copy;2009-2010 by Macusercom
<br><br>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="11226139">
<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG_global.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypal.com/de_DE/i/scr/pixel.gif" width="1" height="1">
</form>
Or on your PC: http://bit.ly/6W5Fpm
<br><br>If you like this Cydget please donate! We won't give Ads in this Cydget or sell it for money! You help this project on each donation! Thanks!

</CENTER>
</body>
</html>

