<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>
</CENTER>
<iframe width="320" height="450" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0" src="http://at.babelfish.yahoo.com/translate_url?doit=done&tt=url&intl=1&fr=bf-home&trurl=http%3A%2F%2Fwww.apfelzone.com%2Fapfel-zone-gewinnspiel%2F&lp=de_en&btnTrUrl=%DCbersetzen"></iframe>  
</body>
</html>

