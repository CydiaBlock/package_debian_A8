
int app_ctl(char *, char *);
int app_peek(char *);

