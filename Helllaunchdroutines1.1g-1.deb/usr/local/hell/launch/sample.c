#include <stdio.h>
#include <stdlib.h>

#include "sample.h"


int main(int argc, char *argv[])
{

    if(argc < 3)
      printf("usage: ./sample <01234> <app id>\n\n Where:\n\t0 => stop\n\t1 => remove\n\t2 => start\n\t3 => peek if running\n\t4 => load\nApp id is your application identifier like br.inf.unix.myapp\n\n Peek option will return -1 if plist not loaded, 0 if stopped and the pid if running\n"), exit(1);

    switch(argv[1][0]) {
      case '0':
               app_ctl("stop", argv[2]);
               break;

      case '1':
               app_ctl("remove", argv[2]);
               break;

      case '2':
               app_ctl("start", argv[2]); 
               break;

      case '3':
               printf("ret %d\n", app_peek(argv[2]));
               break; 

      case '4':
	       app_ctl("load", argv[2]);
    } 
   
    return 0;
}
