// --- VARS ---

var widgetVersion = "1.1";
var widgetVersionPage = "http://www.bewidget.com/widget_version.php?widget=beruler";

// --- UPDATES ---

function hideUpdate(){
	document.getElementById("update").style.display = "none";
}

function swImg(elt, newsrc){
	elt.src = newsrc;
}

function checkForUpdates(){
	var req = new XMLHttpRequest();
	req.onreadystatechange = function(){
		if (req.readyState == 4) {
			if (req.status == 200) {
				
				string = req.responseText;
				if(string != widgetVersion && string != ""){
					window.resizeTo(300,74);
					document.getElementById("update").style.display = "block";
				}else{
					return false;
				}
				
			}
		}
	}
	
	req.open("GET", widgetVersionPage, true);
	req.send("");
}



var currentPos = "h";
var hNumbers = "";
var vNumbers = "";

function setup(){
	var theNumbers  = document.getElementById("the_numbers");
	for(i=0;i<100;i++){
		hNumbers = hNumbers + '<div class="num">'+((i*50)).toString()+"</div>";
	}
	for(i=0;i<100;i++){
		vNumbers = vNumbers + '<div class="num_v">'+((i*50)).toString()+"</div>";
	}
	theNumbers.innerHTML = hNumbers;
	checkForUpdates();
}

function highlight(){
	$('rotate').style.opacity = 0.5;
}

function unhighlight(){
	$('rotate').style.opacity = 1;
}

function rotate(){
	if(currentPos == "h"){
		window.resizeTo(74, window.outerWidth);
		$('left').className = 'left_v';
		$('right').className = 'right_v';
		$('bg').className = 'bg_v';
		$('right').src = 'images/right_v.png';
		$('growbox').src = 'images/growbox_v.png';
		$('growbox').className = 'growbox_v';
		$('the_numbers').className = 'the_numbers_v';
		$('bewidget').className = 'bewidget_v';
		$('bewidget').src = 'images/logo_v.png';
		$('rotate').className = 'rotate_v';
		$('rotate').src = 'images/rotate_v.png';
		unhighlight();
		$('the_numbers').innerHTML = vNumbers;
		currentPos = "v";
	}else if(currentPos == "v"){
		window.resizeTo(window.outerHeight, 74);
		$('left').className = 'left';
		$('right').className = 'right';
		$('bg').className = 'bg';
		$('right').src = 'images/right.png';
		$('growbox').src = 'images/growbox2.png';
		$('growbox').className = 'growbox';
		$('the_numbers').className = 'the_numbers';
		$('bewidget').className = 'bewidget';
		$('bewidget').src = 'images/logo.png';
		$('rotate').className = 'rotate';
		$('rotate').src = 'images/rotate.png';
		unhighlight();
		$('the_numbers').innerHTML = hNumbers;
		currentPos = "h";
	}
}

var lastPos;		// tracks where the last mouse position was throughout the drag

// The mouseDown function is called the user clicks on the growbox.  It prepares the
// widget to be resized and registers handlers for the resizing operations
function mouseDown(event){

	var x = event.x + window.screenX;		// the placement of the click
	var y = event.y + window.screenY;
	
	document.addEventListener("mousemove", mouseMove, true);  	// begin tracking the move
	document.addEventListener("mouseup", mouseUp, true);		// and notify when the drag ends

	lastPos = {x:x, y:y};		// track where the initial mouse down was, for later comparisons
								// the mouseMove function

	event.stopPropagation();
	event.preventDefault();
}


// mouseMove performs the actual resizing of the widget.  It is called after mouseDown
// activates it and every time the mouse moves.
function mouseMove(event){
	
	var screenX = event.x + window.screenX;		// retrieves the current mouse position
	var screenY = event.y + window.screenY;
		
	var deltaX = 0;		// will hold the change since the last mouseMove event
	var deltaY = 0;
	
	if(currentPos == "h"){
		if ( (window.outerWidth + (screenX - lastPos.x)) >= 75 ) { 		// sets a minimum width constraint
			deltaX = screenX - lastPos.x;								// if we're greater than the constraint,
			lastPos.x = screenX;										// save the change and update our past position
		}
		
		window.resizeBy(deltaX,0);	// resizes the widget to follow the mouse movement
	}else if(currentPos == "v"){

		if ( (window.outerHeight + (screenY - lastPos.y)) >= 75 ) {		// setting contrains for the height
			deltaY = screenY - lastPos.y;
			lastPos.y = screenY;
		}
		
		window.resizeBy(1,deltaY);	// resizes the widget to follow the mouse movement
		window.resizeBy(-1,0); // fixes the bug
	}
	//window.resizeTo(window.outerWidth, window.outerHeight);
	event.stopPropagation();
	event.preventDefault();
}


// mouseUp is called when the user stops resizing the widget.  It removes the mouseMove and
// mouseUp event handlers, so that the widget doesn't continute resizing (because the mouse
// button is now up
function mouseUp(event){
	document.removeEventListener("mousemove", mouseMove, true);
	document.removeEventListener("mouseup", mouseUp, true);	

	event.stopPropagation();
	event.preventDefault();
}

function $(name){
	return document.getElementById(name);
}