var pictures = new Array(); // Wird für die Adressbuchbilderreferenzen benötigt
var disableSending = true;



function load(){
    dashcode.setupParts();
    clearForms();
}


function $(elem){
    return document.getElementById(elem);
}


function showBack(event){
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToBack");
    }

    front.style.display = "none";
    back.style.display = "block";

    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
    
    $('token').value = widget.preferenceForKey("token");
}

function showFront(event){
    // save token
        widget.setPreferenceForKey($('token').value, "token");
    // -
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToFront");
    }

    front.style.display="block";
    back.style.display="none";

    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
}

function searchContact(event){
	var searchField = document.getElementById("search");
	var name = searchField.value;
    
    if (name.length >= 2){
		widget.system("./contacts -Sf %n%mp%u -H " + name, searchContactReply);
	}
}

function searchContactReply(reply){
    pictures = new Array();
    var people = reply.outputString.split("\n");
    
    while ($('number').hasChildNodes()){
        $('number').removeChild($('number').firstChild);
    }
    
    for (var i = 0; i < (people.length - 1); i++) {
        var details = people[i].split(":");

        var element = document.createElement("option");
        element.setAttribute("value", details[1]);
        element.innerText = details[0]+" ("+details[1]+")";
        $('number').appendChild(element);
        
        pictures.push(details[2]);
    }    
    showPic(0);
}

function onChangeUser(){
    showPic($('number').selectedIndex);
}

function showPic (selected) {
    if (selected != -1) {
		picID=pictures[selected];
                
		var imageExists = widget.system("/bin/ls \"$HOME/Library/Application\ Support/AddressBook/Images/\"" + picID, null).outputString;
        var picture = $("personImage");
		var imageSource = "./pic1.png";
		if (imageExists != null && picID != ""){
			widget.system("/bin/cp \"$HOME/Library/Application\ Support/AddressBook/Images/\"" + picID + " " + imageSource, null);
			picture.setAttribute("src", imageSource + "?" + Math.random());//random to ensure refresh
		}else{
			picture.setAttribute("src","bitesms.png");
		}
	}else {
        picture.setAttribute("src","bitesms.png");
	}
}

function sendSMS(){

    var noError = true;

    if($('msg').value.length ==  0){
        $('statusMsg').innerHTML = 'please insert a message';
        noError = false;
    }
    
    if($('number').value ==  -1){
        $('statusMsg').innerHTML = 'please search & select a contact';
        noError = false;
    }
    
    if(widget.preferenceForKey("token") == ''){
        $('statusMsg').innerHTML = 'first you need to insert your bitesms token...';
        noError = false;
    }
    //QV0o9qAAwMCUfyJ6jN55
    
    if(noError){
        var onloadHandler = function() { xmlLoaded(xmlRequest); };	

        var xmlRequest = new XMLHttpRequest();
        xmlRequest.onload = onloadHandler;
        xmlRequest.open("POST", "http://smsgateway.bitesms.com/deliver");
        xmlRequest.setRequestHeader("Cache-Control", "no-cache");
   
        var now = new Date();
        var dateString = now.getFullYear()+"-"+(now.getMonth()+1)+"-"+now.getDate()+" "+now.getHours()+":"+now.getMinutes()+":"+now.getSeconds();
    
        xmlRequest.send('<?xml version="1.0" encoding="UTF-8"?><sms><timestamp>'+dateString+' +0100</timestamp><recipients><to>'+$('number').value+'</to></recipients><vouchers><token>'+widget.preferenceForKey("token")+'</token></vouchers><message>'+$('msg').value+'</message></sms>');
        $("stackLayout").object.setCurrentView("view2",true);
    }
}

function xmlLoaded(xmlRequest) {
	if (xmlRequest.status == 200) {
		clearForms();
        
        if(xmlRequest.responseText.indexOf('<type>ERROR</type>') != -1){
            $("msg").value = 'Error while sending SMS. \n\nPlease try again later or contact dennis.rochel@imount.de';
        }
        
        $("stackLayout").object.setCurrentView("view1",true);
	}else{
		$("msg").value = "Error fetching data: HTTP status " + xmlRequest.status;
	}
}

function clearForms(){
    $('personImage').setAttribute("src","bitesms.png");
    $('personImage').value = "";
    
    while ($('number').hasChildNodes()){
        $('number').removeChild($('number').firstChild);
    }
    
    $('search').value = '';
    
    var element = document.createElement("option");
    element.innerText = "search has no matches";
    element.setAttribute("value", "-1");
    $('number').appendChild(element);    
    $('statusMsg').innerHTML = '';
    
    $('msg').value = '';
}


function getHelp(){
    widget.openURL("http://dev.imount.de/bitesms-widget/");
}