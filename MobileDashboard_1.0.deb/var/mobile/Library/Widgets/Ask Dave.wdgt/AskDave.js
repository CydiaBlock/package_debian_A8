
// -----------------------------------------------------------------------

// Much of this was swiped from Alwin Troost -  http://www.alwintroost.nl/

// -----------------------------------------------------------------------


function goWeb(site)
{
	if (window.widget)
	{
		widget.openURL(site);
	}
}


var timerTick = 0;

var images = new Array();
images['Images/Shaker0.png'] = new Image();
images['Images/Shaker0.png'].src = 'Images/Shaker0.png';
images['Images/Shaker1.png'] = new Image();
images['Images/Shaker1.png'].src = 'Images/Shaker1.png';
images['Images/Shaker2.png'] = new Image();
images['Images/Shaker2.png'].src = 'Images/Shaker2.png';
images['Images/Shaker3.png'] = new Image();
images['Images/Shaker3.png'].src = 'Images/Shaker3.png';
images['Images/Shaker4.png'] = new Image();
images['Images/Shaker4.png'].src = 'Images/Shaker4.png';

var answers = new Array();
answers['Answers/0.png'] = new Image();
answers['Answers/0.png'].src = 'Answers/0.png';
answers['Answers/1.png'] = new Image();
answers['Answers/1.png'].src = 'Answers/1.png';
answers['Answers/2.png'] = new Image();
answers['Answers/2.png'].src = 'Answers/2.png';
answers['Answers/3.png'] = new Image();
answers['Answers/3.png'].src = 'Answers/3.png';
answers['Answers/4.png'] = new Image();
answers['Answers/4.png'].src = 'Answers/4.png';
answers['Answers/5.png'] = new Image();
answers['Answers/5.png'].src = 'Answers/5.png';
answers['Answers/6.png'] = new Image();
answers['Answers/6.png'].src = 'Answers/6.png';
answers['Answers/7.png'] = new Image();
answers['Answers/7.png'].src = 'Answers/7.png';
answers['Answers/8.png'] = new Image();
answers['Answers/8.png'].src = 'Answers/8.png';
answers['Answers/9.png'] = new Image();
answers['Answers/9.png'].src = 'Answers/9.png';
answers['Answers/10.png'] = new Image();
answers['Answers/10.png'].src = 'Answers/10.png';
answers['Answers/11.png'] = new Image();
answers['Answers/11.png'].src = 'Answers/11.png';
answers['Answers/12.png'] = new Image();
answers['Answers/12.png'].src = 'Answers/12.png';
answers['Answers/13.png'] = new Image();
answers['Answers/13.png'].src = 'Answers/13.png';
answers['Answers/14.png'] = new Image();
answers['Answers/14.png'].src = 'Answers/14.png';
answers['Answers/15.png'] = new Image();
answers['Answers/15.png'].src = 'Answers/15.png';
answers['Answers/16.png'] = new Image();
answers['Answers/16.png'].src = 'Answers/16.png';
answers['Answers/17.png'] = new Image();
answers['Answers/17.png'].src = 'Answers/17.png';
answers['Answers/18.png'] = new Image();
answers['Answers/18.png'].src = 'Answers/18.png';
answers['Answers/19.png'] = new Image();
answers['Answers/19.png'].src = 'Answers/19.png';
answers['Answers/20.png'] = new Image();
answers['Answers/20.png'].src = 'Answers/20.png';
answers['Answers/21.png'] = new Image();
answers['Answers/21.png'].src = 'Answers/21.png';
answers['Answers/22.png'] = new Image();
answers['Answers/22.png'].src = 'Answers/22.png';
answers['Answers/23.png'] = new Image();
answers['Answers/23.png'].src = 'Answers/23.png';
answers['Answers/24.png'] = new Image();
answers['Answers/24.png'].src = 'Answers/24.png'; 


function clearAnswer()
{
	var ans = document.getElementById('answerImage');
	ans.src=answers['Answers/24.png'].src;
}


function giveAnswer()
{
	var ans = document.getElementById('answerImage');
	var seed = new Date().getSeconds();
	var randy=Math.floor(Math.random(seed)*24);
	
	if (randy==0) ans.src=answers['Answers/0.png'].src;
	if (randy==1) ans.src=answers['Answers/1.png'].src;
	if (randy==2) ans.src=answers['Answers/2.png'].src;
	if (randy==3) ans.src=answers['Answers/3.png'].src;
	if (randy==4) ans.src=answers['Answers/4.png'].src;
	if (randy==5) ans.src=answers['Answers/5.png'].src;
	if (randy==6) ans.src=answers['Answers/6.png'].src;
	if (randy==7) ans.src=answers['Answers/7.png'].src;
	if (randy==8) ans.src=answers['Answers/8.png'].src;
	if (randy==9) ans.src=answers['Answers/9.png'].src;
	if (randy==10) ans.src=answers['Answers/10.png'].src;
	if (randy==11) ans.src=answers['Answers/11.png'].src;
	if (randy==12) ans.src=answers['Answers/12.png'].src;
	if (randy==13) ans.src=answers['Answers/13.png'].src;
	if (randy==14) ans.src=answers['Answers/14.png'].src;
	if (randy==15) ans.src=answers['Answers/15.png'].src;
	if (randy==16) ans.src=answers['Answers/16.png'].src;
	if (randy==17) ans.src=answers['Answers/17.png'].src;
	if (randy==18) ans.src=answers['Answers/18.png'].src;
	if (randy==19) ans.src=answers['Answers/19.png'].src;
	if (randy==20) ans.src=answers['Answers/20.png'].src;
	if (randy==21) ans.src=answers['Answers/21.png'].src;
	if (randy==22) ans.src=answers['Answers/22.png'].src;
	if (randy==23) ans.src=answers['Answers/23.png'].src;
}


function letsGo(event)
{
	timerTick=0;
	startShaking();
}


function startShaking()
{
	timerTick = 0;
	timer = setInterval ("shake();", 25);
}


function shake()
{
	var img = document.getElementById('sketchImage');
	
	if (timerTick==1) clearAnswer();
	if (timerTick==1) img.src=images['Images/Shaker1.png'].src;
	if (timerTick==2) img.src=images['Images/Shaker2.png'].src;
	if (timerTick==3) img.src=images['Images/Shaker1.png'].src;
	if (timerTick==4) img.src=images['Images/Shaker0.png'].src;
	if (timerTick==5) img.src=images['Images/Shaker3.png'].src;
	if (timerTick==6) img.src=images['Images/Shaker4.png'].src;
	if (timerTick==7) img.src=images['Images/Shaker3.png'].src;
	if (timerTick==8) img.src=images['Images/Shaker0.png'].src;

	if (timerTick==9) img.src=images['Images/Shaker1.png'].src;
	if (timerTick==10) img.src=images['Images/Shaker2.png'].src;
	if (timerTick==11) img.src=images['Images/Shaker1.png'].src;
	if (timerTick==12) img.src=images['Images/Shaker0.png'].src;
	if (timerTick==13) img.src=images['Images/Shaker3.png'].src;
	if (timerTick==14) img.src=images['Images/Shaker4.png'].src;
	if (timerTick==15) img.src=images['Images/Shaker3.png'].src;
	if (timerTick==16) img.src=images['Images/Shaker0.png'].src;

	if (timerTick==17) img.src=images['Images/Shaker1.png'].src;
	if (timerTick==18) img.src=images['Images/Shaker2.png'].src;
	if (timerTick==19) img.src=images['Images/Shaker1.png'].src;
	if (timerTick==20) img.src=images['Images/Shaker0.png'].src;
	if (timerTick==21) img.src=images['Images/Shaker3.png'].src;
	if (timerTick==22) img.src=images['Images/Shaker4.png'].src;
	if (timerTick==23) img.src=images['Images/Shaker3.png'].src;
	if (timerTick==24) img.src=images['Images/Shaker0.png'].src;
	if (timerTick==24) giveAnswer();

	timerTick++;
	
	if (timerTick==25){
		clearInterval(timer);
	}	
}


// -------------------------------------------------------------------

// Anything below this point was taken from Apple's pref/flip routines

// -------------------------------------------------------------------

function showPrefs()
{
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget)
		widget.prepareForTransition("ToBack");
	
	front.style.display="none";
	back.style.display="block";
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);

	document.getElementById('fliprollie').style.display = 'none';
}


function hidePrefs()
{
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget)
		widget.prepareForTransition("ToFront");
	
	back.style.display="none";
	front.style.display="block";
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);
}


function makeKey(key)
{
	return (widget.identifier + "-" + key);
}


function removed()
{

	widget.setPreferenceForKey(null,makeKey("worldString"));
}


function focused()
{
	document.getElementById('worldText').style.color = 'white'; 
}


function blurred()
{
	document.getElementById('worldText').style.color = 'gray'; 
}


if(window.widget)
{
	widget.onremove = removed;
	window.onfocus = focused;
	window.onblur = blurred;
}	


var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};


function mousemove (event)
{
	if (!flipShown)
	{
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13;
		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 1.0;
		animate();
		flipShown = true;
	}
}


function mouseexit (event)
{
	if (flipShown)
	{
		// fade in the flip widget
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13;
		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}


function animate()
{
	var T;
	var ease;
	var time = (new Date).getTime();
		
	
	T = limit_3(time-animation.starttime, 0, animation.duration);
	
	if (T >= animation.duration)
	{
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}
	else
	{
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	
	animation.firstElement.style.opacity = animation.now;
}


function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}


function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}


function enterflip(event)
{
	document.getElementById('fliprollie').style.display = 'block';
}


function exitflip(event)
{
	document.getElementById('fliprollie').style.display = 'none';
}
