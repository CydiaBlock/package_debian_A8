
resp=$1
install(){
# data=$(id)
# echo $data
data=$(id)
echo $data
nocache=1
echo "set nocache !!!!!"
export nocache
dpkg -i /var/mobile/Documents/kbatterydownloader/kbdpro_battview.deb 
if [ "$resp" -eq "1" ];then
    echo need resping
    killall SpringBoard
fi
}
main(){
flag=/var/tmp/runkbdrm
if [ -f $flag ]; then
	echo $flag installmain!!
	rm -f $flag
	install $resp
fi
}
main >> /var/tmp/kBatteryDownload.log 2>&1; 

