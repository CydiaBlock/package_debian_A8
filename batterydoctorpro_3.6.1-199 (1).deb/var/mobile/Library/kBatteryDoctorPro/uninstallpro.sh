dpkg -r com.ijinshan.kbatterydoctorpro &
