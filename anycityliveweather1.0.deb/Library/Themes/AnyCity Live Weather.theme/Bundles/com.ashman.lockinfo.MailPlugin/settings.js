if(!Settings['com.ashman.lockinfo.MailPlugin'])
  Settings['com.ashman.lockinfo.MailPlugin'] = {};

Settings['com.ashman.lockinfo.MailPlugin'] = Object.extend({
  
  // Enable/Disable Expansion
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  // Group Mails
  groupMails: false,
  
  // Group mails by date when not grouped by account
  groupDates: true,
  
  // Nb of mails displayed folded
  maxMailCount: 3,
  
  // Nb of mails displayed once unfolded (0 = no limit)
  maxMailCountExpanded: 10,
}, Settings['com.ashman.lockinfo.MailPlugin']);
