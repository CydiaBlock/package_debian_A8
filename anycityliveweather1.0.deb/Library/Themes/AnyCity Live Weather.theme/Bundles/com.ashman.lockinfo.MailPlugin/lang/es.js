
if(!Es)
  var Es = new Language('es');

Es.setString("New Mail","Nuevo email");
Es.setString("New Mails","Nuevos emails");
