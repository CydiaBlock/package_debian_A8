﻿
if(!Cs)
	var Cs = new Language('cs');

Cs.setString("New Mail","Nový e-mail");
