
if(!Tr)
	var Tr = new Language('tr');

Tr.setString("New Mail","Yeni e-posta");
Tr.setString("New Mails","Yeni e-postalar");
