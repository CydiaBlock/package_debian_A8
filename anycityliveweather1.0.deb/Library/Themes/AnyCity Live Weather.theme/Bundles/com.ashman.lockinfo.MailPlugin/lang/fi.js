﻿
if(!Fi)
	var Fi = new Language('fi');

Fi.setString("New Mail","Uusi sähköposti");
Fi.setString("New Mails","Uusia sähköposteja");
