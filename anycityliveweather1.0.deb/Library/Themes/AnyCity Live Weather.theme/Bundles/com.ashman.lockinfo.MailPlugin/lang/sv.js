
if(!Sv)
  var Sv = new Language('sv');

Sv.setString("New Mail","Nytt Mail");
Sv.setString("New Mails","Nya Mail");
