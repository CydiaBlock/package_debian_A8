
if(!Ro)
  var Ro = new Language('ro');

Ro.setString("New Mail","E-mail nou");
Ro.setString("New Mails","E-mailuri noi");
