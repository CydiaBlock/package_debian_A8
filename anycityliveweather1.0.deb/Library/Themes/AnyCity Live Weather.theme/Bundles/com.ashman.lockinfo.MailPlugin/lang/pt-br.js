
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("New Mail","Novo email");
PtBr.setString("New Mails","Novos emails");
