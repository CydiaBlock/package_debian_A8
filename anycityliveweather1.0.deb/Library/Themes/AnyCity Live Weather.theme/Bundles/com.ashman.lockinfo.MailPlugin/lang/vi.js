
if(!Vi)
  var Vi = new Language('vi');

Vi.setString("New Mail","Thư mới");
