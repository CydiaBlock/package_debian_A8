
if(!Pt)
  var Pt = new Language('pt');

Pt.setString("New Mail","Novo Mail");
Pt.setString("New Mails","Novos Mails");
