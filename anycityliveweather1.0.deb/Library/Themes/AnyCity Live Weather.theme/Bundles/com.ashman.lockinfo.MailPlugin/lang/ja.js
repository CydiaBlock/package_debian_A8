
if(!Ja)
	var Ja = new Language('ja');

Ja.setString("New Mail","新着メール");
Ja.setString("New Mails","新着メール");
