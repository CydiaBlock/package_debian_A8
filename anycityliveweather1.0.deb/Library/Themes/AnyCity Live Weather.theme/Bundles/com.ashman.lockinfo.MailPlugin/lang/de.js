
if(!De)
  var De = new Language('de');

De.setString("New Mail","Neue Mail");
De.setString("New Mails","Neue Mails");
