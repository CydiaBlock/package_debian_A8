
if(!ZhCn)
  var ZhCn = new Language('zh-cn');

ZhCn.setString("New Mails","新到邮件");
ZhCn.setString("New Mail","新邮件");
