
if(!It)
  var It = new Language('it');

It.setString("New Mail","Nuova Mail");
It.setString("New Mails","Nuove Mail");
