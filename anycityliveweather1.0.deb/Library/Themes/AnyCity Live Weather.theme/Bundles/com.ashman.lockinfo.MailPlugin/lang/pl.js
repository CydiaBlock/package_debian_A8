
if(!Pl)
  var Pl = new Language('pl');

Pl.setString("New Mail","Nowa Poczta");
Pl.setString("New Mails","Nowych wiadomości e-mail");
