
if(!Fr)
  var Fr = new Language('fr');

//desc:E-mails
Fr.setString("New Mail","Nouveau e-mail ");
Fr.setString("New Mails","Nouveaux e-mails ");
