
if(!Ru)
  var Ru = new Language('ru');

Ru.setString("New Mail","Новое письмо");
Ru.setString("New Mails","Новых писем");
