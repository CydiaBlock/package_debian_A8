
if(!NbNo)
  var NbNo = new Language('nb-no');

NbNo.setString("New Mail","Ny e-post");
NbNo.setString("New Mails","Nye e-post");
