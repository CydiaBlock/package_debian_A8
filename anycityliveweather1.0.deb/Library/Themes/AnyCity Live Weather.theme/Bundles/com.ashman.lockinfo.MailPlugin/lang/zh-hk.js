﻿
if(!ZhHk)
	var ZhHk = new Language('zh-hk');

ZhHk.setString("New Mail","新郵件");
ZhHk.setString("New Mails","新郵件");
