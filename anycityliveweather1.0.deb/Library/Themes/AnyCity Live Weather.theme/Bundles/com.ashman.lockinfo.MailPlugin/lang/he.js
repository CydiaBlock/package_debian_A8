
if(!He)
	var He = new Language('he');

He.setString("New Mail","דואר חדש");
He.setString("New Mails","דואר חדש");
