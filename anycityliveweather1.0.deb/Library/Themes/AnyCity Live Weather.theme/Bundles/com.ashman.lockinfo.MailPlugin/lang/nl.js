
if(!Nl)
  var Nl = new Language('nl');

Nl.setString("New Mail","Nieuwe e-mail");
Nl.setString("New Mails","Nieuwe e-mails");
