
if(!El)
	var El = new Language('el');

El.setString("New Mail","Νέο e-mail");
El.setString("New Mails","Νέα e-mails");
