/*

  MobileMail plugin
  
    Show unread emails
    
*/
//console.log('loading mail...');
var Mail = new Plugin('com.ashman.lockinfo.MailPlugin');

Mail.short = 'mail';
Mail.bundleIdentifier = 'com.ashman.lockinfo.MailPlugin';
Mail.expandable = [];
Mail.expander = [];
Mail.expanded = [];

Mail.preload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.overrideMimeType("text/xml");
  
  xmlReq.open("GET", 'li://com.ashman.lockinfo.MailPlugin/updateView',true);
  
  xmlReq.setRequestHeader("Cache-Control", "no-cache");
  xmlReq.send(null);
};

Mail.callback = function(data) {
  
  accounts_content = [];
  account_count = [];
  c_div = [];
  
  this.Design.clean();
  this.nowExpand = [];
  
  var msgs = data.messages;
  if (msgs.length > 0) {
    var currentAccount = null;
    var currentDate = null;
    var maxPerAccount = ((this.Settings.maxMailCountExpanded == 0)?msgs.length:this.Settings.maxMailCountExpanded);
    
    function sortfunction(a, b){
      return (b.received - a.received);
    }
    
    if(this.Settings.groupMails && this.Settings.groupDates)
      msgs.sort(sortfunction);
    
    for (i = 0; i < msgs.length; i++) {
      // Different acount from last message
      if ((!this.Settings.groupMails && msgs[i].account != currentAccount) || currentAccount == null) {
        currentAccount = msgs[i].account;
        
        if(typeof this.nowExpand[currentAccount] == 'undefined')
          this.nowExpand[currentAccount] = false;
        
        if(typeof account_count[currentAccount] == 'undefined')
          account_count[currentAccount] = 0;
        
        if(typeof accounts_content[currentAccount] == 'undefined') {
          accounts_content[currentAccount] = document.createElement('div');
          c_div[currentAccount] = accounts_content[currentAccount];
        }
        
        if(typeof this.expanded[currentAccount] == 'undefined')
          this.expanded[currentAccount] = false;
      }
      
      if (account_count[currentAccount] < 100) {
        if (account_count[currentAccount] < maxPerAccount) {
          if((account_count[currentAccount] >= this.Settings.maxMailCount) && (!this.nowExpand[currentAccount])) {
            div = accounts_content[currentAccount].appendChild(this.Design.generateCustom('','','mail-'+currentAccount.replace(/([:\s])/i,'-')));
            div.style.display = (this.Settings.defState == 'shrinked' && !this.expanded[currentAccount])?'none':'block';
            this.expanded[currentAccount] = (!(this.Settings.defState == 'shrinked' && !this.expanded[currentAccount]));
            c_div[currentAccount] = div
            this.nowExpand[currentAccount] = true;
          }
          
          var date = new Date(msgs[i].received);
          
          if(this.Settings.groupMails && this.Settings.groupDates && (currentDate == null || date.isDifferentDay(currentDate))) {
            if(date.isToday())
              c_div[currentAccount].appendChild(this.Design.generateHeader($L('Today'), 'dayHeader'));
            else if(date.isYesterday())
              c_div[currentAccount].appendChild(this.Design.generateHeader($L('Yesterday'), 'dayHeader'));
            else
              c_div[currentAccount].appendChild(this.Design.generateHeader(date.format($S('longDate')), 'dayHeader'));
            
            currentDate = date;
          }

          if(this.Settings.groupMails && this.Settings.groupDates)
            var dateStr = (Settings.useRelative)?date.relative():date.format($S('formatTime'));
          else if (date.isToday())
            var dateStr = ((Settings.useRelative)?date.relative():$L('Today')+" "+$S('dateDivider')+' '+date.format($S('formatTime')));
          else if (date.isYesterday())
            var dateStr = ((Settings.useRelative)?date.relative():$L('Yesterday')+" "+$S('dateDivider')+' '+date.format($S('formatTime')));
          else
            var dateStr = ((Settings.useRelative)?date.relative():date.format($S('formatDate'))+" "+$S('dateDivider')+' '+date.format($S('formatTime')));
          
          var temp = document.createDocumentFragment();
          
          if(this.Settings.groupMails) {
            var account_sp = document.createElement('span');
            account_sp.className = 'mailAccount';
            account_sp.appendChild(document.createTextNode(msgs[i].account));
            
            temp.appendChild(account_sp);
          }
          
          var subject = document.createElement('span');
          subject.className = 'mailSubject'+((this.Settings.groupMails)?' regrouped':'');
          subject.appendChild(document.createTextNode(msgs[i].subject));
          
          temp.appendChild(subject);
          
          var sum = this.Design.generateSummary(temp,(i == 0 ? " firstItem" : ""));
          sum.onclick = function(e){ var t=this.getDimensions().height; toggleClassName(this,'readSubject'); if(t != this.getDimensions().height) e.stopPropagation();};
          
					c_div[currentAccount].appendChild(sum);
					c_div[currentAccount].appendChild(this.Design.generateLocation(msgs[i].sender.truncate()+' '+$S('dateDivider')+' '+dateStr));
				}
				account_count[currentAccount]++;
      }
    }
    
    var j=1;
    for(var s in accounts_content) {
      var strCount = (maxPerAccount < account_count[s])?maxPerAccount+'/'+account_count[s]:account_count[s];
      var ul = this.Design.generateCustom(this.Design.generateHeader(((Settings.nbBefore)?((this.Settings.groupMails)?strCount+' '+((account_count[s] > 1)?$L('New Mails'):$L('New Mail')):s+': '+strCount):((this.Settings.groupMails)?((account_count[s] > 1)?$L('New Mails'):$L('New Mail')):s)+': '+strCount)),'account','expander-'+s.replace(/([:\s])/i,'-'));
      ul.account = s;
      ul.appendChild(accounts_content[s]);
      
      this.Design.appendCustom(ul);
      
      if(this.nowExpand[s]) {
        this.expandable[s] = 'mail-'+s.replace(/([:\s])/i,'-');
        this.expander[s] = 'expander-'+s.replace(/([:\s])/i,'-');
  		  this.Design.appendCustom('. . .','expand');
  		}
      
      j++;
    }
    
    this.setToggle();
  }
  
  return true;
};

Controller.registerPlugin(Mail);
