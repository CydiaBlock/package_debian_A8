
if(!Pl)
  var Pl = new Language('pl');

Pl.setString("Voicemail","Nowych wiadomości Voicemail"); //Text displayed in the topbar of voicemails
Pl.setString("Unknown","Nieznany"); //Text displayed for unknown callers
