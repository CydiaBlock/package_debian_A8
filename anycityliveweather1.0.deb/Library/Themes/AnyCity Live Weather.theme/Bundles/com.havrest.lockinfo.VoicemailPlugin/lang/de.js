
if(!De)
  var De = new Language('de');

De.setString("Voicemail","Voicemail");
De.setString("Unknown","Unbekannt");
