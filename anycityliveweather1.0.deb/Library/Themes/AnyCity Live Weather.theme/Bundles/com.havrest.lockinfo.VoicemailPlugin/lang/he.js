
if(!He)
	var He = new Language('he');

He.setString("Voicemail","דואר קולי");
He.setString("Unknown","לא ידוע");
