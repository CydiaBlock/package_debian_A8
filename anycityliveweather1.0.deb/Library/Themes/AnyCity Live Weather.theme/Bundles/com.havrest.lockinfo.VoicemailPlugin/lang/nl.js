
if(!Nl)
  var Nl = new Language('nl');

Nl.setString("Voicemail","Voicemail");
Nl.setString("Unknown","Onbekend"); //Text displayed for unknown callers
