
if(!Fr)
  var Fr = new Language('fr');

//desc:Calls
Fr.setString("Voicemail","Messagerie vocale "); //Text displayed in the topbar of voicemails
Fr.setString("Unknown","Masqué"); //Text displayed for unknown callers
