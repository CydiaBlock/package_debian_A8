
if(!Sv)
  var Sv = new Language('sv');

Sv.setString("Missed Call","Missat Samtal");
Sv.setString("Missed Calls","Missade Samtal");
Sv.setString("Voicemail","Mobilsvar");
Sv.setString("Unknown","Okänd");
