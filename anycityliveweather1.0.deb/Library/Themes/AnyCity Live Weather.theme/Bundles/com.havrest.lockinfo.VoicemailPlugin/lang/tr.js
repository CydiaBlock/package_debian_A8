
if(!Tr)
	var Tr = new Language('tr');

Tr.setString("Unknown","Bilinmeyen");
