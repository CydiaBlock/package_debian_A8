if(!Cs)
  var Cs = new Language('cs');

Cs.setString("Voicemail","Hlasová pošta");
Cs.setString("Unknown","Neznámý"); //Text displayed for unknown callers
