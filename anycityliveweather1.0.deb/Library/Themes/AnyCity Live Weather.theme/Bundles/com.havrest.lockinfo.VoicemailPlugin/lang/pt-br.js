
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("Voicemail","Caixa postal");
PtBr.setString("Unknown","Desconhecido");
