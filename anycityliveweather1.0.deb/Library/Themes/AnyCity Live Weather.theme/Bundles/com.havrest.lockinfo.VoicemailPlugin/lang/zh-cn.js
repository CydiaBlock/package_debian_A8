
if(!ZhCn)
  var ZhCn = new Language('zh-cn');

ZhCn.setString("Voicemail","语音信箱"); //Text displayed in the topbar of voicemails
ZhCn.setString("Unknown","未知联系人"); //Text displayed for unknown callers
