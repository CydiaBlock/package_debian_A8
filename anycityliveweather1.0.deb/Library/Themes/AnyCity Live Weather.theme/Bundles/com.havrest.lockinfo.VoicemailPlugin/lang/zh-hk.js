﻿
if(!ZhHk)
	var ZhHk = new Language('zh-hk');

ZhHk.setString("Voicemail","語音留言");
ZhHk.setString("Unknown","没有來電顯示");
