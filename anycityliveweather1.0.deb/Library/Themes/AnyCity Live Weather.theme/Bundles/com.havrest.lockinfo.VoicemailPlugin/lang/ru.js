
if(!Ru)
  var Ru = new Language('ru');

Ru.setString("Voicemail","Голосовая почта");
Ru.setString("Unknown","Неизвестный");
