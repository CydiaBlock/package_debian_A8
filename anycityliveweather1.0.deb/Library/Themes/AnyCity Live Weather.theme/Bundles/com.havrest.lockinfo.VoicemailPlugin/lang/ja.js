
if(!Ja)
	var Ja = new Language('ja');

Ja.setString("Voicemail","ボイスメール");
Ja.setString("Unknown","非通知着信");
