
if(!Es)
  var Es = new Language('es');

Es.setString("Voicemail","Buzón de Voz"); //Text displayed in the topbar of voicemails
Es.setString("Unknown","Desconocido"); //Text displayed for unknown callers
