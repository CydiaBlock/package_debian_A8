
if(!El)
	var El = new Language('el');

El.setString("Voicemail","Τηλεφωνητής");
El.setString("Unknown","Άγνωστος");
