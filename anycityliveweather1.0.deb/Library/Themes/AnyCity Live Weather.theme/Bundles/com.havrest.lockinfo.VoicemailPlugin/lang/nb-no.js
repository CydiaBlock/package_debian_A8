
if(!NbNo)
  var NbNo = new Language('nb-no');

NbNo.setString("Voicemail","Mobilsvar"); //Text displayed in the topbar of voicemails
NbNo.setString("Unknown","Ukjent"); //Text displayed for unknown callers
