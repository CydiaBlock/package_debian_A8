
if(!Pt)
  var Pt = new Language('pt');

Pt.setString("Voicemail","Voicemail");
Pt.setString("Unknown","Desconhecido");
