
if(!Ro)
  var Ro = new Language('ro');

Ro.setString("Voicemail","Casuta vocala"); //Text displayed in the topbar of voicemails
Ro.setString("Unknown","Necunoscut"); //Text displayed for unknown callers
