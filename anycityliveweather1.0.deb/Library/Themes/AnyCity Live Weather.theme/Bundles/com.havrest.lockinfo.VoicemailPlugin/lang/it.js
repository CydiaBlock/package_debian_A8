
if(!It)
  var It = new Language('it');

It.setString("Voicemail","Segreteria"); //Text displayed in the topbar of voicemails
It.setString("Unknown","Anonimo"); //Text displayed for unknown callers
