
var CallsVoice = new Plugin('com.havrest.lockinfo.VoicemailPlugin');

CallsVoice.short = 'calls:voicemail';
CallsVoice.bundleIdentifier = 'com.ashman.lockinfo.PhonePlugin';

CallsVoice.expandable = 'voicemail-expand';

CallsVoice.preload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.overrideMimeType("text/xml");
  
  xmlReq.open("GET", 'li://com.ashman.lockinfo.PhonePlugin/updateView',true);
  
  xmlReq.setRequestHeader("Cache-Control", "no-cache");
  xmlReq.send(null);
};

CallsVoice.callback = function(data) {
  if (data.voicemail)
    this.callback_voicemail(data);
};

CallsVoice.callback_voicemail = function(data) {
  
  this.Design.clean();
  this.nowExpand = false;
  
  var vm = data.voicemail;
  var currentDate;
  if (vm.length > 0) {
    var maxExpanded = ((this.Settings.maxVoicemailExpanded == 0)?vm.length:this.Settings.maxVoicemailExpanded);
    
    var countStr = ((maxExpanded < vm.length)?maxExpanded+'/'+vm.length:vm.length);
    
    //Add header
    var div = this.Design.generateCustom('','voicemail-content','voicemail');
    div.appendChild(this.Design.generateHeader($L('Voicemail')+": "+countStr));
		
		for (i = 0; i < vm.length && i < maxExpanded; i++) {
		  
		  if((i >= this.Settings.maxVoicemail) && (!this.nowExpand)) {
        this.Design.appendCustom(div);
        div = div.appendChild(this.Design.generateCustom('','voicemail-content','voicemail-expand'));
        div.style.display = (this.Settings.defVoicemailState == 'shrinked' && !this.expanded)?'none':'block';
        this.expanded = (!(this.Settings.defVoicemailState == 'shrinked' && !this.expanded));
        this.nowExpand = true;
      }
      
      
			date = new Date();
			date.setTime(vm[i].date);
      
      if ((!this.Settings.groupVoicemails) && (currentDate == null || date.isDifferentDay(currentDate))) {
        if(date.isToday())
          div.appendChild(this.Design.generateHeader($L('Today'), 'dayHeader'));
        else if(date.isYesterday())
          div.appendChild(this.Design.generateHeader($L('Yesterday'), 'dayHeader'));
        else
          div.appendChild(this.Design.generateHeader(date.format($S('longDate')), 'dayHeader'));
        
        currentDate = date;
      }
      
      //Add Caller ID
      div.appendChild(this.Design.generateSummary(vm[i].caller,(i == 0 ? "firstItem" : "")));
      
			
			//Add Date
      if(!this.Settings.groupVoicemails)
        div.appendChild(this.Design.generateLocation((Settings.useRelative)?date.relative():date.format($S('formatTime'))));
      else if (date.isToday())
        div.appendChild(this.Design.generateLocation($L('Today')+" "+$S('dateDivider')+' '+((Settings.useRelative)?date.relative():date.format($S('formatTime')))));
      else if (date.isYesterday())
        div.appendChild(this.Design.generateLocation($L('Yesterday')+" "+$S('dateDivider')+' '+((Settings.useRelative)?date.relative():date.format($S('formatTime')))));
      else
        div.appendChild(this.Design.generateLocation(date.format($S('formatDate'))+" "+$S('dateDivider')+' '+((Settings.useRelative)?date.relative():date.format($S('formatTime')))));
			
		}
		
		this.Design.appendCustom(div);
		
		if(this.nowExpand) {
      this.Design.appendCustom('. . .','expand');
		  
      this.setToggle();
		}
	}
	
	return true;
};


Controller.registerPlugin(CallsVoice);
