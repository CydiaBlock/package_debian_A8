if(!Settings['com.havrest.lockinfo.VoicemailPlugin'])
  Settings['com.havrest.lockinfo.VoicemailPlugin'] = {};

Settings['com.havrest.lockinfo.VoicemailPlugin'] = Object.extend({
  
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  //Max number of missed calls show folded
  maxVoicemail: 3,
  
  //Max number of missed calls show unfolded
  //Set to 0 for no limit
  maxVoicemailExpanded: 0,
  
  groupVoicemails: true,
}, Settings['com.havrest.lockinfo.VoicemailPlugin']);
