
if(!It)
  var It = new Language('it');

It.setString("New SMS (plural)","Nuovi SMS");
It.setString("New SMS","Nuovo SMS"); //Text displayed in the topbar of SMS
