﻿
if(!Fi)
	var Fi = new Language('fi');

Fi.setString("New SMS","Uusi tekstiviesti");
Fi.setString("New SMS (plural)","Uusia tekstiviestejä");
