
if(!Vi)
  var Vi = new Language('vi');

Vi.setString("New SMS","Tinnhắn mới");
