
if(!Pl)
  var Pl = new Language('pl');

Pl.setString("New SMS (plural)","Nowe sms");
Pl.setString("New SMS","Nowych wiadomości SMS"); //Text displayed in the topbar of SMS
