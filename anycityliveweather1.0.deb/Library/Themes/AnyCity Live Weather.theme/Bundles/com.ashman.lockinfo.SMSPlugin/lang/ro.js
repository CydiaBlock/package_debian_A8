
if(!Ro)
  var Ro = new Language('ro');

Ro.setString("New SMS","Mesaje noi"); //Text displayed in the topbar of SMS
Ro.setString("New SMS (plural)","SMS-uri nou");
