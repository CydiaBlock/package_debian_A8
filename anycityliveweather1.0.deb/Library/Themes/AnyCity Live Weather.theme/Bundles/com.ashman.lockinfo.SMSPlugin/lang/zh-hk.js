﻿
if(!ZhHk)
	var ZhHk = new Language('zh-hk');

ZhHk.setString("New SMS","新短訊");
ZhHk.setString("New SMS (plural)","新短訊");
