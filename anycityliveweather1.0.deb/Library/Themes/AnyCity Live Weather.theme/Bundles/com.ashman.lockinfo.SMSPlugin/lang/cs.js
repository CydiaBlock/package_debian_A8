if(!Cs)
  var Cs = new Language('cs');

Cs.setString("New SMS","Nová SMS"); //Text displayed in the topbar of SMS
