
if(!Ja)
	var Ja = new Language('ja');

Ja.setString("New SMS","新着SMS");
Ja.setString("New SMS (plural)","新着SMS");
