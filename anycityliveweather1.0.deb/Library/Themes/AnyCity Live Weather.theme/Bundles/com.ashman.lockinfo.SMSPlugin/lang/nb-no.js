
if(!NbNo)
  var NbNo = new Language('nb-no');

NbNo.setString("New SMS","Ny SMS");
NbNo.setString("New SMS (plural)","Nye SMSer");
