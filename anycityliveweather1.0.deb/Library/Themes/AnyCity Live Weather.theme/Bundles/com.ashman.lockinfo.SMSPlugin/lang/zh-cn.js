
if(!ZhCn)
  var ZhCn = new Language('zh-cn');

ZhCn.setString("New SMS","新到短信"); //Text displayed in the topbar of SMS
ZhCn.setString("New SMS (plural)","新短信");
