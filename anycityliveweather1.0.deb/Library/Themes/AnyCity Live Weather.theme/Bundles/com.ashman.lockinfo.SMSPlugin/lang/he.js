
if(!He)
	var He = new Language('he');

He.setString("New SMS","הודעת טקסט חדשה");
He.setString("New SMS (plural)","הודעות טקסט חדשות");
