
if(!Nl)
  var Nl = new Language('nl');

Nl.setString("New SMS (plural)","Nieuwe SMS berichten");
Nl.setString("New SMS","Nieuwe SMS"); //Text displayed in the topbar of SMS
