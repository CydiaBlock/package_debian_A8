
if(!Pt)
  var Pt = new Language('pt');

Pt.setString("New SMS","Novas SMS"); //Text displayed in the topbar of SMS
Pt.setString("New SMS (plural)","Novas SMS");
