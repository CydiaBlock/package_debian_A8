
if(!El)
	var El = new Language('el');

El.setString("New SMS","Νέο μήνυμα");
El.setString("New SMS (plural)","Νέα μηνύματα");
