
if(!Fr)
  var Fr = new Language('fr');

//desc:Sms
Fr.setString("New SMS","Nouveau SMS ");
Fr.setString("New SMS (plural)","Nouveaux SMS "); //Text displayed in the topbar of SMS
