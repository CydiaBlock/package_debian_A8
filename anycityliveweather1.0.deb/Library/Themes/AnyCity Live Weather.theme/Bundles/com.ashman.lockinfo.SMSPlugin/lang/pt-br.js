
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("New SMS","Nova SMS");
PtBr.setString("New SMS (plural)","Novas SMS");
