
if(!De)
  var De = new Language('de');

De.setString("New SMS (plural)","Neue SMS");
De.setString("New SMS","Neue SMS"); //Text displayed in the topbar of SMS
