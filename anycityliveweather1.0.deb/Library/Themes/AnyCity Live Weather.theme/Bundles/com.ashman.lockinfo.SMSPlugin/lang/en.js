
if(!En)
  var En = new Language('en');

En.setString('New SMS (plural)', 'New SMS');
