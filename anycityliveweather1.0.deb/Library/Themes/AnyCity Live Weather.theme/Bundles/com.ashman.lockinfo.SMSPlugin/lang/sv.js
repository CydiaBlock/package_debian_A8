
if(!Sv)
  var Sv = new Language('sv');

Sv.setString("New SMS","Nytt SMS");
Sv.setString("New SMS (plural)","Nya SMS");
