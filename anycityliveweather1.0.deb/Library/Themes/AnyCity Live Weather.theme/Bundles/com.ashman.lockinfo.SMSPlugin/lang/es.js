
if(!Es)
  var Es = new Language('es');

Es.setString("New SMS (plural)","Nuevos SMS");
Es.setString("New SMS","Nuevo SMS"); //Text displayed in the topbar of SMS
