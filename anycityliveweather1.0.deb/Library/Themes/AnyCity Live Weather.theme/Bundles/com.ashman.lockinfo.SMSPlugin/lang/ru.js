
if(!Ru)
	var Ru = new Language('ru');

Ru.setString("New SMS","Новое сообщение");
Ru.setString("New SMS (plural)","Новых сообщений");
