/*

  MobileSMS plugin
  
    Show unread SMS
    
*/
var Sms = new Plugin('com.ashman.lockinfo.SMSPlugin');

Sms.short = 'sms';
Sms.bundleIdentifier = 'com.ashman.lockinfo.SMSPlugin';

Sms.preload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.overrideMimeType("text/xml");
  
  xmlReq.open("GET", 'li://com.ashman.lockinfo.SMSPlugin/updateView',true);
  
  xmlReq.setRequestHeader("Cache-Control", "no-cache");
  xmlReq.send(null);
};

Sms.callback = function(data) {
  this.Design.clean();
  
  this.nowExpand = false;
  var msgs = data.messages;
  var currentDate;
  if (msgs.length > 0) {
    var maxNb = ((this.Settings.maxExpanded == 0)?msgs.length:this.Settings.maxExpanded);
    var countStr = ((maxNb < msgs.length)?maxNb+'/'+msgs.length:msgs.length);
    
    var div = this.Design.generateCustom('','sms-content','sms');
    
    // Add header 
		div.appendChild(this.Design.generateHeader((Settings.nbBefore)?countStr+' '+((msgs.length > 1)?$L('New SMS (plural)'):$L('New SMS')):((msgs.length > 1)?$L('New SMS (plural)'):$L('New SMS'))+": "+countStr));
		
		for (i = 0; i < msgs.length && i < maxNb; i++) {
		  
		  if((i >= this.Settings.maxFolded) && (!this.nowExpand)) {
        this.Design.appendCustom(div);
        div = div.appendChild(this.Design.generateCustom('','sms-content','sms-expand'));
        div.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';
        
        this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
        this.nowExpand = true;
      }
      var sum = this.Design.generateSummary(msgs[i].text,(i == 0 ? " firstItem" : ""));
      sum.onclick = function(e){ var t=this.getDimensions().height; toggleClassName(this,'readSMS'); if(t != this.getDimensions().height) e.stopPropagation();};
			div.appendChild(sum);
			div.appendChild(this.Design.generateLocation(msgs[i].sender));
		}
		
		this.Design.appendCustom(div);
		
		if(this.nowExpand) {
      this.Design.appendCustom('. . .','expand');
      this.expandable = 'sms-expand';
      
      this.setToggle();
		}
	}
	
	return true;
};

Controller.registerPlugin(Sms);
