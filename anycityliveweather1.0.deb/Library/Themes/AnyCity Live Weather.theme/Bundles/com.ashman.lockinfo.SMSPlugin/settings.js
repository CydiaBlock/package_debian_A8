if(!Settings['com.ashman.lockinfo.SMSPlugin'])
  Settings['com.ashman.lockinfo.SMSPlugin'] = {};

Settings['com.ashman.lockinfo.SMSPlugin'] = Object.extend({
  
  // Enable/Disable Expansion
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  //Max number of sms show folded
  maxFolded: 3,
  
  //Max number of sms show unfolded
  //Set to 0 for no limit
  maxExpanded: 10,
}, Settings['com.ashman.lockinfo.SMSPlugin']);
