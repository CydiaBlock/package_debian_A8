
/*

  MobilePhone plugin
  
    Show Missed Calls and Voicemails
    
*/

CallsPhone = new Plugin('com.ashman.lockinfo.PhonePlugin')

CallsPhone.short = 'calls:phone';
CallsPhone.bundleIdentifier = 'com.ashman.lockinfo.PhonePlugin';

CallsPhone.preload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.overrideMimeType("text/xml");
  
  xmlReq.open("GET", 'li://com.ashman.lockinfo.PhonePlugin/updateView',true);
  
  xmlReq.setRequestHeader("Cache-Control", "no-cache");
  xmlReq.send(null);
};

CallsPhone.callback = function(data) {
  if (data.calls)
    this.callback_phone(data);
  
  return true;
};

CallsPhone.callback_phone = function(data) {
  
  this.Design.clean();
  this.nowExpand = false;
  
  var calls = data.calls;
  var currentDate;
  if (calls.length > 0) {
    var maxExpanded = ((this.Settings.maxCallsExpanded == 0)?calls.length:this.Settings.maxCallsExpanded);
	  var countStr = ((maxExpanded < calls.length)?maxExpanded+'/'+calls.length:calls.length);
	  
    var div = this.Design.generateCustom('','calls-content','calls');
    
    // Add Missed calls header
    div.appendChild(this.Design.generateHeader((Settings.nbBefore)?countStr+' '+((calls.length > 1)?$L('Missed Calls'):$L('Missed Call')):((calls.length > 1)?$L('Missed Calls'):$L('Missed Call'))+': '+countStr,'calls'));
    
    for (i = 0; i < calls.length && i < maxExpanded; i++) {
      
      //Create the hidden div if over limit
      if((i >= this.Settings.maxCalls) && (!this.nowExpand)) {
        this.Design.appendCustom(div);
        div = div.appendChild(this.Design.generateCustom('','calls-content','calls-expand'));
        div.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';
        this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
        this.nowExpand = true;
      }
      
      
      //Add Date
      date = new Date();
      date.setTime(calls[i].date);
      
      if ((!this.Settings.groupCalls) && (currentDate == null || date.isDifferentDay(currentDate))) {
        if(date.isToday())
          div.appendChild(this.Design.generateHeader($L('Today'), 'dayHeader'));
        else if(date.isYesterday())
          div.appendChild(this.Design.generateHeader($L('Yesterday'), 'dayHeader'));
        else
          div.appendChild(this.Design.generateHeader(date.format($S('longDate')), 'dayHeader'));
        
        currentDate = date;
      }
      
      //Adding Caller name
      if (calls[i].caller == "Unknown")
        var callerName = $L('Unknown');
      else
        var callerName = calls[i].caller;
      
      div.appendChild(this.Design.generateSummary(callerName,(i == 0 ? "firstItem" : "")));
      
      if(!this.Settings.groupCalls)
        div.appendChild(this.Design.generateLocation((Settings.useRelative)?date.relative():date.format($S('formatTime'))));
      else if (date.isToday())
        div.appendChild(this.Design.generateLocation($L('Today')+" "+$S('dateDivider')+' '+((Settings.useRelative)?date.relative():date.format($S('formatTime')))));
      else if (date.isYesterday())
        div.appendChild(this.Design.generateLocation($L('Yesterday')+" "+$S('dateDivider')+' '+((Settings.useRelative)?date.relative():date.format($S('formatTime')))));
      else
        div.appendChild(this.Design.generateLocation(date.format($S('formatDate'))+" "+$S('dateDivider')+' '+((Settings.useRelative)?date.relative():date.format($S('formatTime')))));
    }
    
    this.Design.appendCustom(div);
    
    if(this.nowExpand) {
      this.Design.appendCustom('. . .','expand');
      this.expandable = 'calls-expand';
      
      this.setToggle();
		}
  }
  
  return true;
};

Controller.registerPlugin(CallsPhone);
