
if(!He)
  var He = new Language('he');

He.setString("Missed Calls","שיחות שלא נענו");
He.setString("Missed Call","שיחה שלא נענתה");
He.setString("Unknown","לא ידוע");
