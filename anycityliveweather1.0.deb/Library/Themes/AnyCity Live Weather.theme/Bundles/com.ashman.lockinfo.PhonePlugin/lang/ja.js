
if(!Ja)
	var Ja = new Language('ja');

Ja.setString("Missed Call","不在着信");
Ja.setString("Missed Calls","不在着信");
Ja.setString("Unknown","非通知着信");
