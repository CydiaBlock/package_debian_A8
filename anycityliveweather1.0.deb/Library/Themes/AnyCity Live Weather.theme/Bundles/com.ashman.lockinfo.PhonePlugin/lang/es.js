
if(!Es)
  var Es = new Language('es');

Es.setString("Missed Call","Llamada Perdida");
Es.setString("Missed Calls","Llamadas Perdidas"); //Text displayed in the topbar of missed calls
Es.setString("Unknown","Desconocido"); //Text displayed for unknown callers
