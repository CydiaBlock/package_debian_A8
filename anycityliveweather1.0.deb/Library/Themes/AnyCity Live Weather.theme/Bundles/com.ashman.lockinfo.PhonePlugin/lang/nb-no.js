
if(!NbNo)
  var NbNo = new Language('nb-no');

NbNo.setString("Missed Call","Ubesvart anrop");
NbNo.setString("Missed Calls","Ubesvarte anrop"); //Text displayed in the topbar of missed calls
NbNo.setString("Unknown","Ukjent"); //Text displayed for unknown callers
