
if(!Fi)
	var Fi = new Language('fi');

Fi.setString("Unknown","Tuntematon");
