
if(!El)
	var El = new Language('el');

El.setString("Missed Call","Αναπάντητη κλήση");
El.setString("Missed Calls","Αναπάντητες κλήσεις");
El.setString("Unknown","Άγνωστος");
