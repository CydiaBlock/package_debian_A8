
if(!De)
  var De = new Language('de');

De.setString("Missed Call","Verpasster Anruf");
De.setString("Missed Calls","Anrufe in Abwesenheit"); //Text displayed in the topbar of missed calls
De.setString("Unknown","Unbekannt");
