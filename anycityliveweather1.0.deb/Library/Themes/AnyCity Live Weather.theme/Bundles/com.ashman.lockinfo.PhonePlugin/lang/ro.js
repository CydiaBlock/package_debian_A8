
if(!Ro)
  var Ro = new Language('ro');

Ro.setString("Missed Call","Apeluri Pierdute");
Ro.setString("Missed Calls","Apeluri pierdute"); //Text displayed in the topbar of missed calls
Ro.setString("Unknown","Necunoscut"); //Text displayed for unknown callers
