
if(!Vi)
  var Vi = new Language('vi');

Vi.setString("Missed Call","Cuộc gọi nhỡ");
