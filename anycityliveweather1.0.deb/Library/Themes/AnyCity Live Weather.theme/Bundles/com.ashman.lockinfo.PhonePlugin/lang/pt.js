
if(!Pt)
  var Pt = new Language('pt');

Pt.setString("Missed Calls","Chamadas perdidas"); //Text displayed in the topbar of missed calls
Pt.setString("Missed Call","Chamada Perdida");
Pt.setString("Unknown","Desconhecido");
