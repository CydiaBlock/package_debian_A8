
if(!It)
  var It = new Language('it');

It.setString("Missed Call","Chiamata Persa");
It.setString("Missed Calls","Chiamate Perse"); //Text displayed in the topbar of missed calls
It.setString("Unknown","Anonimo"); //Text displayed for unknown callers
