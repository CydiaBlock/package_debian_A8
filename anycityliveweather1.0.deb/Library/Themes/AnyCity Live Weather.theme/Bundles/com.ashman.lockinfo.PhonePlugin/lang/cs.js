if(!Cs)
  var Cs = new Language('cs');

Cs.setString("Missed Call","Zmeškané hovory");
Cs.setString("Missed Calls","Zmeškané volání"); //Text displayed in the topbar of missed calls
Cs.setString("Unknown","Neznámý"); //Text displayed for unknown callers
