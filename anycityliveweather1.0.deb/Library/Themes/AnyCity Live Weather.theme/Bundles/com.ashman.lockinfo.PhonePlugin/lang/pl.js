
if(!Pl)
  var Pl = new Language('pl');

Pl.setString("Missed Call","Nieodebrane Połączenia");
Pl.setString("Missed Calls","Nieodebranych połączeń"); //Text displayed in the topbar of missed calls
Pl.setString("Unknown","Nieznany"); //Text displayed for unknown callers
