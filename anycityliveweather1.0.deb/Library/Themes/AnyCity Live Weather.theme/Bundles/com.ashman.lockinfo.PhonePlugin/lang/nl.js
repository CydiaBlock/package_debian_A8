
if(!Nl)
  var Nl = new Language('nl');

Nl.setString("Missed Call","Gemiste oproep");
Nl.setString("Missed Calls","Gemiste Oproepen");
Nl.setString("Unknown","Onbekend"); //Text displayed for unknown callers
