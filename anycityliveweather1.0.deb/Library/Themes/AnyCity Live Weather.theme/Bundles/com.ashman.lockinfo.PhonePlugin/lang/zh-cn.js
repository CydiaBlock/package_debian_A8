
if(!ZhCn)
  var ZhCn = new Language('zh-cn');

ZhCn.setString("Missed Calls","未接来电"); //Text displayed in the topbar of missed calls
ZhCn.setString("Missed Call","未接电话");
ZhCn.setString("Unknown","未知联系人"); //Text displayed for unknown callers
