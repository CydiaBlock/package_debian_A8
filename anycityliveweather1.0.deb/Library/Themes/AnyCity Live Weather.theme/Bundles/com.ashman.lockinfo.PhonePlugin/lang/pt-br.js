
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("Unknown","Desconhecido");
PtBr.setString("Missed Call","Chamada perdida");
