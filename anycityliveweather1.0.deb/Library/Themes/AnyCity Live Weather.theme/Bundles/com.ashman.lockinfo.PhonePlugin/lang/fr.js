
if(!Fr)
  var Fr = new Language('fr');

//desc:Calls
Fr.setString("Missed Call","Appel manqué ");
Fr.setString("Missed Calls","Appels manqués "); //Text displayed in the topbar of missed calls
Fr.setString("Unknown","Masqué"); //Text displayed for unknown callers
