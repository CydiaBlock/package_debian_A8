
if(!Tr)
	var Tr = new Language('tr');

Tr.setString("Missed Call","Cevapsız Çağrı");
Tr.setString("Missed Calls","Cevapsız Çağrılar");
Tr.setString("Unknown","Bilinmeyen");
