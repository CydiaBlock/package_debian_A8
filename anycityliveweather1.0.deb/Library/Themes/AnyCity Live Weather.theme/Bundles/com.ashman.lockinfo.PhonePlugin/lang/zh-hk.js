﻿
if(!ZhHk)
	var ZhHk = new Language('zh-hk');

ZhHk.setString("Missed Call","未接來電");
ZhHk.setString("Missed Calls","未接來電");
ZhHk.setString("Unknown","没有來電顯示");
