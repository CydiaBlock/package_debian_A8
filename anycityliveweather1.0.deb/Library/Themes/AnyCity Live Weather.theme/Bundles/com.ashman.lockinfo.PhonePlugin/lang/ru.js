
if(!Ru)
  var Ru = new Language('ru');

Ru.setString("Missed Call","Пропущенный звонок");
Ru.setString("Missed Calls","Пропущенных звонков");
Ru.setString("Unknown","Неизвестный");
