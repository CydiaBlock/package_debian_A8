
if(!Settings['com.ashman.lockinfo.PhonePlugin'])
  Settings['com.ashman.lockinfo.PhonePlugin'] = {};

Settings['com.ashman.lockinfo.PhonePlugin'] = Object.extend({

  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  //Max number of missed calls show folded
  maxCalls: 3,
  
  //Max number of missed calls show unfolded
  //Set to 0 for no limit
  maxCallsExpanded: 0,
  
  groupCalls: true,
}, Settings['com.ashman.lockinfo.PhonePlugin']);

