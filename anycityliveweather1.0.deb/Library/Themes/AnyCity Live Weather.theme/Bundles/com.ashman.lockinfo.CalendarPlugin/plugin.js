/*

  MobileCal plugin
  
    Show upcoming events
    
*/

var Cal = new Plugin('com.ashman.lockinfo.CalendarPlugin');

Cal.short = 'cal';
Cal.bundleIdentifier = 'com.ashman.lockinfo.CalendarPlugin';

Cal.preload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.overrideMimeType("text/xml");
  
  xmlReq.open("GET", 'li://com.ashman.lockinfo.CalendarPlugin/updateView',true);
  
  xmlReq.setRequestHeader("Cache-Control", "no-cache");
  xmlReq.send(null);
};

Cal.callback = function(data) {
  
  this.Design.clean();
  
  var currentDate;
  this.nowExpand = false;
	var todays_date=new Date();
  
	
  var ul = this.Design.appendCustom('','calendar-items');
	
  var events = data.events;
	if (events.length > 0) {
    var maxNb = ((this.Settings.maxCalCountExpanded == 0)?events.length:this.Settings.maxCalCountExpanded);
    
    var calendars = [];
    var eventsHead = false;
    for (i = 0; i < events.length && i < maxNb; i++) {
      var start = new Date();
      start.setTime(events[i].start);
			
      var end = new Date();
      end.setTime(events[i].end);
      
      if(calendars.indexOf(events[i].calendar) == -1)
        var calIndex = calendars.push(events[i].calendar)-1;
      else
        var calIndex = calendars.indexOf(events[i].calendar);
      
        /*
          Adding header
            - Upcoming if groupEvents enabled
            - Day header else
        */
        if (currentDate == null || start.isDifferentDay(currentDate)) {
          if(((this.Settings.groupEvents) && (currentDate == null)) || ((this.Settings.maxCalCountMini == 0) && (currentDate == null)) || ((i == 0) && (!start.isWithinDays(this.Settings.showEventsForDaysMini)))) {
            
            if(this.Settings.maxCalCountMini == 0) {
              var nbTotal = 0; var nbToday = 0;
              for(j=0; j < events.length && j < maxNb; j++) {
                var start2 = new Date();
                start2.setTime(events[j].start);
          			
                var end2 = new Date();
                end2.setTime(events[j].end);
                
                if((start2.getTime()<todays_date.getTime()) && ((!start2.isToday()) || (end2.getTime()<todays_date.getTime())))
                  continue ;
                
                nbTotal++;
                if(start2.isToday())
                  nbToday++;
              }
              
              ul.appendChild(this.Design.generateHeader($L('Upcoming Events')+' '+nbTotal+' '+((nbToday > 0)?'('+nbToday+')':'')));
            }
            else
              ul.appendChild(this.Design.generateHeader($L('Upcoming Events')));
            
            eventsHead = true;
          }
          
				  
          if (!this.Settings.groupEvents) {
            if((i >= this.Settings.maxCalCountMini || !start.isWithinDays(this.Settings.showEventsForDaysMini)) && (!this.nowExpand)) {
              this.Design.appendCustom(ul);
              ul = ul.appendChild(this.Design.generateCustom('','','cal-expand'));
              ul.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';;
              this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
              this.nowExpand = true;
            }
            
            if(start.isToday())
              ul.appendChild(this.Design.generateHeader($L('Today'), (currentDate == null && !eventsHead)?'':'dayHeader'));
            else if(start.isTomorrow())
              ul.appendChild(this.Design.generateHeader($L('Tomorrow'), (currentDate == null && !eventsHead)?'':'dayHeader'));
            else
              ul.appendChild(this.Design.generateHeader(start.format($S('longDate')), (currentDate == null && !eventsHead)?'':'dayHeader'));
          }
          
          currentDate = start;
				}
				
				
				/*
				  Switch to hidden div if over folded limit
				*/
				if((i >= this.Settings.maxCalCountMini || !start.isWithinDays(this.Settings.showEventsForDaysMini)) && (!this.nowExpand)) {
  			  this.Design.appendCustom(ul);
  			  ul = ul.appendChild(this.Design.generateCustom('','','cal-expand'));
  			  ul.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';
          this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
  			  this.nowExpand = true;
        }
				
				
				/*
				  Birthday detection
				*/
        var pattern = "\\b(birthday|anniversary|"+$S('birthdayCheck')+")\\b";
        var modele = new RegExp(pattern, "i");
        
        var birthday = false; 
        if(modele.test((events[i].summary + '').toLowerCase()))
          birthday = true;
				
				
				
				/*
				  Adding events class name depending on duration
				   - All Day event  : allDayEvent
				   - <= 1 hour      : less1hEvent
				   - <= 1 day       : less1dEvent
				   - >  1 day       : more1dEvent
				   
				   - end time <= 1h : willExpire
				   currentEvent
				*/
        var className = [];
        
        if(birthday && this.Settings.showBirthdays)
          className.push('birthday');
        
        var classEvent = 'more1dEvent'
        if(events[i].allDay)
		      classEvent = 'allDayEvent';
		    else if(end.getTime()-start.getTime() <= 3600*1000)
		      classEvent = 'less1hEvent';
		    else if(end.getTime()-start.getTime() <= 24*3600*1000)
		      classEvent = 'less1dEvent';
		    
		    className.push(classEvent);
		    
		    if(!events[i].allDay && start.getTime() < todays_date.getTime())
		      className.push('currentEvent');
		    
		    if((end.getTime() != start.getTime()) && (todays_date.getTime()-end.getTime() <= 3600*1000))
		      className.push('willExpire');
				
				//Add calendar index
				className.push('calendar'+calIndex);
				
				//Event name
				ul.appendChild(this.Design.generateSummary(document.createTextNode(events[i].summary.truncate()), ((i == 0)?className.concat(['firstItem']):className) ));
				
				
				// Event date (if !groupEvents), start-end time and location
        var line2 = "";
        
        if (events[i].allDay == 1){
          if(!this.Settings.groupEvents)
            line2 += $L('All Day');
          else if (start.isToday())
            line2 += $L('Today')+" "+$S('dateDivider')+" "+$L('All Day');
          else if (start.isTomorrow())
            line2 += $L('Tomorrow')+" "+$S('dateDivider')+" "+$L('All Day');
          else
            line2 += start.format($S('formatDate'))+" "+$S('dateDivider')+" "+$L('All Day');
				}
        else {
          if(!this.Settings.groupEvents)
            line2 += start.format($S('formatTime'));
          else if (start.isToday())
            line2 += $L('Today')+" "+$S('dateDivider')+" "+ start.format($S('formatTime'));
          else if (start.isTomorrow())
            line2 += $L('Tomorrow')+" "+$S('dateDivider')+" "+ start.format($S('formatTime'));
          else
            line2 += start.format($S('formatDate'))+" "+$S('dateDivider')+" "+ start.format($S('formatTime'));
          
					if (start.getTime() != end.getTime() ||
						start.getMonth() != end.getMonth() ||
						start.getFullYear() != end.getFullYear())
            line2 += "-"+end.format($S('formatTime'));
        }
        
        if(Settings.useRelative && start.getTime()>todays_date.getTime() && !(start.isTomorrow() && Math.abs(start.getTime()-todays_date.getTime()) > 24*3600*1000))
          line2 += ' ('+start.relative()+')';
        
        var temp = document.createDocumentFragment();
        
        var tt = document.createElement('span')
        tt.className = 'calTime';
        tt.innerHTML = line2.truncate(120);
        
        temp.appendChild(tt);
        
        
        if(events[i].location) {
  				var span = document.createElement('span');
  				span.className = 'calLocation';
  				 var t = document.createElement('span');
           t.appendChild(document.createTextNode(events[i].location))
  				span.appendChild(t);
  				temp.appendChild(span);
				}        
        
        ul.appendChild(this.Design.generateLocation(temp, className));
    }
    
    if(this.nowExpand) {
      this.Design.appendCustom('. . .','expand');
      this.expandable = 'cal-expand';
      this.setToggle();
    }
  }
  
  return true;
};

Controller.registerPlugin(Cal);
