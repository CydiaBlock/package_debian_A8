
if(!Vi)
  var Vi = new Language('vi');

Vi.setString("Upcoming Events","Sự kiện mới");
Vi.setString("birthdayCheck","Ngáy sinh nhật");
