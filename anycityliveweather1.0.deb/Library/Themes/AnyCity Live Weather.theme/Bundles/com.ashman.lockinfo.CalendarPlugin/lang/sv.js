
if(!Sv)
  var Sv = new Language('sv');

Sv.setString("Upcoming Events","Kommande Händelser");
Sv.setString("birthdayCheck","födelsedag");
