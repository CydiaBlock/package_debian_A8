
if(!Pl)
  var Pl = new Language('pl');

Pl.setString("Upcoming Events","Nadchodzących wydarzeń"); //Text displayed in the topbar of the calendar
Pl.setSymbol("birthdayCheck","urodziny|rocznica"); //Text to search for birthday display. It's not case sensitive (if more than one separate with vertical bar | (Alt Gr + 6) )
