﻿
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("Upcoming Events","Próximas Eventos");
