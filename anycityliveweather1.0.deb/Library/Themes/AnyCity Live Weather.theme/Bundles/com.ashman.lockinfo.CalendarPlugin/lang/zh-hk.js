﻿
if(!ZhHk)
	var ZhHk = new Language('zh-hk');

ZhHk.setString("Upcoming Events","即將發生的事項");
ZhHk.setSymbol("birthdayCheck","搜索生日");
