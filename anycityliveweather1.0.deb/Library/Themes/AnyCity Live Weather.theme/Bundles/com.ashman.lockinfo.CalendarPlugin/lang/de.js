
if(!De)
  var De = new Language('de');

De.setString("Upcoming Events","Anstehende Termine"); //Text displayed in the topbar of the calendar
De.setSymbol("birthdayCheck","geburtstag"); //Text to search for birthday display. It's not case sensitive (if more than one separate with vertical bar | (Alt Gr + 6) )
