
if(!Zh)
  var Zh = new Language('zh');

Zh.setString("Upcoming Events","待办事宜"); //Text displayed in the topbar of the calendar
Zh.setSymbol("birthdayCheck","生日|周年纪念"); //Text to search for birthday display. It's not case sensitive (if more than one separate with vertical bar | (Alt Gr + 6) )
