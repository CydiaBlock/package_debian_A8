
if(!Ro)
  var Ro = new Language('ro');

Ro.setString("Upcoming Events","Evenimente noi"); //Text displayed in the topbar of the calendar
Ro.setSymbol("birthdayCheck","anniversare|zi de nastere"); //Text to search for birthday display. It's not case sensitive (if more than one separate with vertical bar | (Alt Gr + 6) )
