
if(!El)
	var El = new Language('el');

El.setString("Upcoming Events","Προσεχώς...");
