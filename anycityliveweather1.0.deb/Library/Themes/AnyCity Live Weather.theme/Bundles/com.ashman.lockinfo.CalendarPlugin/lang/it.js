
if(!It)
  var It = new Language('it');

It.setString("Upcoming Events","Agenda"); //Text displayed in the topbar of the calendar
It.setSymbol("birthdayCheck","compleanno|anniversario|compleanni|anniversari"); //Text to search for birthday display. It's not case sensitive (if more than one separate with vertical bar | (Alt Gr + 6) )
