
if(!He)
	var He = new Language('he');

He.setString("Upcoming Events","ארועים קרובים");
