
if(!Fr)
  var Fr = new Language('fr');

//desc:Calendar
Fr.setString("Upcoming Events","Prochains événements :"); //Text displayed in the topbar of the calendar
Fr.setSymbol("birthdayCheck","anniversaire|fête"); //@desc:Text to search for birthday display. It's not case sensitive - if more than one word (or word group) separate them with vertical bar <b>|</b> (Alt Gr + 6)
