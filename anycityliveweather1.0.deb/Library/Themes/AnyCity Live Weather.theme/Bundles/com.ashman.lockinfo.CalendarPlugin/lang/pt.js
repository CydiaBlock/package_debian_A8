
if(!Pt)
  var Pt = new Language('pt');

Pt.setString("Upcoming Events","Próximos Eventos"); //Text displayed in the topbar of the calendar
