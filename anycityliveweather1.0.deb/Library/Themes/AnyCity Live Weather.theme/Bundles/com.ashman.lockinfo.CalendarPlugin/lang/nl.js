
if(!Nl)
  var Nl = new Language('nl');

Nl.setString("Upcoming Events","Agenda"); //Text displayed in the topbar of the calendar
Nl.setString("birthdayCheck","verjaardag");
