
if(!Ja)
	var Ja = new Language('ja');

Ja.setString("Upcoming Events","今後の予定");
Ja.setSymbol("birthdayCheck","誕生日");
