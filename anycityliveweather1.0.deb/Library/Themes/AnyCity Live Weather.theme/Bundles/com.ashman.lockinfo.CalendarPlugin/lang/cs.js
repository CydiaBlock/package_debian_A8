if(!Cs)
  var Cs = new Language('cs');

Cs.setString("Upcoming Events","Agenda"); //Text displayed in the topbar of the calendar
Cs.setSymbol("birthdayCheck","narozeniny|výročí"); //Text to search for birthday display. It's not case sensitive (if more than one separate with vertical bar | (Alt Gr + 6) )
