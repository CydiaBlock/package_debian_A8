
if(!Ru)
  var Ru = new Language('ru');

Ru.setString("Upcoming Events","Предстоящие события");
Ru.setString("birthdayCheck","День рождения");
