if(!Settings['com.ashman.lockinfo.CalendarPlugin'])
  Settings['com.ashman.lockinfo.CalendarPlugin'] = {};

Settings['com.ashman.lockinfo.CalendarPlugin'] = Object.extend({

  // Enable/Disable Expansion
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  // Group events under an unique header (if disabled : a header per day)
  groupEvents: false,
  
  // Nb of next days displayed folded
  showEventsForDaysMini: 1,
  
  // Max Nb of events to display folded
  maxCalCountMini: 3,
  
  // Max Nb of events to display unfolded (0 = no limit)
  maxCalCountExpanded: 0,
  
  // Add a specific icon for birthdays (automatic detection)
  showBirthdays: true,
},Settings['com.ashman.lockinfo.CalendarPlugin']);
