
var Fr = new Language('fr');

Fr.setString("News Feeds:","Actualité :");
