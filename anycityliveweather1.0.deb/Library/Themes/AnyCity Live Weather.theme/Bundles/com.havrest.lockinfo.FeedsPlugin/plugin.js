
var Feeds = new Plugin('com.havrest.lockinfo.FeedsPlugin');

Feeds.short = 'feeds';
Feeds.urls = '';
Feeds.expandable = 'Feeds';

Feeds.preload = function() {
  
  var urls = [];
  
  if(this.Settings.url1 != '')
    urls.push(this.Settings.url1);
  
  if(this.Settings.url2 != '')
    urls.push(this.Settings.url2);
  
  if(this.Settings.url3 != '')
    urls.push(this.Settings.url3);
  
  if(this.Settings.url4 != '')
    urls.push(this.Settings.url4);
  
  if(this.Settings.url5 != '')
    urls.push(this.Settings.url5);
  
  this.urls = urls.join(',');
  
  if(this.urls != '')
    this.reload();
};

Feeds.reload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.onreadystatechange = (function(e) { this.dealWithJSON(xmlReq); }).bind(this);
  xmlReq.timeout = 2000;
  xmlReq.open("GET", "http://pipes.yahoo.com/pipes/pipe.run?_id=3pGubTlf3hG78OOowmH_9A&_render=json&limit="+this.Settings.itemsLimit+"&urls="+encodeURIComponent(this.urls), true);
  xmlReq.send(null);
};

Feeds.dealWithJSON = function(req) {
  
  if(req.readyState != 4)
    return ;
  
  if(req.responseText.length > 0) {
    var feed = eval('(' + req.responseText + ')');
    var items = feed.value.items;
    
    this.Design.clean();
    
    if(items.length == 0)
      return ;
    
    this.Design.appendHeader($L('News Feeds:')+' '+items.length);
    
    if(!this.$('Feeds')) {
	    var FeedsItems = this.Design.appendCustom('','Feeds','Feeds');
  	    
      this.Design.appendCustom('. . .','expand');
      this.setToggle();
      
      FeedsItems.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';
      this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
	  }
	  else
	    var FeedsItems = this.$('Feeds');
    
    for(var i=0; i<items.length; i++) {
      FeedsItems.appendChild(this.Design.generateSummary(items[i].title));
      FeedsItems.appendChild(this.Design.generateLocation(new Date(parseInt(items[i]['y:published'].utime)*1000).relative()));
    }
    
  }
  
  Controller.addTimeout({callback: this.reload.bind(this), length: 60*1000*this.Settings.updateInterval});
};

Controller.registerPlugin(Feeds);
