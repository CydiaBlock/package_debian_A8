
if(!Settings['com.havrest.lockinfo.FeedsPlugin'])
  Settings['com.havrest.lockinfo.FeedsPlugin'] = {};

Settings['com.havrest.lockinfo.FeedsPlugin'] = Object.extend({

  // Enable/Disable Expansion
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  itemsLimit: 10,
  
  url1: '',
  
  url2: '',
  
  url3: '',
  
  url4: '',
  
  url5: '',
  
  updateInterval: 15
  
},Settings['com.havrest.lockinfo.FeedsPlugin']);
