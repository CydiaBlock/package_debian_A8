
var Pl = new Language('pl');

//desc:General Strings
Pl.setString("All Day","Całodniowe"); //Text displayed for "all day" events
Pl.setString("Today","Dzisiaj"); //Text displayed instead of today's date
Pl.setString("Tomorrow","Jutro"); //Text displayed instead of tomorrow's date
Pl.setString("Yesterday","Wczoraj");


//desc:Day and Month formatting
Pl.setString("Jan","Sty");
Pl.setString("Feb","Lut");
Pl.setString("Mar","Mar");
Pl.setString("Apr","Kwi");
Pl.setSymbol("May_short","Maj");
Pl.setString("Jun","Cze");
Pl.setString("Jul","Lip");
Pl.setString("Aug","Sie");
Pl.setString("Sep","Wrz");
Pl.setString("Oct","Paź");
Pl.setString("Nov","Lis");
Pl.setString("Dec","Gru");

Pl.setString("January","Stycznia");
Pl.setString("February","Lutego");
Pl.setString("March","Marca");
Pl.setString("April","Kwietnia");
Pl.setString("May","Maj");
Pl.setString("June","Czerwca");
Pl.setString("July","Lipca");
Pl.setString("August","Sierpnia");
Pl.setString("September","Września");
Pl.setString("October","Października");
Pl.setString("November","Listopada");
Pl.setString("December","Grudnia");


Pl.setString("Mon","Pn");
Pl.setString("Tue","Wt");
Pl.setString("Wed","Śr");
Pl.setString("Thu","Czw");
Pl.setString("Fri","Pt");
Pl.setString("Sat","So");
Pl.setString("Sun","Ndz");

Pl.setString("Monday","Poniedziałek");
Pl.setString("Tuesday","Wtorek");
Pl.setString("Wednesday","Środa");
Pl.setString("Thursday","Czwartek");
Pl.setString("Friday","Piątek");
Pl.setString("Saturday","Sobota");
Pl.setString("Sunday","Niedziela");


//desc:General symbols
Pl.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
Pl.setSymbol('longDate',"l, d F"); // Date used for long display (Calendar header by example)
Pl.setSymbol('formatDate',"D, d/m"); // Date used for most functions
Pl.setSymbol('formatTime',"G:i"); // Time used for most functions
Pl.setString("seconds","sekund");
Pl.setString("second","sekunda");
Pl.setString("minutes","minut");
Pl.setString("minute","minuta");
Pl.setString("hours","godzin");
Pl.setString("hour","godzina");
Pl.setString("days","dni");
Pl.setString("day","dzień");
Pl.setString("weeks","tygodnie");
Pl.setString("week","tydzien");
Pl.setString("months","miesięcy");
Pl.setString("month","miesiąc");
Pl.setString("year","rok");
Pl.setString("years","lat");
Pl.setSymbol("inBefore","za");
Pl.setSymbol("agoAfter","temu");
Pl.setSymbol("agoBefore","");
Pl.setSymbol("inAfter","");
Pl.setString("Just now","teraz");
Pl.setString("In few minutes","za kilka minut");
Pl.setString("Few minutes ago","kilka minut temu");
Pl.setString("Next week","w przyszłym tygodniu");
Pl.setString("Last week","w zeszłym tygodniu");
Pl.setString("Next month","w przyszłym miesiącu");
Pl.setString("Last month","w zeszłym miesiącu");
Pl.setString("Next year","w przyszłym roku");
Pl.setString("Last year","poprzedniego roku");
