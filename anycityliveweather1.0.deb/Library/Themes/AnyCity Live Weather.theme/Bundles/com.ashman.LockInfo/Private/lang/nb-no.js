
var NbNo = new Language('nb-no');

//desc:General Strings
NbNo.setString("All Day","Hele dagen"); //Text displayed for "all day" events
NbNo.setString("Today","I dag"); //Text displayed instead of today's date
NbNo.setString("Tomorrow","I morgen"); //Text displayed instead of tomorrow's date
NbNo.setString("Yesterday","I går");


//desc:Day and Month formatting
NbNo.setString("Jan","jan");
NbNo.setString("Feb","feb");
NbNo.setString("Mar","mar");
NbNo.setString("Apr","apr");
NbNo.setSymbol("May_short","mai");
NbNo.setString("Jun","jun");
NbNo.setString("Jul","jul");
NbNo.setString("Aug","aug");
NbNo.setString("Sep","sep");
NbNo.setString("Oct","okt");
NbNo.setString("Nov","nov");
NbNo.setString("Dec","des");

NbNo.setString("January","januar");
NbNo.setString("February","februar");
NbNo.setString("March","mars");
NbNo.setString("April","april");
NbNo.setString("May","mai");
NbNo.setString("June","juni");
NbNo.setString("July","juli");
NbNo.setString("August","august");
NbNo.setString("September","september");
NbNo.setString("October","oktober");
NbNo.setString("November","november");
NbNo.setString("December","desember");


NbNo.setString("Mon","man");
NbNo.setString("Tue","tir");
NbNo.setString("Wed","ons");
NbNo.setString("Thu","tor");
NbNo.setString("Fri","fre");
NbNo.setString("Sat","lør");
NbNo.setString("Sun","søn");

NbNo.setString("Monday","Mandag");
NbNo.setString("Tuesday","Tirsdag");
NbNo.setString("Wednesday","Onsdag");
NbNo.setString("Thursday","Torsdag");
NbNo.setString("Friday","Fredag");
NbNo.setString("Saturday","Lørdag");
NbNo.setString("Sunday","Søndag");

//desc:General symbols
NbNo.setSymbol('dateDivider', '-'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
NbNo.setSymbol('longDate',"l, d. F"); // Date used for long display (Calendar header by example)
NbNo.setSymbol('formatDate',"D, d/m"); // Date used for most functions
NbNo.setSymbol('formatTime',"G:i"); // Time used for most functions
NbNo.setString("seconds","sekunder");
NbNo.setString("second","sekund");
NbNo.setString("minutes","minutter");
NbNo.setString("minute","minutt");
NbNo.setString("hours","timer");
NbNo.setString("hour","time");
NbNo.setString("days","dager");
NbNo.setString("day","dag");
NbNo.setString("weeks","uker");
NbNo.setString("week","uke");
NbNo.setString("months","måneder");
NbNo.setString("month","måned");
NbNo.setString("year","år");
NbNo.setString("years","år");
NbNo.setSymbol("agoBefore","");
NbNo.setSymbol("agoAfter","siden");
NbNo.setSymbol("inBefore","Om");
NbNo.setSymbol("inAfter","");
NbNo.setString("Just now","Akkurat nå");
NbNo.setString("In few minutes","Om noen minutter");
NbNo.setString("Few minutes ago","Noen minutter siden");
NbNo.setString("Next week","Neste uke");
NbNo.setString("Last week","Forrige uke");
NbNo.setString("Next year","Neste år");
NbNo.setString("Last year","I fjor");
NbNo.setString("Next month","Neste måned");
NbNo.setString("Last month","Forrige måned");
