
var Nl = new Language('nl');

//desc:General Strings
Nl.setString("All Day","Hele Dag"); //Text displayed for "all day" events
Nl.setString("Today","Vandaag"); //Text displayed instead of today's date
Nl.setString("Tomorrow","Morgen"); //Text displayed instead of tomorrow's date
Nl.setString("Yesterday","Gisteren");


//desc:Day and Month formatting
Nl.setString("Jan","jan");
Nl.setString("Feb","feb");
Nl.setString("Mar","mrt");
Nl.setString("Apr","apr");
Nl.setSymbol("May_short","mei");
Nl.setString("Jun","jun");
Nl.setString("Jul","jul");
Nl.setString("Aug","aug");
Nl.setString("Sep","sep");
Nl.setString("Oct","okt");
Nl.setString("Nov","nov");
Nl.setString("Dec","dec");

Nl.setString("January","januari");
Nl.setString("February","februari");
Nl.setString("March","maart");
Nl.setString("April","april");
Nl.setString("May","mei");
Nl.setString("June","juni");
Nl.setString("July","juli");
Nl.setString("August","augustus");
Nl.setString("September","september");
Nl.setString("October","oktober");
Nl.setString("November","november");
Nl.setString("December","december");


Nl.setString("Mon","ma");
Nl.setString("Tue","di");
Nl.setString("Wed","wo");
Nl.setString("Thu","do");
Nl.setString("Fri","vr");
Nl.setString("Sat","za");
Nl.setString("Sun","zo");

Nl.setString("Monday","maandag");
Nl.setString("Tuesday","dinsdag");
Nl.setString("Wednesday","woensdag");
Nl.setString("Thursday","donderdag");
Nl.setString("Friday","vrijdag");
Nl.setString("Saturday","zaterdag");
Nl.setString("Sunday","zondag");


//desc:General symbols
Nl.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
Nl.setSymbol('formatDate',"D, d/m"); // Date used for most functions
Nl.setSymbol('formatTime',"G:i"); // Time used for most functions
Nl.setSymbol("longDate","l, j F");
Nl.setString("seconds","seconden");
Nl.setString("second","seconde");
Nl.setString("minutes","minuten");
Nl.setString("minute","minuut");
Nl.setString("hours","uren");
Nl.setString("hour","uur");
Nl.setString("days","dagen");
Nl.setString("day","dag");
Nl.setString("weeks","weken");
Nl.setString("week","week");
Nl.setString("months","maanden");
Nl.setString("month","maan");
Nl.setString("year","jaar");
Nl.setString("years","jaren");
Nl.setSymbol("inBefore","over");
Nl.setSymbol("agoBefore","");
Nl.setSymbol("agoAfter","geleden");
Nl.setString("Just now","nu");
Nl.setString("In few minutes","straks");
Nl.setString("Few minutes ago","paar minuten geleden");
Nl.setString("Next week","Volgende week");
Nl.setString("Last week","Afgelopen week");
Nl.setString("Next month","Volgende maand");
Nl.setString("Last month","Afgelopen maand");
Nl.setString("Next year","Volgend jaar");
Nl.setString("Last year","Afgelopen jaar");
