﻿
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("All Day","Dia todo");
PtBr.setString("Today","Hoje");
PtBr.setString("Tomorrow","Amanhã");
PtBr.setString("Yesterday","Ontem");

PtBr.setString("Jan","Jan");
PtBr.setString("Feb","Fev");
PtBr.setString("Mar","Mar");
PtBr.setString("Apr","Abr");
PtBr.setString("May_short","Mai");
PtBr.setString("Jun","Jun");
PtBr.setString("Jul","Jul");
PtBr.setString("Aug","Ago");
PtBr.setString("Sep","Set");
PtBr.setString("Oct","Out");
PtBr.setString("Nov","Nov");
PtBr.setString("Dec","Dez");

PtBr.setString("January","Janeiro");
PtBr.setString("February","Fevereiro");
PtBr.setString("March","Março");
PtBr.setString("April","Abril");
PtBr.setString("June","Junho");
PtBr.setString("July","Julho");
PtBr.setString("August","Agosto");
PtBr.setString("September","Setembro");
PtBr.setString("October","Outubro");
PtBr.setString("November","Novembro");
PtBr.setString("December","Dezembro");

PtBr.setString("Mon","Seg");
PtBr.setString("Tue","Ter");
PtBr.setString("Wed","Qua");
PtBr.setString("Thu","Qui");
PtBr.setString("Fri","Sex");
PtBr.setString("Sat","Sáb");
PtBr.setString("Sun","Dom");

PtBr.setString("Monday","Segunda");
PtBr.setString("Tuesday","Terça");
PtBr.setString("Wednesday","Quarta");
PtBr.setString("Thursday","Quinta");
PtBr.setString("Friday","Sexta");
PtBr.setString("Saturday","Sábado");
PtBr.setString("Sunday","Domingo");

PtBr.setSymbol("dateDivider","/");
PtBr.setSymbol("formatTime","G:i");
PtBr.setSymbol("agoBefore","");
PtBr.setSymbol("agoAfter","atrás");
PtBr.setSymbol("inBefore","Em");

PtBr.setString("seconds","segundos");
PtBr.setString("second","segundo");
PtBr.setString("minutes","minutos");
PtBr.setString("minute","minuto");
PtBr.setString("hours","horas");
PtBr.setString("hour","hora");
PtBr.setString("days","dias");
PtBr.setString("day","dia");
PtBr.setString("weeks","semanas");
PtBr.setString("week","semana");
PtBr.setString("months","meses");
PtBr.setString("month","mês");
PtBr.setString("year","ano");
PtBr.setString("years","anos");

PtBr.setString("Next week","próxima semana");
PtBr.setString("Last week","semana passada");
PtBr.setString("Next month","próximo mês");
PtBr.setString("Last month","mês passado");
PtBr.setString("Next year","próximo ano");
PtBr.setString("Last year","ano passado");
PtBr.setString("Just now","Agora");
PtBr.setString("In few minutes","Em alguns minutos");
PtBr.setString("Few minutes ago","Alguns minutos atras");
