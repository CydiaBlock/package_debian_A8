
var It = new Language('it');

//desc:General Strings
It.setString("All Day","Tutto il Giorno"); //Text displayed for "all day" events
It.setString("Today","Oggi"); //Text displayed instead of today's date
It.setString("Tomorrow","Domani"); //Text displayed instead of tomorrow's date
It.setString("Yesterday","Ieri");

//desc:Day and Month formatting
It.setString("Jan","Gen");
It.setString("Feb","Feb");
It.setString("Mar","Mar");
It.setString("Apr","Apr");
It.setSymbol("May_short","Mag");
It.setString("Jun","Giu");
It.setString("Jul","Lug");
It.setString("Aug","Ago");
It.setString("Sep","Set");
It.setString("Oct","Ott");
It.setString("Nov","Nov");
It.setString("Dec","Dic");

It.setString("January","Gennaio");
It.setString("February","Febbraio");
It.setString("March","Marzo");
It.setString("April","Aprile");
It.setString("May","Maggio");
It.setString("June","Giugno");
It.setString("July","Luglio");
It.setString("August","Agosto");
It.setString("September","Settembre");
It.setString("October","Ottobre");
It.setString("November","Novembre");
It.setString("December","Dicembre");


It.setString("Mon","lun");
It.setString("Tue","mar");
It.setString("Wed","mer");
It.setString("Thu","gio");
It.setString("Fri","ven");
It.setString("Sat","sab");
It.setString("Sun","dom");

It.setString("Monday","lunedi");
It.setString("Tuesday","martedi");
It.setString("Wednesday","mercoledi");
It.setString("Thursday","giovedi");
It.setString("Friday","venerdi");
It.setString("Saturday","sabato");
It.setString("Sunday","domenica");


//desc:General symbols
It.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
It.setSymbol('formatDate',"D. j F"); // Date used for most functions
It.setSymbol('formatTime',"G:i"); // Time used for most functions
It.setString("second","Secondo");
It.setString("seconds","Secondi");
It.setString("minutes","Minuti");
It.setString("minute","Minuto");
It.setString("hours","Ore");
It.setString("hour","Ora");
It.setString("days","Giorni");
It.setString("day","Giorno");
It.setString("weeks","Settimane");
It.setString("week","Settimana");  
It.setString("months","Mesi");
It.setString("month","Mese");
It.setString("year","Anno");
It.setString("years","Anni");
It.setString("Just now","Adesso");
It.setString("In few minutes","Fra pochi minuti");
It.setString("Few minutes ago","Alcuni minuti fa");
It.setString("Next week","Prossima settimana");
It.setString("Last week","Settimana scorsa");
It.setString("Next month","Mese prossimo");
It.setString("Last month","Mese scorso");
It.setString("Next year","Prossimo anno");
It.setString("Last year","Scorso anno");
