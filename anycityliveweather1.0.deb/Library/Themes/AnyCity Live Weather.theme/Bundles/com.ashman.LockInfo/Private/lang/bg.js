﻿
if(!Bg)
	var Bg = new Language('bg');

Bg.setString("All Day","Цял ден");
Bg.setString("Today","Днес");
Bg.setString("Tomorrow","Утре");
Bg.setString("Yesterday","Вчера");

Bg.setString("Jan","Януари");
Bg.setString("Feb","Февруари");
Bg.setString("Mar","Март");
Bg.setString("Apr","Април");
Bg.setSymbol("May_short","Май");
Bg.setString("Jun","Юни");
Bg.setString("Jul","Юли");
Bg.setString("Aug","Август");
Bg.setString("Sep","Септември");
Bg.setString("Oct","Октомври");
Bg.setString("Nov","Ноември");
Bg.setString("Dec","Декември");

Bg.setString("seconds","секунди");
Bg.setString("second","секунда");
Bg.setString("minutes","минути");
Bg.setString("minute","минута");
Bg.setString("hours","часа");
Bg.setString("hour","час");
Bg.setString("days","дни");
Bg.setString("day","ден");
Bg.setString("weeks","седмици");
Bg.setString("week","седмица");
Bg.setString("months","месеци");
Bg.setString("month","месец");
Bg.setString("year","година");
Bg.setString("years","години");
Bg.setString("Just now","Току-що");
Bg.setString("In few minutes","След няколко минути");
Bg.setString("Few minutes ago","Преди няколко минути");
Bg.setString("Next week","Следващата седмица");
Bg.setString("Last week","Миналата седмица");
Bg.setString("Next month","Следващият месец");
Bg.setString("Last month","Миналият месец");
Bg.setString("Next year","Следващата година");
Bg.setString("Last year","Миналата година");
