
var Ro = new Language('ro');

//desc:General Strings
Ro.setString("All Day","Toata ziua"); //Text displayed for "all day" events
Ro.setString("Today","Azi"); //Text displayed instead of today's date
Ro.setString("Tomorrow","Maine"); //Text displayed instead of tomorrow's date
Ro.setString("Yesterday","Ieri");


//desc:Day and Month formatting
Ro.setString("Jan","Ian");
Ro.setString("Feb","Feb");
Ro.setString("Mar","Mar");
Ro.setString("Apr","Apr");
Ro.setSymbol("May_short","Mai");
Ro.setString("Jun","Iun");
Ro.setString("Jul","Iul");
Ro.setString("Aug","Aug");
Ro.setString("Sep","Sep");
Ro.setString("Oct","Oct");
Ro.setString("Nov","Nov");
Ro.setString("Dec","Roc");

Ro.setString("January","Ianuarie");
Ro.setString("February","Februarie");
Ro.setString("March","Martie");
Ro.setString("April","Aprilie");
Ro.setString("May","Mai");
Ro.setString("June","Iunie");
Ro.setString("July","Iulie");
Ro.setString("August","August");
Ro.setString("September","Septembrie");
Ro.setString("October","Octombrie");
Ro.setString("November","Noiembrie");
Ro.setString("December","Rocembrie");


Ro.setString("Mon","Lun");
Ro.setString("Tue","Mar");
Ro.setString("Wed","Mie");
Ro.setString("Thu","Joi");
Ro.setString("Fri","Vin");
Ro.setString("Sat","Sam");
Ro.setString("Sun","Dum");

Ro.setString("Monday","Luni");
Ro.setString("Tuesday","Marti");
Ro.setString("Wednesday","Miercuri");
Ro.setString("Thursday","Joi");
Ro.setString("Friday","Vineri");
Ro.setString("Saturday","Sambata");
Ro.setString("Sunday","Duminica");


//desc:General symbols
Ro.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
Ro.setSymbol('longDate',"l, d F"); // Date used for long display (Calendar header by example)
Ro.setSymbol('formatDate',"D, d/m"); // Date used for most functions
Ro.setSymbol('formatTime',"H:i"); // Time used for most functions
Ro.setString("seconds","secunde");
Ro.setString("second","secunda");
Ro.setString("minutes","minute");
Ro.setString("minute","minut");
Ro.setString("hours","ore");
Ro.setString("hour","ora");
Ro.setString("days","zile");
Ro.setString("day","zi");
Ro.setString("weeks","saptamani");
Ro.setString("week","saptamana");
Ro.setString("months","luni");
Ro.setString("month","luna");
Ro.setString("year","an");
Ro.setString("years","ani");
Ro.setString("Just now","chiar acum");
Ro.setString("In few minutes","In cateva minute");
Ro.setString("Few minutes ago","Cateva minute in urma");
Ro.setString("Next week","Saptamna viitoare");
Ro.setString("Last week","Saptamana trecuta");
Ro.setString("Next month","Luna viitoare");
Ro.setString("Last month","Luna trecuta");
Ro.setString("Next year","Anul viitor");
Ro.setString("Last year","Anul trecut");
Ro.setSymbol("inBefore","In");
Ro.setSymbol("inAfter","");
Ro.setSymbol("agoBefore","");
Ro.setSymbol("agoAfter","in urma");    
  
    
  
