
if(!Ja)
	var Ja = new Language('ja');

Ja.setString("All Day","終日");
Ja.setString("Today","今日");
Ja.setString("Tomorrow","明日");
Ja.setString("Yesterday","昨日");

Ja.setString("Jan","1月");
Ja.setString("Feb","2月");
Ja.setString("Mar","3月");
Ja.setString("Apr","4月");
Ja.setString("May_short","5月");
Ja.setString("Jun","6月");
Ja.setString("Jul","7月");
Ja.setString("Aug","8月");
Ja.setString("Sep","9月");
Ja.setString("Oct","10月");
Ja.setString("Nov","11月");
Ja.setString("Dec","12月");

Ja.setString("January","1月");
Ja.setString("February","2月");
Ja.setString("March","3月");
Ja.setString("April","4月");
Ja.setString("June","6月");
Ja.setString("July","7月");
Ja.setString("August","8月");
Ja.setString("September","9月");
Ja.setString("October","10月");
Ja.setString("November","11月");
Ja.setString("December","12月");

Ja.setString("Mon","月");
Ja.setString("Tue","火");
Ja.setString("Wed","水");
Ja.setString("Thu","木");
Ja.setString("Fri","金");
Ja.setString("Sat","土");
Ja.setString("Sun","日");

Ja.setString("Monday","月曜日");
Ja.setString("Tuesday","火曜日");
Ja.setString("Wednesday","水曜日");
Ja.setString("Thursday","木曜日");
Ja.setString("Friday","金曜日");
Ja.setString("Saturday","土曜日");
Ja.setString("Sunday","日曜日");


Ja.setSymbol("dateDivider","　");
Ja.setSymbol("formatDate","m/d (D)");
Ja.setSymbol("formatTime","H:i");
Ja.setSymbol("longDate","l/F/d");

Ja.setSymbol("agoBefore","");
Ja.setSymbol("agoAfter","前");
Ja.setSymbol("inBefore","");
Ja.setSymbol("inAfter","後");

Ja.setString("seconds","秒");
Ja.setString("second","秒");
Ja.setString("minutes","分");
Ja.setString("minute","分");
Ja.setString("hours","時間");
Ja.setString("hour","時間");
Ja.setString("days","日");
Ja.setString("day","日");
Ja.setString("weeks","週間");
Ja.setString("week","週間");
Ja.setString("months","月");
Ja.setString("month","月");
Ja.setString("year","年");
Ja.setString("years","年");
Ja.setString("Just now","今");
Ja.setString("In few minutes","数分後");
Ja.setString("Few minutes ago","数分前");
Ja.setString("Next week","来週");
Ja.setString("Last week","先週");
Ja.setString("Next month","来月");
Ja.setString("Last month","先月");
Ja.setString("Next year","来年");
Ja.setString("Last year","去年");
