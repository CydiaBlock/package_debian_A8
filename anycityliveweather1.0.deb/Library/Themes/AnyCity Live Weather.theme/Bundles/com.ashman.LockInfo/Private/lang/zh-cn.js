
var ZhCn = new Language('zh-cn');

//desc:General Strings
ZhCn.setString("All Day","全天"); //Text displayed for "all day" events
ZhCn.setString("Today","今天"); //Text displayed instead of today's date
ZhCn.setString("Tomorrow","明天"); //Text displayed instead of tomorrow's date
ZhCn.setString("Yesterday","昨天");


//desc:Day and Month formatting
ZhCn.setString("Jan","一月");
ZhCn.setString("Feb","二月");
ZhCn.setString("Mar","三月");
ZhCn.setString("Apr","四月");
ZhCn.setSymbol("May_short","五月");
ZhCn.setString("Jun","六月");
ZhCn.setString("Jul","七月");
ZhCn.setString("Aug","八月");
ZhCn.setString("Sep","九月");
ZhCn.setString("Oct","十月");
ZhCn.setString("Nov","十一月");
ZhCn.setString("Dec","十二月");

ZhCn.setString("January","一月");
ZhCn.setString("February","二月");
ZhCn.setString("March","三月");
ZhCn.setString("April","四月");
ZhCn.setString("May","五月");
ZhCn.setString("June","六月");
ZhCn.setString("July","七月");
ZhCn.setString("August","八月");
ZhCn.setString("September","九月");
ZhCn.setString("October","十月");
ZhCn.setString("November","十一月");
ZhCn.setString("December","十二月");


ZhCn.setString("Mon","周一");
ZhCn.setString("Tue","周二");
ZhCn.setString("Wed","周三");
ZhCn.setString("Thu","周四");
ZhCn.setString("Fri","周五");
ZhCn.setString("Sat","周六");
ZhCn.setString("Sun","周日");

ZhCn.setString("Monday","星期一");
ZhCn.setString("Tuesday","星期二");
ZhCn.setString("Wednesday","星期三");
ZhCn.setString("Thursday","星期四");
ZhCn.setString("Friday","星期五");
ZhCn.setString("Saturday","星期六");
ZhCn.setString("Sunday","星期天");


//desc:General symbols
ZhCn.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
ZhCn.setSymbol('longDate',"l, F dS"); // Date used for long display (Calendar header by example)
ZhCn.setSymbol('formatDate',"D, m/d"); // Date used for most functions
ZhCn.setSymbol('formatTime',"g:ia"); // Time used for most functions
  
ZhCn.setString("seconds","秒");
ZhCn.setString("second","秒");
ZhCn.setString("minutes","分");
ZhCn.setString("minute","分");
ZhCn.setString("hours","小时");
ZhCn.setString("hour","小时");
ZhCn.setString("days","天");
ZhCn.setString("day","天");
ZhCn.setString("weeks","周");
ZhCn.setString("week","周");
ZhCn.setString("months","月");
ZhCn.setString("month","月");
ZhCn.setString("year","年");
ZhCn.setString("years","年");
ZhCn.setString("Just now","当前");
ZhCn.setString("In few minutes","几分钟内");
ZhCn.setString("Few minutes ago","几分钟前");
ZhCn.setString("Next week","下周");
ZhCn.setString("Last week","上周");
ZhCn.setString("Next month","下个月");
ZhCn.setString("Last month","上个月");
ZhCn.setString("Next year","明年");
ZhCn.setString("Last year","去年"); 
