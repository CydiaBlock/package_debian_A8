
if(!Th)
	var Th = new Language('th');

Th.setString("All Day","ทั้งวัน");
Th.setString("Today","วันนี้");
Th.setString("Tomorrow","พรุ่งนี้");
Th.setString("Yesterday","เมื่อวาน");
