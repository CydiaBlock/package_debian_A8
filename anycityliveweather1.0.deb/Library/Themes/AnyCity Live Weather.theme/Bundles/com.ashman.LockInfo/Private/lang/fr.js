
var Fr = new Language('fr');

//desc:General Strings
Fr.setString("All Day","Toute la journée"); //Text displayed for "all day" events
Fr.setString("Today","Aujourd'hui"); //Text displayed instead of today's date
Fr.setString("Tomorrow","Demain"); //Text displayed instead of tomorrow's date
Fr.setString("Yesterday","Hier");

//desc:Day and Month formatting
Fr.setString("Jan","Jan");
Fr.setString("Feb","Fév");
Fr.setString("Mar","Mar");
Fr.setString("Apr","Avr");
Fr.setSymbol("May_short","Mai");
Fr.setString("Jun","Jun");
Fr.setString("Jul","Jul");
Fr.setString("Aug","Aou");
Fr.setString("Sep","Sep");
Fr.setString("Oct","Oct");
Fr.setString("Nov","Nov");
Fr.setString("Dec","Déc");

Fr.setString("January","Janvier");
Fr.setString("February","Février");
Fr.setString("March","Mars");
Fr.setString("April","Avril");
Fr.setString("May","Mai");
Fr.setString("June","Juin");
Fr.setString("July","Juillet");
Fr.setString("August","Août");
Fr.setString("September","Septembre");
Fr.setString("October","Octobre");
Fr.setString("November","Novembre");
Fr.setString("December","Décembre");


Fr.setString("Mon","Lun");
Fr.setString("Tue","Mar");
Fr.setString("Wed","Mer");
Fr.setString("Thu","Jeu");
Fr.setString("Fri","Ven");
Fr.setString("Sat","Sam");
Fr.setString("Sun","Dim");

Fr.setString("Monday","Lundi");
Fr.setString("Tuesday","Mardi");
Fr.setString("Wednesday","Mercredi");
Fr.setString("Thursday","Jeudi");
Fr.setString("Friday","Vendredi");
Fr.setString("Saturday","Samedi");
Fr.setString("Sunday","Dimanche");


//desc:General symbols
Fr.setSymbol('dateDivider', '-'); //@desc:Displayed between Date and Time when in the same line

//desc:Date and timeformats
Fr.setSymbol('longDate',"l d F"); //@descDate used for long display (Calendar header by example)
Fr.setSymbol('formatDate',"D, d/m"); //@desc:Date used for most functions
Fr.setSymbol('formatTime',"H:i"); //@desc:Time used for most functions
Fr.setSymbol('agoBefore','Il y a');//@desc:String before past lengths - <b>Il y a</b> 2 heures - Let empty if not relevant@allowEmpty
Fr.setSymbol('agoAfter','');//@desc:String after past lengths - 2 hours <b>ago</b> - Let empty if not relevant@allowEmpty
Fr.setSymbol('inBefore','Dans');//@desc:String before future lengths - <b>In</b> 2 hours - Let empty if not relevant @allowEmpty
Fr.setSymbol('inAfter','');//@desc:String after future lengths - <em>no example, sorry</em> - Let empty if not relevant@allowEmpty
Fr.setString('seconds','secondes');
Fr.setString('second','seconde');
Fr.setString('minutes','minutes');
Fr.setString('minute','minute');
Fr.setString('hours','heures');
Fr.setString('hour','heure');
Fr.setString('days','jours');
Fr.setString('day','jour');
Fr.setString('weeks','semaines');
Fr.setString('week','semaine');
Fr.setString('months','mois');
Fr.setString('month','mois');
Fr.setString('year','année');
Fr.setString('years','années');
Fr.setString('Just now','À l\'instant');
Fr.setString('In few minutes','Dans quelques minutes');
Fr.setString('Few minutes ago','Il y a quelques minutes');
Fr.setString('Next week','La semaine prochaine');
Fr.setString('Last week','La semaine dernière');
Fr.setString('Next month','Le mois prochain');
Fr.setString('Last month','Le mois dernier');
Fr.setString('Next year','L\'année prochaine');
Fr.setString('Last year','L\'année dernière');
