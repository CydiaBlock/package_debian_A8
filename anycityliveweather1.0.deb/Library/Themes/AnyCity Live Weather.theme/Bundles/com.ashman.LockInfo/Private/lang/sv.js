
var Sv = new Language('sv');

//desc:General Strings
Sv.setString("All Day","Hela Dagen");
Sv.setString("Today","Idag");
Sv.setString("Tomorrow","Imorgon");
Sv.setString("Yesterday","Igår");

//desc:Day and Month formatting
Sv.setString("Feb","Feb");
Sv.setString("Jan","Jan");
Sv.setString("Mar","Mar");
Sv.setString("Apr","Apr");
Sv.setSymbol("May_short","Maj");
Sv.setString("Jun","Jun");
Sv.setString("Jul","Jul");
Sv.setString("Aug","Aug");
Sv.setString("Sep","Sep");
Sv.setString("Oct","Okt");
Sv.setString("Nov","Nov");
Sv.setString("Dec","Dec");

Sv.setString("January","Januari");
Sv.setString("February","Februari");
Sv.setString("March","Mars");
Sv.setString("April","April");
Sv.setString("June","Juni");
Sv.setString("July","Juli");
Sv.setString("August","Augusti");
Sv.setString("September","September");
Sv.setString("October","Oktober");
Sv.setString("November","November");
Sv.setString("December","December");

Sv.setString("Mon","Mån");
Sv.setString("Tue","Tis");
Sv.setString("Wed","Ons");
Sv.setString("Thu","Tors");
Sv.setString("Fri","Fre");
Sv.setString("Sat","Lör");
Sv.setString("Sun","Sön");

Sv.setString("Monday","Måndag");
Sv.setString("Tuesday","Tisdag");
Sv.setString("Wednesday","Onsdag");
Sv.setString("Thursday","Torsdag");
Sv.setString("Friday","Fredag");
Sv.setString("Saturday","Lördag");
Sv.setString("Sunday","Söndag");

Sv.setSymbol("dateDivider","-");
Sv.setSymbol('longDate',"l, d F"); // Date used for long display (Calendar header by example)
Sv.setSymbol('formatDate',"D, d.m"); // Date used for most functions
Sv.setSymbol('formatTime',"H:i"); // Time used for most functions
Sv.setString("seconds","sekunder");
Sv.setString("second","sekund");
Sv.setString("minutes","minuter");
Sv.setString("minute","minut");
Sv.setString("hours","timmar");
Sv.setString("hour","timme");
Sv.setString("days","dagar");
Sv.setString("day","dag");
Sv.setString("weeks","veckor");
Sv.setString("week","vecka");
Sv.setString("Next week","Nästa vecka");
Sv.setString("Next year","Förra året");
Sv.setString("months","månader");
Sv.setString("month","månad");
Sv.setString("year","år");
Sv.setString("years","år");
Sv.setString("In few minutes","om några minuter");
Sv.setString("Few minutes ago","några minuter sen");
Sv.setString("Last week","Förra veckan");
Sv.setString("Next month","Nästa månad");
Sv.setString("Last month","Förra månaden");
Sv.setString("Last year","Förra året");
Sv.setSymbol("agoBefore","");
Sv.setSymbol("agoAfter","sen");
Sv.setSymbol("inBefore","om");
Sv.setSymbol("inAfter","");
Sv.setString("Just now","Just nu");
