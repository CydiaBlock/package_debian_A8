
var De = new Language('de');

//desc:General Strings
De.setString("All Day","Ganztägig"); //Text displayed for "all day" events
De.setString("Today","Heute"); //Text displayed instead of today's date
De.setString("Tomorrow","Morgen"); //Text displayed instead of tomorrow's date
De.setString("Yesterday","Gestern");


//desc:Day and Month formatting
De.setString("Jan","Jan");
De.setString("Feb","Feb");
De.setString("Mar","Mär");
De.setString("Apr","Apr");
De.setSymbol("May_short","Mai");
De.setString("Jun","Jun");
De.setString("Jul","Jul");
De.setString("Aug","Aug");
De.setString("Sep","Sep");
De.setString("Oct","Okt");
De.setString("Nov","Nov");
De.setString("Dec","Dez");

De.setString("January","Januar");
De.setString("February","Februar");
De.setString("March","März");
De.setString("April","April");
De.setString("May","Mai");
De.setString("June","Juni");
De.setString("July","Juli");
De.setString("August","August");
De.setString("September","September");
De.setString("October","Oktober");
De.setString("November","November");
De.setString("December","Dezember");


De.setString("Mon","Mo");
De.setString("Tue","Di");
De.setString("Wed","Mi");
De.setString("Thu","Do");
De.setString("Fri","Fr");
De.setString("Sat","Sa");
De.setString("Sun","So");

De.setString("Monday","Montag");
De.setString("Tuesday","Dienstag");
De.setString("Wednesday","Mittwoch");
De.setString("Thursday","Donnerstag");
De.setString("Friday","Freitag");
De.setString("Saturday","Samstag");
De.setString("Sunday","Sonntag");


//desc:General symbols
De.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
De.setSymbol("longDate","l, d. F");
De.setSymbol("formatDate","D, d.m.");
De.setSymbol('formatTime',"G:i"); // Time used for most functions
De.setString("seconds","Sekunden");
De.setString("second","Sekunde");
De.setString("minutes","Minuten");
De.setString("minute","Minute");
De.setString("hours","Stunden");
De.setString("hour","Stunde");
De.setString("days","Tagen");
De.setString("day","Tag");
De.setString("weeks","Wochen");
De.setString("week","Woche");
De.setString("month","Monat");
De.setString("months","Monate");
De.setString("year","Jahr");
De.setString("years","Jahre");
De.setSymbol("inBefore","in");
De.setSymbol('inAfter','');
De.setSymbol("agoBefore","vor");
De.setSymbol('agoAfter','');
De.setString("Just now","soeben");
De.setString("In few minutes","in wenigen Minuten");
De.setString("Few minutes ago","vor wenigen Minuten");
De.setString("Next week","nächste Woche");
De.setString("Last week","letzte Woche");
De.setString("Next month","nächsten Monat");
De.setString("Last month","letzten Monat");
De.setString("Next year","nächstes Jahr");
De.setString("Last year","letztes Jahr");
