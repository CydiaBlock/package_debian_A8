
var En = new Language('en');

//General Symbols
En.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//Date and timeformats
En.setSymbol("May_short","May");
En.setSymbol('longDate',"l, F dS"); // Date used for long display (Calendar header by example)
En.setSymbol('formatDate',"D, m/d"); // Date used for most functions
En.setSymbol('formatTime',"g:ia"); // Time used for most functions
En.setSymbol('agoBefore','');
En.setSymbol('agoAfter','ago');
En.setSymbol('inBefore','In');
En.setSymbol('inAfter','');
