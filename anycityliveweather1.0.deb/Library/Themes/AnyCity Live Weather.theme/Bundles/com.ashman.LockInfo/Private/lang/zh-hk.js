﻿
if(!ZhHk)
	var ZhHk = new Language('zh-hk');

ZhHk.setString("All Day","全日");
ZhHk.setString("Today","今日");
ZhHk.setString("Tomorrow","明日");
ZhHk.setString("Yesterday","昨天");

ZhHk.setString("Jan","一月");
ZhHk.setString("Feb","二月");
ZhHk.setString("Mar","三月");
ZhHk.setString("Apr","四月");
ZhHk.setString("May_short","五月");
ZhHk.setString("Jun","六月");
ZhHk.setString("Jul","七月");
ZhHk.setString("Aug","八月");
ZhHk.setString("Sep","九月");
ZhHk.setString("Oct","十月");
ZhHk.setString("Nov","十一月");
ZhHk.setString("Dec","十二月");

ZhHk.setString("January","一月");
ZhHk.setString("February","二月");
ZhHk.setString("March","三月");
ZhHk.setString("April","四月");
ZhHk.setString("June","六月");
ZhHk.setString("July","七月");
ZhHk.setString("August","八月");
ZhHk.setString("September","九月");
ZhHk.setString("October","十月");
ZhHk.setString("November","十一月");
ZhHk.setString("December","十二月");

ZhHk.setString("Mon","星期一");
ZhHk.setString("Tue","星期二");
ZhHk.setString("Wed","星期三");
ZhHk.setString("Thu","星期四");
ZhHk.setString("Fri","星期五");
ZhHk.setString("Sat","星期六");
ZhHk.setString("Sun","星期日");

ZhHk.setString("Monday","星期一");
ZhHk.setString("Tuesday","星期二");
ZhHk.setString("Wednesday","星期三");
ZhHk.setString("Thursday","星期四");
ZhHk.setString("Friday","星期五");
ZhHk.setString("Saturday","星期六");
ZhHk.setString("Sunday","星期日");

ZhHk.setSymbol("agoBefore","");

ZhHk.setString("seconds","秒");
ZhHk.setString("second","秒");
ZhHk.setString("minutes","分");
ZhHk.setString("minute","分");
ZhHk.setString("hours","時");
ZhHk.setString("hour","時");
ZhHk.setString("days","日");
ZhHk.setString("day","日");
ZhHk.setString("weeks","周");
ZhHk.setString("week","周");
ZhHk.setString("months","月");
ZhHk.setString("month","月");
ZhHk.setString("year","年");
ZhHk.setString("years","年");

ZhHk.setString("Just now","剛剛");
ZhHk.setString("In few minutes","幾分鐘後");
ZhHk.setString("Few minutes ago","幾分鐘前");

ZhHk.setString("Next week","下星期");
ZhHk.setString("Last week","上星期");
ZhHk.setString("Next month","下個月");
ZhHk.setString("Last month","上個月");
ZhHk.setString("Next year","明年");
ZhHk.setString("Last year","去年");
