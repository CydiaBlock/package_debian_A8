﻿
if(!ArSa)
	var ArSa = new Language('ar-sa');

ArSa.setString("All Day"," كل اليوم");
ArSa.setString("Today","اليوم");
ArSa.setString("Tomorrow","غداً");
ArSa.setString("Yesterday","أمس");
ArSa.setString("Jan","يونيو");
ArSa.setString("Feb","فبراير");
ArSa.setString("Mar","مارس");
