
var El = new Language('el');

El.setString("Today","Σήμερα");
El.setString("Tomorrow","Αύριο");
El.setString("Yesterday","Χθες");

El.setString("Jan","Ιανουάριος");
El.setString("Feb","Φεβρουάριος");
El.setString("Mar","Μάρτιος");
El.setString("Apr","Απρίλιος");
El.setSymbol("May_short","Μάιος");
El.setString("Jun","Ιούνιος");
El.setString("Jul","Ιούλιος");
El.setString("Aug","Αύγουστος");
El.setString("Sep","Σεπτέμβριος");
El.setString("Oct","Οκτώβριος");
El.setString("Nov","Νοέμβριος");
El.setString("Dec","Δεκέμβριος");

El.setString("January","Ιανουάριος");
El.setString("February","Φεβρουάριος");
El.setString("March","Μάρτιος");
El.setString("April","Απρίλιος");
El.setString("June","Ιούνιος");
El.setString("July","Ιούλιος");
El.setString("August","Αύγουστος");
El.setString("September","Σεπτέμβριος");
El.setString("October","Οκτώβριος");
El.setString("November","Νοέμβριος");
El.setString("December","Δεκέμβριος");

El.setString("Mon","ΔΕΥ");
El.setString("Tue","ΤΡΙ");
El.setString("Wed","ΤΕΤ");
El.setString("Thu","ΠΕΜ");
El.setString("Fri","ΠΑΡ");
El.setString("Sat","ΣΑΒ");
El.setString("Sun","ΚΥΡ");

El.setString("Monday","Δευτέρα");
El.setString("Tuesday","Τρίτη");
El.setString("Wednesday","Τετάρτη");
El.setString("Thursday","Πέμπτη");
El.setString("Friday","Παρασκευή");
El.setString("Saturday","Σάββατο");
El.setString("Sunday","Κυριακή");


El.setString("seconds","δευτερόλεπτα");
El.setString("second","δευτερόλεπτο");
El.setString("minutes","λεπτά");
El.setString("minute","λεπτό");
El.setString("hours","ώρες");
El.setString("hour","ώρα");
El.setString("days","ημέρες");
El.setString("day","ημέρα");
El.setString("weeks","εβδομάδες");
El.setString("week","εβδομάδα");
El.setString("months","μήνες");
El.setString("month","μήνας");
El.setString("year","χρόνος");
El.setString("years","χρόνια");
El.setString("Just now","Μόλις τώρα");
El.setString("In few minutes","σε λίγα λεπτά");
El.setString("Few minutes ago","Πριν από λίγο");
El.setString("Next week","Επόμενη εβδομάδα");
El.setString("Last week","Προηγούμενη εβδομάδα");
El.setString("Next month","Επόμενος μήνας");
El.setString("Last month","Προηγούμενος μήνας");
El.setString("Next year","Του χρόνου");
El.setString("Last year","Πέρυσι");
