
Ca = new Language('ca');

Ca.setString("All Day","Tot el dia");
Ca.setString("Today","Avui");
Ca.setString("Tomorrow","Demà");
Ca.setString("Yesterday","Ahir");

Ca.setString("January","Gener");
Ca.setString("February","Febrer");
Ca.setString("March","Març");
Ca.setString("April","Abril");
Ca.setString("June","Juny");
Ca.setString("July","Juliol");
Ca.setString("August","Agost");
Ca.setString("September","Setembre");
Ca.setString("October","Octubre");
Ca.setString("November","Novembre");
Ca.setString("December","Decembre");

Ca.setString("Monday","Dilluns");
Ca.setString("Tuesday","Dimarts");
Ca.setString("Wednesday","Dimecres");
Ca.setString("Thursday","Dijous");
Ca.setString("Friday","Divendres");
Ca.setString("Saturday","Dissabte");
Ca.setString("Sunday","Diumenge");

Ca.setString("seconds","segons");
Ca.setString("second","segon");
Ca.setString("minutes","minuts");
Ca.setString("minute","minut");
Ca.setString("hours","hores");
Ca.setString("hour","hora");
Ca.setString("days","dies");
Ca.setString("day","dia");
Ca.setString("weeks","setmanes");
Ca.setString("week","setmana");
Ca.setString("months","mesos");
Ca.setString("month","mes");
