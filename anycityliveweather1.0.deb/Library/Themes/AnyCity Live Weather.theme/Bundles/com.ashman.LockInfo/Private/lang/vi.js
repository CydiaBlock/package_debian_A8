
var Vi = new Language('vi');

Vi.setString("All Day","Cả ngày");
Vi.setString("Today","Hôm nay");
Vi.setString("Tomorrow","Ngày mai");
Vi.setString("Yesterday","Hôm qua");


Vi.setString("Jan","Tháng 1");
Vi.setString("Feb","Tháng 2");
Vi.setString("Mar","Tháng 3");
Vi.setString("Apr","Tháng 4");
Vi.setSymbol("May_short","Tháng 5");
Vi.setString("Jun","Tháng 6");
Vi.setString("Jul","Tháng 7");
Vi.setString("Aug","Tháng 8");
Vi.setString("Sep","Tháng 9");
Vi.setString("Oct","Tháng 10");
Vi.setString("Nov","Tháng 11");
Vi.setString("Dec","Tháng 12");

Vi.setString("Mon","Thứ 2");
Vi.setString("Tue","Thứ 3");
Vi.setString("Wed","Thứ 4");
Vi.setString("Thu","Thứ 5");
Vi.setString("Fri","Thứ 6");
Vi.setString("Sat","Thứ 7");
Vi.setString("Sun","Chủ nhật");

Vi.setString("seconds","Giây");
Vi.setString("second","Giây");
Vi.setString("minutes","Phút");
Vi.setString("minute","Phút");
Vi.setString("hours","Giờ");
Vi.setString("hour","Giờ");
Vi.setString("days","Ngày");
Vi.setString("day","Ngày");
Vi.setString("weeks","Tuần");
Vi.setString("week","Tuần");
Vi.setString("months","Tháng");
Vi.setString("month","Tháng");
Vi.setString("years","Năm");
Vi.setString("year","Năm");
Vi.setString("Just now","Bây giờ");
Vi.setString("In few minutes","Trong vài phút");
Vi.setString("Few minutes ago","Cách đây vài phút");
Vi.setString("Next week","Tuần tới");
Vi.setString("Last week","Tuần trước");
Vi.setString("Next month","Tháng tới");
Vi.setString("Last month","Tháng trước");
Vi.setString("Next year","Năm tới");
Vi.setString("Last year","Năm ngoái");
