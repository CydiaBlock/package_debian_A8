
if(!Sk)
	var Sk = new Language('sk');

Sk.setString("All Day","Celý deň");
Sk.setString("Today","Dnes");
Sk.setString("Tomorrow","Zajtra");
Sk.setString("Yesterday","Včera");


Sk.setString("Jun","Jún");
Sk.setString("Jul","Júl");
Sk.setString("Oct","Okt");

Sk.setString("January","Január");
Sk.setString("February","Február");
Sk.setString("March","Marec");
Sk.setString("April","Apríl");
Sk.setString("June","Jún");
Sk.setString("July","Júl");
Sk.setString("October","Október");

Sk.setString("Mon","Po");
Sk.setString("Tue","Ut");
Sk.setString("Wed","St");
Sk.setString("Thu","Št");
Sk.setString("Fri","Pi");
Sk.setString("Sat","So");
Sk.setString("Sun","Ne");

Sk.setString("Monday","Pondelok");
Sk.setString("Tuesday","Utorok");
Sk.setString("Wednesday","Streda");
Sk.setString("Thursday","Štvrtok");
Sk.setString("Friday","Piatok");
Sk.setString("Saturday","Sobota");
Sk.setString("Sunday","Nedeľa");
