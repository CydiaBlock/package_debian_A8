
var He = new Language('he');

He.setString("All Day","כל היום");
He.setString("Today","היום");
He.setString("Tomorrow","מחר");
He.setString("Yesterday","אתמול");

He.setString("Jan","ינו");
He.setString("Feb","פבר");
He.setString("Mar","מרץ");
He.setString("Apr","אפר");
He.setString("May_short","מאי");
He.setString("Jun","יונ");
He.setString("Jul","יול");
He.setString("Aug","אוג");
He.setString("Sep","ספט");
He.setString("Oct","אוק");
He.setString("Nov","נוב");
He.setString("Dec","דצמ");

He.setString("January","ינואר");
He.setString("February","פברואר");
He.setString("March","מרץ");
He.setString("April","אפריל");
He.setString("June","יוני");
He.setString("July","יולי");
He.setString("August","אוגוסט");
He.setString("September","ספטמבר");
He.setString("October","אוקטובר");
He.setString("November","נובמבר");
He.setString("December","דצמבר");

He.setString("Mon","שני");
He.setString("Tue","שלישי");
He.setString("Wed","רביעי");
He.setString("Thu","חמישי");
He.setString("Fri","שישי");
He.setString("Sat","שבת");
He.setString("Sun","ראשון");

He.setString("Monday","יום שני");
He.setString("Tuesday","יום שלישי");
He.setString("Wednesday","יום רביעי");
He.setString("Thursday","יום חמישי");
He.setString("Friday","יום שישי");
He.setString("Saturday","יום שבת");
He.setString("Sunday","יום ראשון");

He.setString("seconds","שניות");
He.setString("second","שניה");
He.setString("minutes","דקות");
He.setString("minute","דקה");
He.setString("hours","שעות");
He.setString("hour","שעה");
He.setString("days","ימים");
He.setString("day","יום");
He.setString("weeks","שבועות");
He.setString("week","שבוע");
He.setString("months","חודשים");
He.setString("month","חודש");
He.setString("year","שנה");
He.setString("years","שנים");
He.setString("Just now","הרגע");
He.setString("In few minutes","בעוד מספר דקות");
He.setString("Few minutes ago","לפני מספר דקות");
He.setString("Next week","שבוע הבא");
He.setString("Last week","שבוע קודם");
He.setString("Next month","חודש הבא");
He.setString("Last month","חודש קודם");
He.setString("Next year","שנה הבאה");
He.setString("Last year","שנה קודמת");
