
if(!Hr)
	var Hr = new Language('hr');

Hr.setString("All Day","Cijeli dan");
Hr.setString("Today","Danas");
Hr.setString("Tomorrow","Sutra");
Hr.setString("Yesterday","Jučer");

Hr.setString("Jan","Sij");

Hr.setString("January","Siječanj");
Hr.setString("February","Veljača");
Hr.setString("March","Ožujak");
