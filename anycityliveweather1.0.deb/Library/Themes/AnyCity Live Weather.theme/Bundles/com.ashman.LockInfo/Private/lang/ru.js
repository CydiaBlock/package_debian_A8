
var Ru = new Language('ru');

Ru.setString("All Day","Весь день");
Ru.setString("Today","Сегодня");
Ru.setString("Tomorrow","Завтра");
Ru.setString("Yesterday","Вчера");

Ru.setString("Jan","Янв");
Ru.setString("Feb","Фев");
Ru.setString("Mar","Мар");
Ru.setString("Apr","Апр");
Ru.setSymbol("May_short","Май");
Ru.setString("Jun","Июн");
Ru.setString("Jul","Июл");
Ru.setString("Aug","Авг");
Ru.setString("Sep","Сен");
Ru.setString("Oct","Окт");
Ru.setString("Nov","Ноя");
Ru.setString("Dec","Дек");

Ru.setString("January","Января");
Ru.setString("February","Февраля");
Ru.setString("March","Марта");
Ru.setString("April","Апреля");

Ru.setString("June","Июня");
Ru.setString("July","Июля");
Ru.setString("August","Августа");
Ru.setString("September","Сентября");
Ru.setString("October","Октября");
Ru.setString("November","Ноября");
Ru.setString("December","Декабря");

Ru.setString("Mon","Пнд");
Ru.setString("Tue","Втр");
Ru.setString("Wed","Срд");
Ru.setString("Thu","Чтв");
Ru.setString("Fri","Птн");
Ru.setString("Sat","Сбт");
Ru.setString("Sun","Вск");

Ru.setString("Monday","Понедельник");
Ru.setString("Tuesday","Вторник");
Ru.setString("Wednesday","Среда");
Ru.setString("Thursday","Четверг");
Ru.setString("Friday","Пятница");
Ru.setString("Saturday","Суббота");
Ru.setString("Sunday","Воскресенье");


Ru.setSymbol("dateDivider","|");
Ru.setSymbol("formatDate","l,d F");
Ru.setSymbol("formatTime","G:i");
Ru.setSymbol("agoAfter","назад");
Ru.setSymbol("agoBefore","");
Ru.setSymbol("inBefore","через");
Ru.setSymbol("inAfter","");
Ru.setString("seconds","секунды");
Ru.setString("second","секунда");
Ru.setString("minutes","минуты");
Ru.setString("minute","минута");
Ru.setString("hours","часы");
Ru.setString("hour","час");
Ru.setString("days","дни");
Ru.setString("day","день");
Ru.setString("weeks","недели");
Ru.setString("week","неделя");
Ru.setString("months","месяцев");
Ru.setString("month","месяц");
Ru.setString("year","год");
Ru.setString("years","лет");
Ru.setString("Few minutes ago","несколько минут назад");
Ru.setString("Next week","следующая неделя");
Ru.setString("Next month","следующий месяц");
Ru.setString("Next year","следующий год");
Ru.setString("Last month","предыдущий месяц");
Ru.setString("Last week","предыдущая неделя");
Ru.setString("Last year","В прошлом году");
Ru.setString("Just now","Только что");
Ru.setString("In few minutes","Через несколько минут");
