
if(!Tr)
	var Tr = new Language('tr');

Tr.setString("All Day","Hergün");
Tr.setString("Today","Bugün");
Tr.setString("Tomorrow","Yarın");
Tr.setString("Yesterday","Dün");

Tr.setString("Jan","Oca");
Tr.setString("Feb","Şub");
Tr.setString("Mar","Mar");
Tr.setString("Apr","Nis");
Tr.setString("May_short","May");
Tr.setString("Jun","Haz");
Tr.setString("Jul","Tem");
Tr.setString("Aug","Ağu");
Tr.setString("Sep","Eyl");
Tr.setString("Oct","Eki");
Tr.setString("Nov","Kas");
Tr.setString("Dec","Ara");

Tr.setString("January","Oca");
Tr.setString("February","Şub");
Tr.setString("March","Mar");
Tr.setString("April","Nis");
Tr.setString("June","Haz");
Tr.setString("July","Tem");
Tr.setString("August","Ağu");
Tr.setString("September","Eyl");
Tr.setString("October","Eki");
Tr.setString("November","Kas");
Tr.setString("December","Ara");

Tr.setString("Mon","Pzt");
Tr.setString("Tue","Sal");
Tr.setString("Wed","Çar");
Tr.setString("Thu","Per");
Tr.setString("Fri","Cum");
Tr.setString("Sat","Cmt");
Tr.setString("Sun","Paz");

Tr.setString("Monday","Pazartesi");
Tr.setString("Tuesday","Salı");
Tr.setString("Wednesday","Çarşamba");
Tr.setString("Thursday","Perşembe");
Tr.setString("Friday","Cuma");
Tr.setString("Saturday","Cumartesi");
Tr.setString("Sunday","Pazar");


Tr.setString("seconds","Saniyeler");
Tr.setString("second","Saniye");
Tr.setString("minutes","Dakikalar");
Tr.setString("minute","Dakika");
Tr.setString("hours","Saatler");
Tr.setString("hour","Saat");
Tr.setString("days","Günler");
Tr.setString("day","Gün");
Tr.setString("weeks","Haftalar");
Tr.setString("week","Hafta");
Tr.setString("months","Aylar");
Tr.setString("month","Ay");
Tr.setString("year","Yıl");
Tr.setString("years","Yıllar");
Tr.setString("Just now","Şu Anda");
Tr.setString("Next week","Gelecek Hafta");
Tr.setString("Last week","Geçen Hafta");
Tr.setString("Next month","Gelecek Ay");
Tr.setString("Last month","Geçen Ay");
Tr.setString("Next year","Gelecek Yıl");
Tr.setString("Last year","Geçen Yıl");
