﻿
if(!Fi)
	var Fi = new Language('fi');

Fi.setString("All Day","Koko päivä");
Fi.setString("Today","Tänään");
Fi.setString("Tomorrow","Huomenna");
Fi.setString("Yesterday","Eilen");

Fi.setString("Jan","Tammi");
Fi.setString("Feb","Helmi");
Fi.setString("Mar","Maalis");
Fi.setString("Apr","Huhti");
Fi.setString("May_short","Touko");
Fi.setString("Jun","Kesä");
Fi.setString("Jul","Heinä");
Fi.setString("Aug","Elo");
Fi.setString("Sep","Syys");
Fi.setString("Oct","Loka");
Fi.setString("Nov","Marras");
Fi.setString("Dec","Joulu");

Fi.setString("January","Tammikuu");
Fi.setString("February","Helmikuu");
Fi.setString("March","Maaliskuu");
Fi.setString("April","Huhtikuu");
Fi.setString("June","Kesäkuu");
Fi.setString("July","Heinäkuu");
Fi.setString("August","Elokuu");
Fi.setString("September","Syyskuu");
Fi.setString("October","Lokakuu");
Fi.setString("November","Marraskuu");
Fi.setString("December","Joulukuu");

Fi.setString("Mon","Ma");
Fi.setString("Tue","Ti");
Fi.setString("Wed","Ke");
Fi.setString("Thu","To");
Fi.setString("Fri","Pe");
Fi.setString("Sat","La");
Fi.setString("Sun","Su");

Fi.setString("Monday","Maanantai");
Fi.setString("Tuesday","Tiistai");
Fi.setString("Wednesday","Keskiviikko");
Fi.setString("Thursday","Torstai");
Fi.setString("Friday","Perjantai");
Fi.setString("Saturday","Lauantai");
Fi.setString("Sunday","Sunnuntai");
