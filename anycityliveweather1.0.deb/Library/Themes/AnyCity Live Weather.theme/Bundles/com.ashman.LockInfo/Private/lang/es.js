
var Es = new Language('es');

//desc:General Strings
Es.setString("All Day","Todo el día");
Es.setString("Today","Hoy"); //Text displayed instead of today's date
Es.setString("Tomorrow","Mañana"); //Text displayed instead of tomorrow's date
Es.setString("Yesterday","Ayer");


//desc:Day and Month formatting
Es.setString("Jan","Ene");
Es.setString("Feb","Feb");
Es.setString("Mar","Mar");
Es.setString("Apr","Abr");
Es.setSymbol("May_short","May");
Es.setString("Jun","Jun");
Es.setString("Jul","Jul");
Es.setString("Aug","Ago");
Es.setString("Sep","Sep");
Es.setString("Oct","Oct");
Es.setString("Nov","Nov");
Es.setString("Dec","Dic");

Es.setString("January","de Enero");
Es.setString("February","de Febrero");
Es.setString("March","de Marzo");
Es.setString("April","de Abril");
Es.setString("May","de Mayo");
Es.setString("June","de Junio");
Es.setString("July","de Julio");
Es.setString("August","de Agosto");
Es.setString("September","de Septiembre");
Es.setString("October","de Octubre");
Es.setString("November","de Noviembre");
Es.setString("December","de Diciembre");


Es.setString("Mon","Lun");
Es.setString("Tue","Mar");
Es.setString("Wed","Mié");
Es.setString("Thu","Jue");
Es.setString("Fri","Vie");
Es.setString("Sat","Sab");
Es.setString("Sun","Dom");

Es.setString("Monday","Lunes");
Es.setString("Tuesday","Martes");
Es.setString("Wednesday","Miércoles");
Es.setString("Thursday","Jueves");
Es.setString("Friday","Viernes");
Es.setString("Saturday","Sábado");
Es.setString("Sunday","Domingo");


//desc:General symbols
Es.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
Es.setSymbol('longDate',"l d F"); // Date used for long display (Calendar header by example)
Es.setSymbol('formatDate',"D, j F"); // Date used for most functions
Es.setSymbol('formatTime',"H:i"); // Time used for most functions
Es.setSymbol("inBefore","dentro de");
Es.setSymbol("agoBefore","hace");
Es.setSymbol("agoAfter","");
Es.setSymbol("inAfter","");
Es.setString("year","año");
Es.setString("years","años");
Es.setString("month","mes");
Es.setString("months","meses");
Es.setString("week","semana");
Es.setString("weeks","semanas");
Es.setString("day","día");
Es.setString("days","días");
Es.setString("hour","hora");
Es.setString("hours","horas");
Es.setString("minute","minuto");
Es.setString("minutes","minutos");
Es.setString("second","segundo");
Es.setString("seconds","segundos");
Es.setString("Just now","Ahora");
Es.setString("Last year","El año pasado");
Es.setString("Last month","El mes pasado");
Es.setString("Last week","La semana pasada");
Es.setString("Next week","La próxima semana");
Es.setString("Next month","El próximo mes");
Es.setString("Next year","El próximo año");
Es.setString("Few minutes ago","Hace algunos minutos");
Es.setString("In few minutes","Dentro de algunos minutos");
