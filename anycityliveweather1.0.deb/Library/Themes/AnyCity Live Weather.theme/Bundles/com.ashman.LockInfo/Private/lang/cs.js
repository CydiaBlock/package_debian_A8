
var Cs = new Language('cs');

//desc:General Strings
Cs.setString("All Day","Celý den"); //Text displayed for "all day" events
Cs.setString("Today","Dnes"); //Text displayed instead of today's date
Cs.setString("Tomorrow","Zítra"); //Text displayed instead of tomorrow's date
Cs.setString("Yesterday","Včera");


//desc:Day and Month formatting
Cs.setString("Jan","Led");
Cs.setString("Feb","Úno");
Cs.setString("Mar","Bře");
Cs.setString("Apr","Dub");
Cs.setSymbol("May_short","Kvě");
Cs.setString("Jun","Čer");
Cs.setString("Jul","Črc");
Cs.setString("Aug","Srp");
Cs.setString("Sep","Zář");
Cs.setString("Oct","Říj");
Cs.setString("Nov","Lis");
Cs.setString("Dec","Pro");

Cs.setString("January","Leden");
Cs.setString("February","Únor");
Cs.setString("March","Březen");
Cs.setString("April","Duben");
Cs.setString("May","Květen");
Cs.setString("June","Červen");
Cs.setString("July","Červenec");
Cs.setString("August","Srpen");
Cs.setString("September","Září");
Cs.setString("October","Říjen");
Cs.setString("November","Listopad");
Cs.setString("December","Prosinec");


Cs.setString("Mon","Po");
Cs.setString("Tue","Út");
Cs.setString("Wed","St");
Cs.setString("Thu","Čt");
Cs.setString("Fri","Pá");
Cs.setString("Sat","So");
Cs.setString("Sun","Ne");

Cs.setString("Monday","Pondělí");
Cs.setString("Tuesday","Úterý");
Cs.setString("Wednesday","Středa");
Cs.setString("Thursday","Čtvrtek");
Cs.setString("Friday","Pátek");
Cs.setString("Saturday","Sobota");
Cs.setString("Sunday","Neděle");


//desc:General symbols
Cs.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
Cs.setSymbol('longDate',"l, d. F"); // Date used for long display (Calendar header by example)
Cs.setSymbol('formatDate',"D, d/m"); // Date used for most functions
Cs.setSymbol('formatTime',"G:i"); // Time used for most functions

Cs.setString("seconds","sekundy");
Cs.setString("Next week","Příští týden");
Cs.setString("Last week","Minulý týden");
Cs.setString("Next month","Příští měsíc");
Cs.setString("Last month","Minulý týden");
Cs.setString("Next year","Příští rok");
Cs.setString("Last year","Minulý rok");  
