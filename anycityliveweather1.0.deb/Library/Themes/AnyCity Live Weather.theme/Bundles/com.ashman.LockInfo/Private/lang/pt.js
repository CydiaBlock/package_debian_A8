
var Pt = new Language('pt');

//desc:General Strings
Pt.setString("All Day","Dia inteiro"); //Text displayed for "all day" events
Pt.setString("Today","Hoje"); //Text displayed instead of today's date
Pt.setString("Tomorrow","Amanhã"); //Text displayed instead of tomorrow's date
Pt.setString("Yesterday","Ontem");


//desc:Day and Month formatting
Pt.setString("Jan","Jan");
Pt.setString("Feb","Fev");
Pt.setString("Mar","Mar");
Pt.setString("Apr","Abr");
Pt.setSymbol("May_short","Mai");
Pt.setString("Jun","Jun");
Pt.setString("Jul","Jul");
Pt.setString("Aug","Ago");
Pt.setString("Sep","Set");
Pt.setString("Oct","Out");
Pt.setString("Nov","Nov");
Pt.setString("Dec","Dez");

Pt.setString("January","Janeiro");
Pt.setString("February","Fevereiro");
Pt.setString("March","Março");
Pt.setString("April","Abril");
Pt.setString("May","Maio");
Pt.setString("June","Junho");
Pt.setString("July","Julho");
Pt.setString("August","Agosto");
Pt.setString("September","Setembro");
Pt.setString("October","Outubro");
Pt.setString("November","Novembro");
Pt.setString("December","Dezembro");


Pt.setString("Mon","Seg");
Pt.setString("Tue","Ter");
Pt.setString("Wed","Qua");
Pt.setString("Thu","Qui");
Pt.setString("Fri","Sex");
Pt.setString("Sat","Sáb");
Pt.setString("Sun","Dom");

Pt.setString("Monday","Segunda");
Pt.setString("Tuesday","Terça");
Pt.setString("Wednesday","Quarta");
Pt.setString("Thursday","Quinta");
Pt.setString("Friday","Sexta");
Pt.setString("Saturday","Sábado");
Pt.setString("Sunday","Domingo");


//desc:General symbols
Pt.setSymbol('dateDivider', '|'); //Displayed between Date and Time when in the same line

//desc:Date and timeformats
Pt.setSymbol('formatDate',"D, d/m"); // Date used for most functions
Pt.setSymbol('formatTime',"G:i"); // Time used for most functions
Pt.setSymbol("longDate","l, d \"de\" F \"de\" Y");

Pt.setSymbol("agoAfter","atrás");
Pt.setSymbol("inBefore","dentro de");
Pt.setSymbol("agoBefore","");
Pt.setSymbol("inAfter","");

Pt.setString("seconds","segundos");
Pt.setString("second","segundo");
Pt.setString("minutes","minutos");
Pt.setString("minute","minuto");
Pt.setString("hours","horas");
Pt.setString("hour","hora");
Pt.setString("days","dias");
Pt.setString("day","dia");
Pt.setString("weeks","semanas");
Pt.setString("week","semana");
Pt.setString("months","meses");
Pt.setString("month","mês");
Pt.setString("year","ano");
Pt.setString("years","anos");
Pt.setString("Just now","Agora mesmo");
Pt.setString("In few minutes","Em alguns minutos");
Pt.setString("Few minutes ago","Alguns minutos atrás");
Pt.setString("Next week","próxima semana");
Pt.setString("Last week","semana passada");
Pt.setString("Next month","próximo mês");
Pt.setString("Last month","Ultímo mês");
Pt.setString("Next year","Próximo ano");
Pt.setString("Last year","Último ano");  
