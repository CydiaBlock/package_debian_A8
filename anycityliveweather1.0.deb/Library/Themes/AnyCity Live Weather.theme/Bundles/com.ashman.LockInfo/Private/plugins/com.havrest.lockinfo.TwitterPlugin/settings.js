
if(!Settings['com.havrest.lockinfo.TwitterPlugin'])
  Settings['com.havrest.lockinfo.TwitterPlugin'] = {};

Settings['com.havrest.lockinfo.TwitterPlugin'] = Object.extend({  
  //Allow weather expansion (allow click on it)
  //Allow: allowExpand: true
  //Disallow: allowExpand: false
  username: '',
  
  //Default state: shrinked or stretched
  password: '',
  
  //Use the alternative icon (t)
  altIcon: false,
}, Settings['com.havrest.lockinfo.TwitterPlugin']);


if(!Settings['com.havrest.lockinfo.TwitterPlugin:friends'])
  Settings['com.havrest.lockinfo.TwitterPlugin:friends'] = {};

Settings['com.havrest.lockinfo.TwitterPlugin:friends'] = Object.extend({  
  //Allow weather expansion (allow click on it)
  //Allow: allowExpand: true
  //Disallow: allowExpand: false
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  itemsFrom: 60,
  
  itemsNb: 10,
  
  updateInterval: 15,
}, Settings['com.havrest.lockinfo.TwitterPlugin:friends']);


if(!Settings['com.havrest.lockinfo.TwitterPlugin:mentions'])
  Settings['com.havrest.lockinfo.TwitterPlugin:mentions'] = {};

Settings['com.havrest.lockinfo.TwitterPlugin:mentions'] = Object.extend({  
  //Allow weather expansion (allow click on it)
  //Allow: allowExpand: true
  //Disallow: allowExpand: false
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  itemsFrom: 60,
  
  itemsNb: 10,
  
  updateInterval: 15,
}, Settings['com.havrest.lockinfo.TwitterPlugin:mentions']);


if(!Settings['com.havrest.lockinfo.TwitterPlugin:direct'])
  Settings['com.havrest.lockinfo.TwitterPlugin:direct'] = {};

Settings['com.havrest.lockinfo.TwitterPlugin:direct'] = Object.extend({  
  //Allow weather expansion (allow click on it)
  //Allow: allowExpand: true
  //Disallow: allowExpand: false
  allowExpand: true,
  
  //Default state: shrinked or stretched
  defState: 'shrinked',
  
  itemsFrom: 60,
  
  itemsNb: 10,
  
  updateInterval: 15,
}, Settings['com.havrest.lockinfo.TwitterPlugin:direct']);
