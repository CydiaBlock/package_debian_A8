
if(!Nl)
	var Nl = new Language('nl');

Nl.setString("Twitter - Direct Messages:","Twitter - Berichten:");
Nl.setString("Twitter - Friends Timeline:","Twitter - Vrienden Tijdlijn:");
