

if(!En)
  var En = new Language('en');

En.setString('LGT.RAINSHOWER','Light Rainshower');
