
if(!Pt)
  var Pt = new Language('pt');

Pt.setString("Try a more specific search","Tenta uma pesquisa mais específica");
Pt.setString("Not Found","Não Encontrado");
Pt.setString("No Response","Sem Resposta");
Pt.setString("City not found","Cidade não encontrada");

Pt.setString("FOG","Nevoeiro");
Pt.setString("RAIN","Chuva");

Pt.setString("Last update:","Ultima Actualização");
