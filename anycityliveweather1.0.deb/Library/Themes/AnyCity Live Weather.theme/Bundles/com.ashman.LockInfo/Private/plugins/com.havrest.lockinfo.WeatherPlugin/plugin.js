/*

  Weather plugin
  
    Show current weather and 6 days forecast
    
*/
//console.log('loading weather...');

var Weather = new Plugin('com.havrest.lockinfo.WeatherPlugin');

Weather.short = 'weather';
Weather.expandable = 'Forecast';
Weather.postal = '';
Weather.daysCode = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
Weather.nbTry = 0;
Weather.locale = 0;
Weather.neverUpdated = true;

Weather.preload = function() {
  this.Source.unit = (this.Settings.isCelsius === true || (this.Settings.isCelsius == 'default' && Controller.language.indexOf('en') == -1))?'c':'f';
	this.Source.validateWeatherLocation(escape(this.Settings.locale).replace(/^%u/g, "%"), this.setPostal.bind(this));
};

Weather.setPostal = function(obj) {
  
  if (obj.error == false){
		if(obj.cities.length > 0){
			this.postal = escape(obj.cities[0].zip).replace(/^%u/g, "%");
			this.locale = obj.cities[0].name;
			this.weatherRefresherTemp();
		}else {
		  this.Design.clean();
		  this.Design.appendHeader($L('Not Found'), 'error');
		}
	}
  else {
    this.Design.clean();
    this.Design.appendHeader($L(obj.errorString), 'error');	
		setTimeout('this.Source.validateWeatherLocation(escape(this.Settings.locale).replace(/^%u/g, "%"), this.setPostal.bind(this))', Math.round(1000*60*5));
	}
};

Weather.weatherRefresherTemp = function(manual,e) {
  if(manual) {
    $('mainWeatherIcon').src = 'plugins/com.havrest.lockinfo.WeatherPlugin/ProgressGear_White_small.gif';
    e.stopPropagation();
  }
  
  this.Source.fetchWeatherData(this.dealWithWeather.bind(this),this.postal);
};

Weather.dealWithWeather = function(obj) {
  
	if (obj.error == false) {
	  this.Design.clean();
	  
	  var header = this.Design.generateHeader(''); 
	  
	  var a = document.createElement('a');
	  
	  var icon = document.createElement('img');
	  icon.id = 'mainWeatherIcon';
	  icon.className = 'weatherIcon';
    icon.src="plugins/com.havrest.lockinfo.WeatherPlugin/Icon Sets/"+this.Settings.iconSet+"/"+this.Source.MiniIcons[obj.icon]+this.Settings.iconExt;
    
    if(this.Settings.showUpdateButton) {
      addClassName($('container'),'showRefreshButton');
      icon.onclick = this.weatherRefresherTemp.bind(this,true);
      a.onclick = this.weatherRefresherTemp.bind(this,true);
    }
    
    a.appendChild(icon);
    
    if(this.Settings.showUpdateButton) {    
      var upd = document.createElement('img');
      upd.className = 'updOverlay';
      upd.src = "plugins/com.havrest.lockinfo.WeatherPlugin/refresh.png";
      upd.onclick = this.weatherRefresherTemp.bind(this,true);
      
      a.appendChild(upd);
	  }
	  
	  var city = this.Design.generateCustom(this.locale.toLowerCase(), 'city', null, 'span');
	  city.style.textTransform='capitalize';
	  a.appendChild(city);
	  
    if(this.Settings.useRealFeel == true){
			tempValue = this.convertTemp(obj.realFeel);
		}else{
			tempValue = this.convertTemp(obj.temp)
		}
		
	  a.appendChild(this.Design.generateCustom(tempValue+"°", 'temp', null, 'span'));
	  
	  header.appendChild(a);
				
	  var desc = this.Design.generateCustom($L(obj.description.toUpperCase()).toLowerCase(), 'desc', null, 'span');
	  desc.style.textTransform='capitalize';
	  header.appendChild(desc);
	  
		this.Design.appendCustom(header);
		
		
		lastResults = new Array;
		lastResults[0] = {daycode:obj.daycode, icon:obj.icon, hi:obj.hi, lo:obj.lo, now:obj.temp};
		var c = obj.forecast.length;
		if (c > 6) c = 6; // just to be safe
		var i = 0;
		
		var Forecast = this.Design.appendCustom('','Forecast','Forecast');
		
		if((this.Settings.inlineForecast) || ((c<4) && (this.Settings.autoInline))) {
		  c=((c > this.Settings.inlineLimit)?this.Settings.inlineLimit:c);
		  
  		while (i < c && obj.forecast[i])
  		{
  			var forecast = obj.forecast[i];
  			
  		  if(i == 0 && forecast.daycode != new Date().getDay()) {
  		    i++;
  		    c++;
  		    continue;
  		  }
  		  
  		  var days = document.createElement('div');
  		  days.className = 'dayD';
  		  
        
        var iconD = document.createElement('div');
        iconD.className = 'icon';
        
        var icon = document.createElement('img');
        icon.src = "plugins/com.havrest.lockinfo.WeatherPlugin/Icon Sets/"+this.Settings.iconSet+"/"+this.Source.MiniIcons[forecast.icon]+this.Settings.iconExt;
        
        iconD.appendChild(icon);
        
        days.appendChild(iconD);
        
        var day = document.createElement('div');
        day.className = 'day';
        day.innerText = $L(this.daysCode[forecast.daycode].ucfirst());
        days.appendChild(day);
        
        var desc = document.createElement('div');
        desc.className = 'desc';
        desc.innerText = $L(forecast.description.toUpperCase()).toLowerCase();
        desc.style.textTransform = 'capitalize';
        days.appendChild(desc);
        
        var tempD = document.createElement('div');
        tempD.className = 'temp';
        
        var hi = document.createElement('div');
        hi.className='hi';
        hi.innerText = this.convertTemp(forecast.hi)+"°";
        
        tempD.appendChild(hi);
        
        var low = document.createElement('div');
        low.className='low';
        low.innerText = this.convertTemp(forecast.lo)+"°";
        
        tempD.appendChild(low);
        
        days.appendChild(tempD)
        
        Forecast.appendChild(days);
  			lastResults[i++] = {daycode:forecast.daycode, icon:forecast.icon, hi:forecast.hi, lo:forecast.lo};
  		}
    }
    else {
  		var days = Forecast.appendChild(document.createElement('div'));
  		var icons = Forecast.appendChild(document.createElement('div'));
  		var temps = Forecast.appendChild(document.createElement('div'));
  		
  		while (i < c && obj.forecast[i])
  		{
  			var forecast = obj.forecast[i];
  			
  		  if(i == 0 && forecast.daycode != new Date().getDay()) {
  		    i++;
  		    c++;
  		    continue;
  		  }
        
        var day = document.createElement('div');
        day.className = 'day';
        day.innerText = $L(this.daysCode[forecast.daycode].substring(0,3).toLowerCase().ucfirst()).toUpperCase()
        days.appendChild(day);
        
        var iconD = document.createElement('div');
        iconD.className = 'icon';
        
        var icon = document.createElement('img');
        icon.src = "plugins/com.havrest.lockinfo.WeatherPlugin/Icon Sets/"+this.Settings.iconSet+"/"+this.Source.MiniIcons[forecast.icon]+this.Settings.iconExt;
        
        iconD.appendChild(icon);
        
        icons.appendChild(iconD);
        
        var tempD = document.createElement('div');
        tempD.className = 'temp';
        
        var hi = document.createElement('div');
        hi.className='hi';
        hi.innerText = this.convertTemp(forecast.hi)+"°";
        
        tempD.appendChild(hi);
        
        var low = document.createElement('div');
        low.className='low';
        low.innerText = this.convertTemp(forecast.lo)+"°";
        
        tempD.appendChild(low);
        
        temps.appendChild(tempD)
        
        			
  			lastResults[i++] = {daycode:forecast.daycode, icon:forecast.icon, hi:forecast.hi, lo:forecast.lo};
  		}
  	}
  	
  	this.Design.appendCustom('. . .','expand');
		
		Forecast.style.display = (this.Settings.defState == 'shrinked' && this.neverUpdated || this.neverUpdated !== true && !this.expanded)?'none':'block';
		this.expanded=!(this.Settings.defState == 'shrinked' && this.neverUpdated || this.neverUpdated !== true && !this.expanded);
		
		this.neverUpdated = new Date();
		this.nbTry = 0;
		
		var now = new Date();
		var then = new Date(now.getTime()+60*1000*this.Settings.updateInterval);
		
		if(now.getDate() != then.getDate()) {
		  then.setMilliseconds(0);
      then.setSeconds(0);
      then.setMinutes(0);
      then.setHours(0);
      
		  Controller.addTimeout({callback: this.weatherRefresherTemp.bind(this), date: then});
		}
		else
		  Controller.addTimeout({callback: this.weatherRefresherTemp.bind(this), length: 60*1000*this.Settings.updateInterval});
	}
	else {
	 this.nbTry++;
	 
	 if(this.nbTry > 4 || this.Settings.dontInsist) {
	   this.nbTry = 0;
	   Controller.addTimeout({callback: this.weatherRefresherTemp.bind(this), length: 60*1000*this.Settings.updateInterval});
	 }
	 else
	   Controller.addTimeout({callback: this.weatherRefresherTemp.bind(this), length: 60*1000*2});
	}
	
  if(this.neverUpdated !== true) {
	   if(!this.$('Updated')) {
	     var Updated = this.Design.generateCustom('','Updated','Updated');
	     this.$('Forecast').appendChild(Updated);
	     
	     if(!this.Settings.showLastUpdated)
	       this.$('Updated').style.display = 'none';
	   }
	   else {
	     var Updated = this.$('Updated');
	     Updated.innerHTML = '';
     }
     
     var temp = document.createDocumentFragment();
     
     if(Settings.useRelative) {
      var tt = document.createElement('span');
      tt.innerHTML = this.neverUpdated.relative();
      temp.appendChild(tt);
     }
     else
       temp.appendChild(document.createTextNode(this.neverUpdated.format($S('formatDate'))+' '+$S('dateDivider')+' '+this.neverUpdated.format($S('formatTime'))));
     
	   Updated.appendChild(temp);
  }
};

Weather.convertTemp = function (num)
{
  if(this.Source.innerUnit)
    return num;
  
	if (this.Settings.isCelsius === true || (this.Settings.isCelsius == 'default' && Controller.language.indexOf('en') == -1))
		return Math.round ((num - 32) * 5 / 9);
	else
		return num;
}

Weather.addSource = function(Source) {
  this.Source = Source;
};

addScript('plugins/com.havrest.lockinfo.WeatherPlugin/Sources/'+Weather.Settings.source+'.js',true);

Controller.registerPlugin(Weather);




var Weather1 = new Plugin('com.havrest.lockinfo.WeatherPlugin:1');

Weather1.short = 'weather';
Weather1.expandable = 'Forecast';
Weather1.postal = '';
Weather1.daysCode = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
Weather1.nbTry = 0;
Weather1.locale = 0;
Weather1.neverUpdated = true;

Weather1.preload = function() {
  var locale = this.Settings.locale;
  var defState = this.Settings.defState;
  
  this.Settings = Object.extend({ }, Weather.Settings);
  this.Settings.locale = locale;
  this.Settings.defState = defState;
  
  this.Source = Weather.Source;
	this.Source.validateWeatherLocation(escape(this.Settings.locale).replace(/^%u/g, "%"), Weather.setPostal.bind(this));
};

Weather1.weatherRefresherTemp = function() {
  Weather.Source.fetchWeatherData(Weather.dealWithWeather.bind(this),this.postal);
};

Weather1.convertTemp = Weather.convertTemp;

Controller.registerPlugin(Weather1);




var Weather2 = new Plugin('com.havrest.lockinfo.WeatherPlugin:2');

Weather2.short = 'weather';
Weather2.expandable = 'Forecast';
Weather2.postal = '';
Weather2.daysCode = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
Weather2.nbTry = 0;
Weather2.locale = 0;
Weather2.neverUpdated = true;

Weather2.preload = function() {
  var locale = this.Settings.locale;
  var defState = this.Settings.defState;
  
  this.Settings = Object.extend({ }, Weather.Settings);
  this.Settings.locale = locale;
  this.Settings.defState = defState;
  
  this.Source = Weather.Source;
	this.Source.validateWeatherLocation(escape(this.Settings.locale).replace(/^%u/g, "%"), Weather.setPostal.bind(this));
};

Weather2.weatherRefresherTemp = function() {
  Weather.Source.fetchWeatherData(Weather.dealWithWeather.bind(this),this.postal);
};

Weather2.convertTemp = Weather.convertTemp;

Controller.registerPlugin(Weather2);




var Weather3 = new Plugin('com.havrest.lockinfo.WeatherPlugin:3');

Weather3.short = 'weather';
Weather3.expandable = 'Forecast';
Weather3.postal = '';
Weather3.daysCode = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
Weather3.nbTry = 0;
Weather3.locale = 0;
Weather3.neverUpdated = true;

Weather3.preload = function() {
  var locale = this.Settings.locale;
  var defState = this.Settings.defState;
  
  this.Settings = Object.extend({ }, Weather.Settings);
  this.Settings.locale = locale;
  this.Settings.defState = defState;
  
  this.Source = Weather.Source;
	this.Source.validateWeatherLocation(escape(this.Settings.locale).replace(/^%u/g, "%"), Weather.setPostal.bind(this));
};

Weather3.weatherRefresherTemp = function() {
  Weather.Source.fetchWeatherData(Weather.dealWithWeather.bind(this),this.postal);
};

Weather3.convertTemp = Weather.convertTemp;

Controller.registerPlugin(Weather3);
