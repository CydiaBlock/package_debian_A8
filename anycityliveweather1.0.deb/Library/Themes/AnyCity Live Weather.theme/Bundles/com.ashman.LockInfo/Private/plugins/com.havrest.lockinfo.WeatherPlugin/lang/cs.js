﻿
if(!Cs)
	var Cs = new Language('cs');

Cs.setString("Not Found","Nenalezeno");
Cs.setString("City not found","Město nenalezeno");
Cs.setString("SUNNY","Slunečno");
