
Twitter = new Plugin('com.havrest.lockinfo.TwitterPlugin');
Twitter.preload = function() {
  if(this.Settings.altIcon)
    addClassName($('container'),'altTwitterIcon');
}
Controller.registerPlugin(Twitter);


TwitterFriends = new Plugin('com.havrest.lockinfo.TwitterPlugin:friends');

TwitterFriends.short = 'twitter:friends';
TwitterFriends.lastId = -1;
TwitterFriends.header = false;
TwitterFriends.expandable = 'Tweets';
TwitterFriends.tweets_arr = [];

TwitterFriends.preload = function() {
  this.reload();
};

TwitterFriends.reload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.onreadystatechange = function(e) { TwitterFriends.dealWithJSON(xmlReq); };
  xmlReq.timeout = 2000;
  xmlReq.open("GET", "http://www.twitter.com/statuses/friends_timeline.json?suppress_response_codes=true&count="+this.Settings.itemsNb+((this.lastId == -1)?'':'&since_id='+this.lastId), true);
  xmlReq.setRequestHeader("Authorization", "Basic " + btoa(Twitter.Settings.username + ":" + Twitter.Settings.password));
  xmlReq.send(null);
};

TwitterFriends.dealWithJSON = function(req) {
  
  if(req.readyState != 4)
    return ;
  
  if(req.responseText.length > 0) {
    var twit = eval('(' + req.responseText + ')');
    
    if(!twit.error && twit.length > 0) {
      
      if(!this.header) {
        this.Design.appendHeader($L('Twitter - Friends Timeline:'), ['twitter','friends']);
        this.header = true;
      }
      
      if(!this.$('Tweets')) {
  	    var Tweets = this.Design.appendCustom('','Tweets','Tweets');
    	    
        this.Design.appendCustom('. . .','expand');
        this.setToggle();
        
        Tweets.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';
        this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
  	  }
  	  else
  	    var Tweets = this.$('Tweets');
      
      var add_tweets = document.createDocumentFragment();
      
      var now = new Date();
      
      for(var i=0; i<twit.length; i++) {
        
        var date = new Date(twit[i].created_at);
        
        if((now-date.getTime())/1000 > this.Settings.itemsFrom*60 || this.tweets_arr.indexOf(twit[i].id) != -1)
          continue; 
        
        Controller.addTimeout({callback: (function(id){
            if(!this.$('tw-fr-sum-'+id))
              return true;
            this.$('tw-fr-sum-'+id).parentNode.removeChild(this.$('tw-fr-sum-'+id));
            this.$('tw-fr-loc-'+id).parentNode.removeChild(this.$('tw-fr-loc-'+id));
            if(this.$('Tweets').childNodes.length == 0) {
              this.Design.clean();
              this.header = false;
            }
            }).bind(this,twit[i].id), length: (this.Settings.itemsFrom*60-(now-date.getTime())/1000)*1000});
        
        add_tweets.appendChild(this.Design.generateCustom(this.Design.generateSummary(twit[i].text,['twitter','friends']),null,'tw-fr-sum-'+twit[i].id));
        add_tweets.appendChild(this.Design.generateCustom(this.Design.generateLocation(twit[i].user.screen_name+' - '+date.relative(),['twitter','friends']),null,'tw-fr-loc-'+twit[i].id));
        
        this.tweets_arr.push(twit[i].id);
      }
      
      this.lastId = twit[0].id;
      
      if(Tweets.firstChild)
        Tweets.insertBefore(add_tweets,Tweets.firstChild);
      else
        Tweets.appendChild(add_tweets);
      
      if(Tweets.childNodes.length/2 > this.Settings.itemsNb) {
        for(var i=Tweets.childNodes.length-1; i>=this.Settings.itemsNb*2; i--)
          Tweets.removeChild(Tweets.childNodes[i]);
      }
      
      if(Tweets.childNodes.length == 0) {
        this.Design.clean();
        this.header = false;
      }
    }
    else if(twit.error) {
      this.Design.clean();
      this.Design.appendHeader($L('Twitter - Friends Timeline:')+' '+twit.error, ['twitter','friends','error']);
    }
  }
  
  Controller.addTimeout({callback: this.reload.bind(this), length: 60*1000*this.Settings.updateInterval});
};

Controller.registerPlugin(TwitterFriends);


TwitterMentions = new Plugin('com.havrest.lockinfo.TwitterPlugin:mentions');

TwitterMentions.short = 'twitter:mentions';
TwitterMentions.lastId = -1;
TwitterMentions.header = false;
TwitterMentions.expandable = 'Tweets';
TwitterMentions.tweets_arr = [];

TwitterMentions.preload = function() {
  this.reload();
};

TwitterMentions.reload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.onreadystatechange = function(e) { TwitterMentions.dealWithJSON(xmlReq); };
  xmlReq.timeout = 2000;
  xmlReq.open("GET", "http://twitter.com/statuses/mentions.json?suppress_response_codes=true&count="+this.Settings.itemsNb+((this.lastId == -1)?'':'&since_id='+this.lastId), true);
  xmlReq.setRequestHeader("Authorization", "Basic " + btoa(Twitter.Settings.username + ":" + Twitter.Settings.password));
  xmlReq.send(null);
};

TwitterMentions.dealWithJSON = function(req) {
  
  if(req.readyState != 4)
    return ;
  
  if(req.responseText.length > 0) {
    var twit = eval('(' + req.responseText + ')');
    
    if(!twit.error && twit.length > 0) {
      
      if(!this.header) {
        this.Design.appendHeader($L('Twitter - Mentions:'), ['twitter','mentions']);
        this.header = true;
      }
      
      if(!this.$('Tweets')) {
  	    var Tweets = this.Design.appendCustom('','Tweets','Tweets');
    	    
        this.Design.appendCustom('. . .','expand');
        this.setToggle();
        
        Tweets.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';
        this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
  	  }
  	  else
  	    var Tweets = this.$('Tweets');
      
      var add_tweets = document.createDocumentFragment();
      
      for(var i=0; i<twit.length; i++) {
        var date = new Date(twit[i].created_at);
        
        if((now-date.getTime())/1000 > this.Settings.itemsFrom*60 || this.tweets_arr.indexOf(twit[i].id) != -1)
          continue; 
        
        Controller.addTimeout({callback: (function(id){if(!this.$('tw-fr-sum-'+id)) return true; this.$('tw-fr-sum-'+id).parentNode.removeChild(this.$('tw-fr-sum-'+id)); this.$('tw-fr-loc-'+id).parentNode.removeChild(this.$('tw-fr-loc-'+id));}).bind(this,twit[i].id), length: (this.Settings.itemsFrom*60-(now-date.getTime())/1000)*1000});
        
        add_tweets.appendChild(this.Design.generateCustom(this.Design.generateSummary(twit[i].text,['twitter','mentions']),null,'tw-me-sum-'+twit[i].id));
        add_tweets.appendChild(this.Design.generateCustom(this.Design.generateLocation(twit[i].user.screen_name+' - '+date.relative(),['twitter','mentions']),null,'tw-me-loc-'+twit[i].id));
        
        this.tweets_arr.push(twit[i].id);
      }
      
      this.lastId = twit[0].id;
      
      if(Tweets.firstChild)
        Tweets.insertBefore(add_tweets,Tweets.firstChild);
      else
        Tweets.appendChild(add_tweets);
      
      if(Tweets.childNodes.length/2 > this.Settings.itemsNb) {
        for(var i=Tweets.childNodes.length-1; i>=this.Settings.itemsNb*2; i--)
          Tweets.removeChild(Tweets.childNodes[i]);
      }
      
      if(Tweets.childNodes.length == 0) {
        this.Design.clean();
        this.header = false;
      }
    }
    else if(twit.error) {
      this.Design.clean();
      this.Design.appendHeader($L('Twitter - Mentions:')+' '+twit.error, ['twitter','mentions','error']);
    }
  }
  
  Controller.addTimeout({callback: this.reload.bind(this), length: 60*1000*this.Settings.updateInterval});
};

Controller.registerPlugin(TwitterMentions);



TwitterDirect = new Plugin('com.havrest.lockinfo.TwitterPlugin:direct');

TwitterDirect.short = 'twitter:mentions';
TwitterDirect.lastId = -1;
TwitterDirect.header = false;
TwitterDirect.expandable = 'Tweets';

TwitterDirect.preload = function() {
  this.reload();
};

TwitterDirect.reload = function() {
  var xmlReq = new XMLHttpRequest();
  xmlReq.onreadystatechange = function(e) { TwitterDirect.dealWithJSON(xmlReq); };
  xmlReq.timeout = 2000;
  xmlReq.open("GET", "http://twitter.com/direct_messages.json?suppress_response_codes=true&count="+this.Settings.itemsNb+((this.lastId == -1)?'':'&since_id='+this.lastId), true);
  xmlReq.setRequestHeader("Authorization", "Basic " + btoa(Twitter.Settings.username + ":" + Twitter.Settings.password));
  xmlReq.send(null);
};

TwitterDirect.dealWithJSON = function(req) {
  
  if(req.readyState != 4)
    return ;
  
  if(req.responseText.length > 0) {
    var twit = eval('(' + req.responseText + ')');
    
    if(!twit.error && twit.length > 0) {
      
      if(!this.header) {
        this.Design.appendHeader($L('Twitter - Direct Messages:'), ['twitter','direct']);
        this.header = true;
      }
      
      if(!this.$('Tweets')) {
  	    var Tweets = this.Design.appendCustom('','Tweets','Tweets');
    	    
        this.Design.appendCustom('. . .','expand');
        this.setToggle();
        
        Tweets.style.display = (this.Settings.defState == 'shrinked' && !this.expanded)?'none':'block';
        this.expanded = (!(this.Settings.defState == 'shrinked' && !this.expanded));
  	  }
  	  else
  	    var Tweets = this.$('Tweets');
      
      var add_tweets = document.createDocumentFragment();
      
      for(var i=0; i<twit.length; i++) {
        var date = new Date(twit[i].created_at);
        
        if((now-date.getTime())/1000 > this.Settings.itemsFrom*60 || this.tweets_arr.indexOf(twit[i].id) != -1)
          continue; 
        
        Controller.addTimeout({callback: (function(id){if(!this.$('tw-fr-sum-'+id)) return true; this.$('tw-fr-sum-'+id).parentNode.removeChild(this.$('tw-fr-sum-'+id)); this.$('tw-fr-loc-'+id).parentNode.removeChild(this.$('tw-fr-loc-'+id));}).bind(this,twit[i].id), length: (this.Settings.itemsFrom*60-(now-date.getTime())/1000)*1000});
        
        add_tweets.appendChild(this.Design.generateCustom(this.Design.generateSummary(twit[i].text,['twitter','direct']),null,'tw-di-sum-'+twit[i].id));
        add_tweets.appendChild(this.Design.generateCustom(this.Design.generateLocation(twit[i].user.screen_name+' - '+date.relative(),['twitter','direct']),null,'tw-di-loc-'+twit[i].id));
        
        this.tweets_arr.push(twit[i].id);
      }
      
      this.lastId = twit[0].id;
      
      if(Tweets.firstChild)
        Tweets.insertBefore(add_tweets,Tweets.firstChild);
      else
        Tweets.appendChild(add_tweets);
      
      if(Tweets.childNodes.length/2 > this.Settings.itemsNb) {
        for(var i=Tweets.childNodes.length-1; i>=this.Settings.itemsNb*2; i--)
          Tweets.removeChild(Tweets.childNodes[i]);
      }
      
      if(Tweets.childNodes.length == 0) {
        this.Design.clean();
        this.header = false;
      }
    }
    else if(twit.error) {
      this.Design.clean();
      this.Design.appendHeader($L('Twitter - Direct Messages:')+' '+twit.error, ['twitter','direct','error']);
    }
  }
  
  Controller.addTimeout({callback: this.reload.bind(this), length: 60*1000*this.Settings.updateInterval});
};

Controller.registerPlugin(TwitterDirect);
