
if(!Es)
	var Es = new Language('es');

Es.setString("Twitter - Friends Timeline:","Amigos en Twitter:");
Es.setString("Twitter - Mentions:","Twitter - Menciones:");
Es.setString("Twitter - Direct Messages:","Twitter - Mensajes Directos:");
