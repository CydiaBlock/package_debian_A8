
if(!Vi)
  var Vi = new Language('vi');

Vi.setString("Last update:","Cập nhật lần cuối:");
