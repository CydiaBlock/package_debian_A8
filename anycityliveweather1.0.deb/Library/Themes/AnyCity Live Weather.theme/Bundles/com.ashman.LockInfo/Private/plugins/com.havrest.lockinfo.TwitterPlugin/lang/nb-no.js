
if(!NbNo)
	var NbNo = new Language('nb-no');

NbNo.setString("Twitter - Friends Timeline:","Twitter - Tidslinje:");
NbNo.setString("Twitter - Mentions:","Twitter - Meninger:");
NbNo.setString("Twitter - Direct Messages:","Twitter - Direktemeldinger:");
