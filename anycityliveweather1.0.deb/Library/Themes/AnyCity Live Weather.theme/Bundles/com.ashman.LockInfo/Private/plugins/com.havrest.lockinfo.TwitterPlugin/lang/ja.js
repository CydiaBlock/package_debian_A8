
if(!Ja)
	var Ja = new Language('ja');

Ja.setString("Twitter - Friends Timeline:","Twitter - タイムライン");
Ja.setString("Twitter - Mentions:","Twitter - 返信");
Ja.setString("Twitter - Direct Messages:","Twitter - ダイレクトメッセージ");
