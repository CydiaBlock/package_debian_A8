
if(!De)
  var De = new Language('de');

De.setString("Twitter - Friends Timeline:","Kontaktverlauf:");
De.setString("Twitter - Mentions:","Bemerkungen:");
De.setString("Twitter - Direct Messages:","Direkte Nachricht:");
