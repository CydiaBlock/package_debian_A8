
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("Twitter - Friends Timeline:","Twitter - Timeline:");
PtBr.setString("Twitter - Mentions:","Twitter - @:");
PtBr.setString("Twitter - Direct Messages:","Twitter - Directs:");
