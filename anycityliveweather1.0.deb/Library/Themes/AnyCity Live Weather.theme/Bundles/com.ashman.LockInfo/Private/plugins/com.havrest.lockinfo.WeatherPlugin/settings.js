if(!Settings['com.havrest.lockinfo.WeatherPlugin'])
  Settings['com.havrest.lockinfo.WeatherPlugin'] = {};

Settings['com.havrest.lockinfo.WeatherPlugin'] = Object.extend({

  //Allow weather expansion (allow click on it)
  //Allow: allowExpand: true
  //Disallow: allowExpand: false
  allowExpand: true,
  
  //Set the default state of weather. A small bar (shrinked) or the forecast displayed (stretched)
  //Small bar: defState: 'shrinked'
  //Forecast visible: defState: 'stretched'
  //If allowExpand is set to false, you won't be able to change this state clicking on the weather bar
  defState: 'stretched',
  
  //The location you want see the weather
  
  //If you use Apple source, you can just type your city name with your state or country as "Cupertino, CA"
  //If it says "Not Found", use this method:
  //To search locale code to use with the Apple source got to this url replacing YOURCITY by the name of your city and state or country
  //http://apple.accuweather.com/adcbin/apple/Apple_find_city.asp?location=YOURCITY
  //(For example http://apple.accuweather.com/adcbin/apple/Apple_find_city.asp?location=Cupertino, CA)
  //Then copy the postal of your city and paste it here (you might to do view source in order to see this)
	//<location city="Cupertino" state="CA" postal="95014"/>
  //Here the postal is 95014
  
  //If you use Yahoo source, search your city here :http://weather.yahoo.com
  //Go to its page and copy the code from its url:
  //http://weather.yahoo.com/forecast/USCA0273.html
  //Here the code is : USCA0273
  locale: "Cupertino, CA",
  
  //Use Celsius or Fahrenheit
  // 'default' use Celsius except when language is set to english
  // To use celsius:  isCelsius: true
  // To use Fahrenheit: isCelsius: false
  isCelsius: 'default',
  
  //Use the real feel temperature instead of the "real" on
  //Enable: useRealFeel: true
  //Disable: useRealFeel: false
  useRealFeel: false,
  
  //Use inline forecast instead of colums
  inlineForecast: false,
  
  //You can set a limit number of day forecast to show in inline mode
  inlineLimit: 3,
  
  //Switch to inline forecast instead of columns when less than 4 days forecast
  autoInline: true,
  
  //The update interval (in mniutes)
  updateInterval: 15,
  
  //Disable the more often check (every 2 minutes 3 times then normal interval) when getting no response
  //false: activated / true: disabled
  dontInsist: false,
  
  //Option to turn on or off the display of the last time weather has been updated
  showLastUpdated: false,
  
  //Option to turn on or off the display of a manual update button
  showUpdateButton: false,
  
  //Set source which we take weather from
  //Apple|Yahoo
  source: 'Yahoo',
  
  iconSet: 'tick',
  
  iconExt: '.png',
}, Settings['com.havrest.lockinfo.WeatherPlugin']);


if(!Settings['com.havrest.lockinfo.WeatherPlugin:1'])
  Settings['com.havrest.lockinfo.WeatherPlugin:1'] = {};

Settings['com.havrest.lockinfo.WeatherPlugin:1'] = Object.extend({
  defState: 'shrinked',
  
  locale: '',
}, Settings['com.havrest.lockinfo.WeatherPlugin:1']);

if(!Settings['com.havrest.lockinfo.WeatherPlugin:2'])
  Settings['com.havrest.lockinfo.WeatherPlugin:2'] = {};

Settings['com.havrest.lockinfo.WeatherPlugin:2'] = Object.extend({
  defState: 'shrinked',
  
  locale: '',
}, Settings['com.havrest.lockinfo.WeatherPlugin:2']);

if(!Settings['com.havrest.lockinfo.WeatherPlugin:3'])
  Settings['com.havrest.lockinfo.WeatherPlugin:3'] = {};

Settings['com.havrest.lockinfo.WeatherPlugin:3'] = Object.extend({
  defState: 'shrinked',
  
  locale: '',
}, Settings['com.havrest.lockinfo.WeatherPlugin:3']);
