
var Source = {
  MiniIcons:
  [
    "tstorm3",       // 0  tornado
    "tstorm3",       // 1  tropical storm
    "tstorm3",       // 2  hurricane
    "tstorm3",       // 3  severe thunderstorms
    "tstorm2",       // 4  thunderstorms
    "sleet",         // 5  mixed rain and snow
    "sleet",         // 6  mixed rain and sleet
    "sleet",         // 7  mixed snow and sleet
    "sleet",         // 8  freezing drizzle
    "light_rain",    // 9  drizzle
    "sleet",         // 10 freezing rain
    "shower2",       // 11 showers
    "shower2",       // 12 showers
    "snow1",         // 13 snow flurries
    "snow2",         // 14 light snow showers
    "snow4",         // 15 blowing snow
    "snow4",         // 16 snow
    "hail",          // 17 hail
    "sleet",         // 18 sleet
    "mist",          // 19 dust
    "fog",           // 20 foggy
    "mist",           // 21 haze
    "fog",           // 22 smoky
    "cloudy1",       // 23 blustery
    "cloudy1",       // 24 windy
    "overcast",      // 25 cold
    "cloudy1",       // 26 cloudy
    "cloudy4_night", // 27 mostly cloudy (night)
    "cloudy4",       // 28 mostly cloudy (day)
    "cloudy2_night", // 29 partly cloudy (night)
    "cloudy2",       // 30 partly cloudy (day)
    "sunny_night",   // 31 clear (night)
    "sunny",         // 32 sunny
    "mist_night",    // 33 fair (night)
    "mist",          // 34 fair (day)
    "hail",          // 35 mixed rain and hail
    "sunny",         // 36 hot
    "tstorm1",       // 37 isolated thunderstorms
    "tstorm2",       // 38 scattered thunderstorms
    "tstorm2",       // 39 scattered thunderstorms
    "tstorm2",       // 40 scattered showers
    "snow5",         // 41 heavy snow
    "snow3",         // 42 scattered snow showers
    "snow5",         // 43 heavy snow
    "cloudy1",       // 44 partly cloudy
    "shower2",        // 45 thundershowers
    "snow2",         // 46 snow showers
    "tstorm1",       // 47 isolated thundershowers
    "dunno",         // 48 / 3200 not available
  ],
	
  unit: 'c',
  
  innerUnit: true,
  
  validateWeatherLocation: function (location, callback)
  {
  	var url = 'http://iphone-wu.apple.com/dgw?imei=B7693A01-F383-4327-8771-501ABD85B5C1&apptype=weather&t=4';
  	
  	var xml_request = new XMLHttpRequest();
  	xml_request.onload = (function(e) {this.xml_validateloaded(e, xml_request, callback);}).bind(this);
  	xml_request.overrideMimeType("text/xml");
  	xml_request.open("POST", url);
  	xml_request.setRequestHeader("Cache-Control", "no-cache");
  	xml_request.setRequestHeader("Accept", "en-us");
  	xml_request.setRequestHeader("Accept-Language", "*/*");
  	xml_request.setRequestHeader("User-Agent", "Apple iPhone v2.2 Weather v1.0.0.5G77");
  	xml_request.setRequestHeader("Accept-Encoding", "");
  	xml_request.setRequestHeader("Content-Type", "text/xml");
  	xml_request.send("<?xml version=\"1.0\" encoding=\"utf-8\"?><request devtype=\"Apple iPhone v2.2\" deployver=\"Apple iPhone v2.2\" app=\"YGoiPhoneClient\" appver=\"1.0.0.5G77\" api=\"weather\" apiver=\"1.0.0\" acknotification=\"0000\"><query id=\"30\" timestamp=\"0\" type=\"getlocationid\"><phrase>"+location+"</phrase><language>"+Controller.language.replace(/([-])/i,'_')+"</language></query></request>");
  },
  
  xml_validateloaded: function (event, request, callback)
  {
    
  	if (request.responseXML)
  	{
  		var obj = {error:false, errorString:null, cities:new Array, refine:false};
  		
  		var response = Source.findChild (request.responseXML, "response");
  		if (response == null) {callback(Source.constructError("no &lt;response&gt;")); return;}
  		
  		var result = Source.findChild (response, "result");
  		if (result == null) {callback(Source.constructError("no &lt;result&gt;")); return;}
  		
  		var CityList = Source.findChild (result, "list");
  		if (CityList == null) {callback(Source.constructError("no &lt;list&gt;")); return;}
  		
  		for (child = CityList.firstChild; child != null; child = child.nextSibling)
  		{
  			if (child.nodeName == "item")
  			{
  			 
  			  var zip = Source.findChild (child, "id").firstChild.data.toString().replace(/\|(.+)$/,'');
  				var city = Source.findChild (child, "city").firstChild.data.toString();
  				var state = Source.findChild (child, "region").firstChild.data.toString();
  				
  				if (city && state && zip)
  				{
  					obj.cities[obj.cities.length] = {name:city, state:state, zip:zip};
  				}
  			}
  		}
  		
  		callback (obj);
  	}
  	else
  	{
  		callback ({error:true, errorString:"No Response"});
  	}
  },
  
  fetchWeatherData: function (callback, locale)
  {
    /*url = "http://weather.yahooapis.com/forecastrss?u=f&p=";
    
    var xmlReq = new XMLHttpRequest();
    xmlReq.onreadystatechange = function(e)
    {
      Source.handleFetchedWeatherData(e, xmlReq, callback);
    }
    xmlReq.overrideMimeType("text/xml");
    xmlReq.open("GET", url + escape(locale).replace(/^%u/g, "%"));
    xmlReq.setRequestHeader("Cache-Control", "no-cache");
    xmlReq.send(null);*/
    
    var url = 'http://iphone-wu.apple.com/dgw?imei=B7693A01-F383-4327-8771-501ABD85B5C1&apptype=weather&t=4';
  	
  	var xml_request = new XMLHttpRequest();
  	xml_request.onload = (function(e) {this.handleFetchedWeatherData(e, xml_request, callback);}).bind(this);
  	xml_request.overrideMimeType("text/xml");
  	xml_request.open("POST", url);
  	xml_request.setRequestHeader("Cache-Control", "no-cache");
  	xml_request.setRequestHeader("Accept", "en-us");
  	xml_request.setRequestHeader("Accept-Language", "*/*");
  	xml_request.setRequestHeader("User-Agent", "Apple iPhone v2.2 Weather v1.0.0.5G77");
  	xml_request.setRequestHeader("Accept-Encoding", "");
  	xml_request.setRequestHeader("Content-Type", "text/xml");
  	xml_request.send("<?xml version=\"1.0\" encoding=\"utf-8\"?><request devtype=\"Apple iPhone v2.2\" deployver=\"Apple iPhone v2.2\" app=\"YGoiPhoneClient\" appver=\"1.0.0.5G77\" api=\"weather\" apiver=\"1.0.0\" acknotification=\"0000\"><query id=\"30\" timestamp=\"0\" type=\"getforecastbylocationid\"><list><id>"+locale+"</id></list><language>"+Controller.language.replace(/([-])/i,'_')+"</language><unit>"+this.unit+"</unit></query></request>");
    
    return xmlReq;
  },
  
  handleFetchedWeatherData: function (event, xmlReq, callback)
  {
    if(xmlReq.readyState != 4) 
    {
      return;
    }
    if(xmlReq.status != 200 && xmlReq.status != 0) 
    {
      return;
    }
    if(!xmlReq.responseXML)
    {
      return;
    }
    
    var obj = {error:false, errorString:null};
    
    var List = Source.findChild(Source.findChild(Source.findChild(xmlReq.responseXML, "response"), "result"), "list");
    var Item = Source.findChild(List, "item");
    
    var Condition = Source.findChild(Item, "condition");
    
    attribute = Source.findChild(Item, "location").getAttribute("city");
    obj.city = attribute.toString();
    
    attribute = Condition.getAttribute("temp");
    obj.temp = parseInt(attribute);
    
    attribute = Source.findChild(Item, "wind").getAttribute("chill");
    obj.realFeel = parseInt(attribute);
    
    attribute = Condition.getAttribute("text");
    obj.description = attribute.toString();
    
    attribute = Condition.getAttribute("code");
    obj.icon = parseInt(attribute);
    if(obj.icon == 3200)
    {
      obj.icon = 48;
    }
    
    obj.forecast = new Array;
		var Forecast = Source.findChild (Item, "forecast", true);
		
		// assume the days are in order, 1st entry is today
		var j=0;
		var firstTime = true;
		
		for (var i=0; i<Forecast.length; i++) {
		  var child = Forecast[i];
		  
			if (firstTime) // today
			{
				obj.hi = parseInt (child.getAttribute('high'));
				
				obj.lo = parseInt (child.getAttribute('low'));
				
				firstTime = false;
			}

			var foreobj = {daycode:null, hi:0, lo:0, icon:-1};

			foreobj.daycode = parseInt(child.getAttribute('dayofweek'))-1;
			foreobj.hi = parseInt (child.getAttribute('high'));
			foreobj.lo = parseInt (child.getAttribute('low'));
			foreobj.description = child.getAttribute('text');
			
      foreobj.icon = parseInt(child.getAttribute("code"));
      if(foreobj.icon == 3200)
      {
        foreobj.icon = 48;
      }
      
      foreobj.ouricon = Source.MiniIcons[foreobj.icon-1];
			
			//alert(j);
				
			obj.forecast[j++]=foreobj;
			if (j == 7) break; // only look ahead 7 days
		}
    
    callback(obj); 
  },
  
  findChild: function (element, nodeName, all)
  {
  	var child;
  	var children = [];
  	var i=0;
  	
  	for (child = element.firstChild; child != null; child = child.nextSibling)
  	{
  	  if((child.nodeName == nodeName) && (all))
  	    children[i++]=child;
  		else if (child.nodeName == nodeName)
  			return child;
  	}
  	
  	return ((all)?children:null);
  },
  
  constructError: function (string)
  {
  	return {error:true, errorString:string};
  },
};

Weather.addSource(Source);
