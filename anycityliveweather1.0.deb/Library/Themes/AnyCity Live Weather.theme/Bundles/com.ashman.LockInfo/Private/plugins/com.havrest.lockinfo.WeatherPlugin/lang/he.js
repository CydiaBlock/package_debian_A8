
if(!He)
	var He = new Language('he');

He.setString("Try a more specific search","נסה חיפוש מדויק יותר");
He.setString("Not Found","לא נמצא");
He.setString("No Response","אין תגובה");
He.setString("City not found","עיר לא נמצאה");

He.setString("SUNNY","שמשי");
He.setString("CLOUDY","מעונן");
He.setString("FOG","ערפל");
He.setString("THUNDERSTORM","סופת ברקים");
He.setString("THUNDERSTORMS","סופות ברקים");
He.setString("RAIN","גשם");
He.setString("SNOW","שלג");
He.setString("ICE","קרח");
He.setString("HOT","חם");
He.setString("COLD","קר");
He.setString("PARTLY CLOUDY","מעונן חלקית");
He.setString("PARTLY CLOUDY WITH SHOWERS","מעונן חלקית עם ממטרים");
He.setString("LIGHT RAIN","גשם קל");
He.setString("RAIN SHOWER","מטח גשם");
He.setString("LIGHT FOG","ערפל קל");
He.setString("THUNDERSHOWER","סופת ברקים");
He.setString("FOGGY","ערפילי");

He.setString("Last update:","עדכון אחרון");
