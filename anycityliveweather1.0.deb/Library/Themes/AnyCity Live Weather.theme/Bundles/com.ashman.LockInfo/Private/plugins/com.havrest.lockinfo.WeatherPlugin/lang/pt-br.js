﻿
if(!PtBr)
	var PtBr = new Language('pt-br');

PtBr.setString("Try a more specific search","Pesquise mais especificamente");
PtBr.setString("Not Found","Não encontrado");
PtBr.setString("No Response","Sem resposta");
PtBr.setString("City not found","Cidade não encontrada");

PtBr.setString("SUNNY","Ensolarado");
PtBr.setString("MOSTLY SUNNY","Bem Ensolarado");
PtBr.setString("PARTLY SUNNY","Parc. Ensolarado");
PtBr.setString("MOSTLY CLOUDY","Bem Fechado");
PtBr.setString("CLOUDY","Fechado");
PtBr.setString("RAIN","Chuva");
PtBr.setString("SNOW","Neve");
PtBr.setString("MOSTLY CLOUDY WITH SNOW","Bem Fechado com Neve");
PtBr.setString("ICE","Gelo");
PtBr.setString("FREEZING RAIN","Chuva de Granizo");
PtBr.setString("RAIN AND SNOW MIXED","Chuva com Neve");
PtBr.setString("HOT","Quente");
PtBr.setString("COLD","Frio");
PtBr.setString("CLEAR","Limpo");
PtBr.setString("MOSTLY CLEAR","Bem Limpo");
PtBr.setString("PARTLY CLOUDY","Parc. Limpo");
PtBr.setString("LIGHT RAIN","Chuva leve");
PtBr.setString("RAIN/WIND","Chuva com vento");

PtBr.setString("Last update:","Última atualização");
