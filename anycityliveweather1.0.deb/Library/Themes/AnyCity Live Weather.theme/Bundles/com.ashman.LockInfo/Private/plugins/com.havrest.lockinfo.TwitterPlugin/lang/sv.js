﻿
if(!Sv)
	var Sv = new Language('sv');

Sv.setString("Twitter - Friends Timeline:","Vänners tidsline:");
Sv.setString("Twitter - Mentions:","Sägningar:");
Sv.setString("Twitter - Direct Messages:","Direkt medelanden:");
