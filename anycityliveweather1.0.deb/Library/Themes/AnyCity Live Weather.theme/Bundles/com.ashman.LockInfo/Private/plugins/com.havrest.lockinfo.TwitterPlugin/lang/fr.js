
if(!Fr)
  var Fr = new Language('fr');

Fr.setString('Twitter - Friends Timeline:','Twitter - Tweets Amis :');
Fr.setString('Twitter - Mentions:','Twitter - Mentions :');
Fr.setString('Twitter - Direct Messages:','Twitter - Messages directs :');
