
if(!El)
	var El = new Language('el');

El.setString("Try a more specific search","Κάντε μια αναλυτικότερη αναζήτηση");
El.setString("Not Found","Δεν βρέθηκε");
El.setString("No Response","Καμία Απάντηση");
El.setString("City not found","Η πόλη δεν βρέθηκε");

El.setString("SUNNY","Ηλιοφάνεια");
