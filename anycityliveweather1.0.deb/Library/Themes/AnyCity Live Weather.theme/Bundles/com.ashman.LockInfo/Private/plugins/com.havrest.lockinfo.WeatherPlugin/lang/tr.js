
if(!Tr)
	var Tr = new Language('tr');

Tr.setString("HOT","Sıcak");
Tr.setString("COLD","Soğuk");
Tr.setString("WINDY","Rüzgarlı");
Tr.setString("CLEAR","Açık");
Tr.setString("SUNSHINE AND PATCHY CLOUDS","Paröalı Bulutlu");
Tr.setString("LGT.RAINSHOWER","Yağmurlu");
Tr.setString("MIST","Puslu");
Tr.setString("THUNDERSHOWER","Fırtına");
Tr.setString("FOGGY","Sisli");

Tr.setString("Last update:","Son Güncelleme");
