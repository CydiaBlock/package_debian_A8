﻿
if(!Pl)
	var Pl = new Language('pl');

Pl.setString("Twitter - Friends Timeline:","Czasolinia przyjaciół");
Pl.setString("Twitter - Mentions:","Wzmianki");
Pl.setString("Twitter - Direct Messages:","Wiadomości");
