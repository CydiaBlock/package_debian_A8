﻿
if(!ZhHk)
	var ZhHk = new Language('zh-hk');

ZhHk.setString("Not Found","找不到符合的項目");
ZhHk.setString("No Response","没有回應");
ZhHk.setString("City not found","找不到符合的城市");

ZhHk.setString("SUNNY","睛天");
ZhHk.setString("PARTLY SUNNY","間中有陽光");
ZhHk.setString("INTERMITTENT CLOUDS","間中有雲");
ZhHk.setString("HAZY SUNSHINE","有薄霧");
ZhHk.setString("MOSTLY CLOUDY","陰天");
ZhHk.setString("CLOUDY","多雲");
ZhHk.setString("DREARY","陰天");
ZhHk.setString("FOG","大霧");
ZhHk.setString("SHOWERS","陣雨");
ZhHk.setString("MOSTLY CLOUDY WITH SHOWERS","多雲有雨");
ZhHk.setString("MOSTLY SUNNY WITH SHOWERS","大部份時間有陽光，間中有雨");
ZhHk.setString("THUNDERSTORM","雷雨");
ZhHk.setString("THUNDERSTORMS","雷雨");
ZhHk.setString("MOSTLY CLOUDY WITH THUNDER SHOWERS","多雲有雷雨");
ZhHk.setString("PARTLY SUNNY WITH THUNDER SHOWERS","間中有陽光、雷雨");
ZhHk.setString("RAIN","下雨");
ZhHk.setString("FLURRIES","有風");
ZhHk.setString("MOSTLY CLOUDY WITH FLURRIES","多雲有風");
ZhHk.setString("MOSTLY SUNNY WITH FLURRIES","大部份時間有陽光，有風");
ZhHk.setString("PARTLY SUNNY WITH FLURRIES","部份時間有陽光，有風");
ZhHk.setString("SNOW","下雪");
ZhHk.setString("MOSTLY CLOUDY WITH SNOW","多雲有雪");
ZhHk.setString("SLEET","下凍雨");
ZhHk.setString("RAIN AND SNOW MIXED","下雨、下雪");
ZhHk.setString("HOT","炎熱");
ZhHk.setString("COLD","寒冷");
ZhHk.setString("CLEAR","睛朗");
ZhHk.setString("MOSTLY CLEAR","大部份時間睛朗");
ZhHk.setString("PARTLY CLOUDY","部份時間有雲");
ZhHk.setString("HAZY","有薄霧");
ZhHk.setString("PARTLY CLOUDY WITH SHOWERS","部份時間有雲、有陣雨");
ZhHk.setString("PARTLY CLOUDY WITH THUNDER SHOWERS","部份時間有雲、有雷雨");
ZhHk.setString("LIGHT RAIN","微雨");
ZhHk.setString("BREEZY AND CHILLY WITH SUNSHINE","有微風，間中有陽光");
