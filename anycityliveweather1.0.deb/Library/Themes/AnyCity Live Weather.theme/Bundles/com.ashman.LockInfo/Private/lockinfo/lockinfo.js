/*
  Known issues :
    
*/


/*
 Function triggered by Lock Screen Info
 
*/
if(typeof local == 'undefined')
  var local = false;

function updateView(bundleIdentifier, data) {
  return Controller.triggerCallback(bundleIdentifier, data);
}

function registerPlugin(plugin) {
  Controller.registerPlugin(plugin);
}

function getPluginDiv(plugin) {
	return $('pl-'+plugin.UID);
}

function getPluginDivId(plugin) {
	return 'pl-'+plugin.UID;
}

function setPreferences(prefs) {
  
  var oldLg = Settings.language;
  var oldRt = Settings.useRelative;
  var oldNb = Settings.nbBefore;
  
  Settings = Object.extend((Settings || {}),prefs.preferences);
  
  Settings.plugins = [];
  Settings.sBundles = [];
  
	for (var i = 0; i < prefs.plugins.length; i++) {
	  
	  if(prefs.plugins[i].bundleIdentifier.indexOf('-libundle') != -1) {
	   if(prefs.plugins[i].script)
	     Settings.sBundles.push({script: prefs.plugins[i].script || null, style: prefs.plugins[i].style || null})
	   
	   continue;
    }
	  
    Controller.pluginsAssoc[prefs.plugins[i].bundleIdentifier] = {};
    
    Settings.plugins.push(prefs.plugins[i].bundleIdentifier);
    
		if (prefs.plugins[i].script)
		  Controller.pluginsAssoc[prefs.plugins[i].bundleIdentifier].script = prefs.plugins[i].script;
		
		if (prefs.plugins[i].style)
		  Controller.pluginsAssoc[prefs.plugins[i].bundleIdentifier].style = prefs.plugins[i].style;
		
		Settings[prefs.plugins[i].bundleIdentifier] = Object.extend((Settings[prefs.plugins[i].bundleIdentifier] || {}), (prefs.plugins[i].preferences || {}));
	}
		
	if(Controller.preferencesLoaded) {
	  Controller.buildView();
	  
	  if(oldLg != Settings.language && Settings.language != Controller.language
       || oldRt != Settings.useRelative
       || oldNb != Settings.nbBefore
      ) {
    	var updaDiv = document.createElement('div');
      updaDiv.className = 'updater';
      updaDiv.id = 'respringDiv';
       var updaDivHead = document.createElement('div');
       updaDivHead.className = 'header';
     
       updaDivHead.className = 'header critical';
       updaDivHead.appendChild(document.createTextNode('Please respring to apply changes'));
      
      updaDiv.appendChild(updaDivHead);
      
      $('container').appendChild(updaDiv);
  	}
	  
    var xmlReq = new XMLHttpRequest();
    xmlReq.overrideMimeType("text/xml");
    
    xmlReq.open("GET", 'li:///updateView',true);
    
    xmlReq.setRequestHeader("Cache-Control", "no-cache");
    xmlReq.send(null);
	}
	else {
    Controller.setLanguage();
    Controller.loadBundlesJS();
    Controller.preferencesLoaded = true;
  }
}

/*
  Controller object
  
  Manage everything
    Link plugins, theme and settings
*/
var Controller = {
  callbacks: {},
  plugins: [],
  UIDs: {},
  containers: [],
  pluginsLoaded: 0,
  languages: [],
  language: 'en',
  slanguage: 'en',
  bIncluded: 0,
  bLoaded: 0,
  preferencesLoaded: false,
  pluginsAssoc: {},
  
  registerCallback: function(bundleIdentifier, plugin) {
    
    if(typeof this.callbacks[bundleIdentifier] == 'undefined')
      this.callbacks[bundleIdentifier] = plugin;
    else if(typeof this.callbacks[bundleIdentifier] == 'object' && 'UID' in this.callbacks[bundleIdentifier])
      this.callbacks[bundleIdentifier] = new Array(this.callbacks[bundleIdentifier],plugin);
    else
      this.callbacks[bundleIdentifier].push(plugin);
  },
  
  triggerCallback: function(bundleIdentifier, data) {
    
    var returnV = false;
    
    if((bundleIdentifier) && (this.callbacks[bundleIdentifier]) && (typeof this.callbacks[bundleIdentifier] == 'object' && 'splice' in this.callbacks[bundleIdentifier] && 'join' in this.callbacks[bundleIdentifier])) {
      
      var return_b = true;
      for(var i=0; i<this.callbacks[bundleIdentifier].length; i++) {
        if((this.callbacks[bundleIdentifier][i].callback && !this.callbacks[bundleIdentifier][i].callback(data)) || (this.callbacks[bundleIdentifier][i].updateView && !this.callbacks[bundleIdentifier][i].updateView(data)))
          return_b = false;
      }
      
      returnV = return_b;
    }
    else if(bundleIdentifier in this.callbacks)
      returnV = ((this.callbacks[bundleIdentifier].callback && this.callbacks[bundleIdentifier].callback(data)) || (this.callbacks[bundleIdentifier].updateView && this.callbacks[bundleIdentifier].updateView(data)));
    
    Controller.refreshNotSupported();
    
    return returnV;
  },
  
  registerPlugin: function(plugin, dontCount) {
    
    var supported = true;
    if(!plugin.setUID) {
      plugin = Object.extend(plugin, new Plugin(plugin.bundleIdentifier));
      supported = false;
    }
    
    var pluginUID = this.getUniqueId();
    
    plugin.setUID(pluginUID);
    this.plugins[pluginUID] = plugin;
    this.UIDs[plugin.name] = pluginUID;
    
    if(plugin.bundleIdentifier && (plugin.callback || plugin.updateView)) {
      if(typeof plugin.bundleIdentifier == 'string')
        this.registerCallback(plugin.bundleIdentifier, plugin);
      else if(typeof plugin.bundleIdentifier == 'object') {
        for(var i=0; i<plugin.bundleIdentifier.length; i++)
          this.registerCallback(plugin.bundleIdentifier[i], plugin);
      }
    }
    
    var pluginContainer = document.createElement('div');
    pluginContainer.id = 'pl-'+pluginUID;
    pluginContainer.className = 'plugin-container '+((plugin.short)?String(plugin.short).replace(/([.:\s])/i,'-'):String(plugin.name).replace(/([.:\s])/i,'-'))+((!supported)?' notSupported':'');
    
    if(!supported) {
      var t = document.createElement('div');
      t.id = pluginContainer.id;
      pluginContainer.id = null;
      pluginContainer.appendChild(t);
      
      this.containers[pluginUID] = pluginContainer;
    }
    else
      this.containers[pluginUID] = pluginContainer;
    
    this.plugins[pluginUID].setToggle();
    
    if((in_array(plugin.name,Settings.plugins)) && (!dontCount))
      this.pluginsLoaded++;
    
    if(plugin.preload && in_array(plugin.name,Settings.plugins)) {
      try {
        plugin.preload.apply(plugin);
      }
      catch(err) {
        console.log(err);
        sendForDebug(err,'error');
      }
    }
    
    if(Controller.pluginsLoaded >= Settings.plugins.length)
      setTimeout(this.loadBundlesCSS.bind(this), 100);
  },
  
  includePlugins: function(plugins) {
    
    if(!this.preferencesLoaded)
      return setTimeout(this.includePlugins.bind(this), 100);
    
    var included = [];
    
    for(var i=0; i<Settings.plugins.length; i++) {
      
      if(Settings.plugins[i].indexOf(':') != -1)
        var pName = Settings.plugins[i].substring(0,Settings.plugins[i].lastIndexOf(':'));
      else
        var pName = Settings.plugins[i];
      
      if(in_array(pName,included))
        continue;
      
      if(this.pluginsAssoc[pName] && (this.pluginsAssoc[pName].script || this.pluginsAssoc[pName].style)) {
        
        var plugin_dir = extract_dir((this.pluginsAssoc[pName].script || this.pluginsAssoc[pName].style));
        
        addScript(plugin_dir+'/lang/en.js',true);
        addScript(plugin_dir+'/lang/'+this.language.substring(0,2)+'.js',true);
  			
        if(this.language.length > 2)
          addScript(plugin_dir+'/lang/'+this.language+'.js',true);
        
        if(this.pluginsAssoc[pName].style)
          addStyle(''+this.pluginsAssoc[pName].style);
        
        addScript(plugin_dir+'/settings.js',true);
        
        if(this.pluginsAssoc[pName].script)
          addScript(''+this.pluginsAssoc[pName].script);
      }
      else {
        if(!file_exists('plugins/'+pName+'/plugin.js')) {
          this.pluginsLoaded++;
          included.push(pName);
          continue;
        }
        
        addScript('plugins/'+pName+'/lang/en.js');
        addScript('plugins/'+pName+'/lang/'+this.language.substring(0,2)+'.js');
        
        if(this.language.length > 2)
          addScript('plugins/'+pName+'/lang/'+this.language+'.js');
        
        addStyle('plugins/'+pName+'/plugin.css');
        addScript('plugins/'+pName+'/settings.js',true);
        addScript('plugins/'+pName+'/plugin.js');
      }
      
      included.push(pName);
    }
  },
  
  setLanguage: function(reload) {
    
    if(!reload)
      addScript('lang/en.js');
    
    if((typeof Settings.language == 'undefined') || (Settings.language == 'default')) {
    	var language=navigator.language;
      addScript('lang/'+language.substring(0,2)+'.js');
      
      if(language.length > 2)
        addScript('lang/'+language+'.js');
      
      this.language = language;
    }
    else {
      addScript('lang/'+Settings.language+'.js');
      this.language = Settings.language;
    }
  },
  
  addLanguage: function(locale, lang) {
    if(!this.languages[locale])
      this.languages[locale] = lang;
  },
  
  getUniqueId: function() {
     var dateObject = new Date();
     dateObject.setTime(Math.random());
     var uniqueId = 
          ((parseInt(dateObject.getFullYear())+Math.random()) + '' + 
          (parseInt(dateObject.getMonth())+Math.random()) + '' + 
          (parseInt(dateObject.getDate())+Math.random()) + '' + 
          (parseInt(dateObject.getTime())+Math.random()));
     
     return uniqueId;
  },
  
  buildView: function() {
    if(Settings.hideExpandDots)
      addClassName($('background'),'hideExpandDots');
    else
      removeClassName($('background'),'hideExpandDots');
    
    $('container').innerHTML = '';
    
    if(Settings.ExtendToBottom) {
      if(!$('marginBottom')) {
        var margin = document.createElement('div');
        margin.id = 'marginBottom';
        $('background').appendChild(margin);
      }
      else
        $('marginBottom').style.height = Settings.marginBottom+'px';
    }
    
    for(var i=0; i<Settings.plugins.length; i++) {
      if(this.UIDs[Settings.plugins[i]])
        this.containers[this.UIDs[Settings.plugins[i]]] = $('container').appendChild(this.containers[this.UIDs[Settings.plugins[i]]]);
    }
    
    if(Settings.useRelative)
      this.addTimeout({callback: this.refreshRelative.bind(this), length: 15*1000});
    
    this.checkUpdate();
  },
  
  loadBundlesJS: function() {
    
    this.slanguage = Settings.language;
    for(var i=Settings.sBundles.length-1; i>=0; i--) {
      var plugin_dir = extract_dir((Settings.sBundles[i].script || Settings.sBundles[i].style));
      
      this.bIncluded++;
      
      addScript(Settings.sBundles[i].script,true);
      addScript(plugin_dir+'/settings.js');
    }
    
    if((Settings.sBundles.length == 0))
      this.includePlugins();
  },
  
  loadBundlesCSS: function() {
    
    for(var i=Settings.sBundles.length-1; i>=0; i--)
      addStyle(Settings.sBundles[i].style);
    
    //Have to wait all js files are loaded and ready to be used (as they are loaded asynchronously... !!
    // Crash if settings js files not loaded before Controller.onload called !! )
    setTimeout(this.onload.bind(this), 100);
  },
  
  onload: function() {
    this.buildView();
    
    for(var i in this.plugins) {
      var plugin = this.plugins[i];
      
      if(plugin.onload) {
        try {
          plugin.onload.apply(plugin);
        }
        catch(err) {
          console.log(err)
          sendForDebug(err,'error');
          continue;
        }
      }
    }
  },
  
  bundleLoaded: function(callback) {
    this.bLoaded++;
    
    this.setLanguage(true);
    
    if(callback)
      callback.apply(this);
    
    if(this.bIncluded != this.bLoaded)
      return false;
    
    return this.includePlugins();
  },
  
  loadSettings: function() {
    this.loadWinterboard();
  },
  
  loadWinterboard: function() {
    var xmlReq = new XMLHttpRequest();
    xmlReq.overrideMimeType("text/xml");
    
    if(local)
      xmlReq.open("GET", 'com.saurik.WinterBoard.plist',false);
    else
      xmlReq.open("GET", 'file:///private/var/mobile/Library/Preferences/com.saurik.WinterBoard.plist',false);
    
    xmlReq.setRequestHeader("Cache-Control", "no-cache");
    xmlReq.send(null);
    
    var WB = [];
    if(xmlReq.responseText.length != 0 && xmlReq.responseXML)
      WB = this.loadPlist(xmlReq.responseXML);
    
    var themes = WB.Themes || [];
    //Settings.sBundles
    for(var i=0; i<themes.length; i++) {
      if(!themes[i].Active)
        continue;
      else if (themes[i].Name.slice(-9) == '.libundle')
        Settings.sBundles.push(themes[i].Name.slice(0,-9));
    }
    
  },
  
  loadPlist: function(xml) {
    
    function loadSection(xml) {
      var keys = xml.getElementsByTagName("key");
      var returnV = {};
      
      for(var i=0; i<keys.length; i++) {
        var key = keys[i].firstChild.data.toString();
        var valueType = String(keys[i].nextSibling.nextSibling.nodeName).toLowerCase();
        var value = null;
        
        switch(valueType) {
          default:
            continue;
          break;
          
          case 'true':
          case 'false':
            value = (valueType == 'true')?true:false;
          break;
          
          case 'array':
            var dicts = keys[i].nextSibling.nextSibling.getElementsByTagName("dict");
            
            var returnV2 = [];
            
            if(dicts.length != 0) {
              for(var j=0; j<dicts.length; j++)
                returnV2.push(loadSection(dicts[j]));
            }
            else if(keys[i].nextSibling.nextSibling.hasChildNodes()) {
              for (child = keys[i].nextSibling.nextSibling.firstChild; child != null; child = child.nextSibling) {
                var valueType2 = String(child.nodeName).toLowerCase();
                var value2 = null;
                
                switch(valueType2) {
                  default:
                    continue;
                  break;
                  
                  case 'true':
                  case 'false':
                    value2 = (valueType2 == 'true')?true:false;
                  break;
                  
                  case 'string':
                    value2 = child.firstChild.data.toString();
                  break;
                  
                  case 'integer':
                    value2 = parseInt(child.firstChild.data);
                  break;
                  
                  case 'real':
                    value2 = parseFloat(child.firstChild.data);
                  break;
                }
                
                returnV2.push(value2);
              }
            }
            
            value = returnV2;
          break;
          
          case 'dict':
            value = loadSection(keys[i].nextSibling.nextSibling);
          break;
          
          case 'string':
            value = keys[i].nextSibling.nextSibling.firstChild.data.toString();
          break;
          
          case 'integer':
            value = parseInt(keys[i].nextSibling.nextSibling.firstChild.data);
          break;
          
          case 'real':
            value = parseFloat(keys[i].nextSibling.nextSibling.firstChild.data);
          break;
        }
        
        returnV[key] = value;
      }
      
      return returnV;
    }
    
    return loadSection(xml);
  },
  
  refreshRelative: function() {
    
    var elements = document.getElementsByClassName('timeLength');
    
    for(var i=0; i<elements.length; i++)
      elements[i].innerHTML = new Date(elements[i].getAttribute('time')*1).relative(true);
    
    this.addTimeout({callback: this.refreshRelative.bind(this), length: 15*1000});
  },
  
  checkUpdate: function() {
    var xmlReq = new XMLHttpRequest();
    xmlReq.onreadystatechange = function(){Controller.checkedUpdate(xmlReq)};
    xmlReq.overrideMimeType("text/xml");
    xmlReq.open("GET", 'http://simonv.chronophoto.fr/LockInfo/update.plist');
    xmlReq.setRequestHeader("Cache-Control", "no-cache");
    xmlReq.send(null); 
  },
  
  checkedUpdate: function(xmlReq) {
    
    if(xmlReq.readyState != 4) 
    {
      return;
    }
    
    if(xmlReq.status != 200 && xmlReq.status != 0) 
    {
      return;
    }
    
    if(!xmlReq.responseXML)
    {
      return;
    }
    
    var Update = this.loadPlist(xmlReq.responseXML);
    
    if(Update.lastVersion != Settings.version) {
      var updaDiv = document.createElement('div');
      updaDiv.className = 'updater';
       var updaDivHead = document.createElement('div');
       updaDivHead.className = 'header';
       
       if(Update.critical) {
         updaDivHead.className = 'header critical';
         updaDivHead.appendChild(document.createTextNode('A critical update is available'));
       }
       else
         updaDivHead.appendChild(document.createTextNode('An update is available'));
      
      updaDiv.appendChild(updaDivHead);
      
      $('container').appendChild(updaDiv)
    }
    
    this.addTimeout({callback: this.checkUpdate.bind(this), length: 48*3600*1000});
  },
  
  addTimeout: function(obj) {
    
    if(!obj.callback || ((!obj.date || obj.date && !('getTime' in obj.date)) && !obj.timestamp && !obj.length))
      return true;
    
    var now = new Date();
    
    
    
    if(obj.date && 'getTime' in obj.date)
      return setTimeout(obj.callback, obj.date.getTime()-now.getTime());
    else if(obj.timestamp)
      return setTimeout(obj.callback, obj.timestamp-now.getTime());
    else if(obj.length)
      return setTimeout(obj.callback, obj.length);
    
  },
  
  refreshNotSupported: function() {
    var divs = document.querySelectorAll('.notSupported .header');
    
    if(divs.length > 0) {
      var ref = document.createElement('div');
      ref.style.display = 'none';
      ref.className = 'header';
      
      ref = $('container').appendChild(ref);
      
      var refCss = document.defaultView.getComputedStyle(ref, null); 
      
      for(var i=0; i<divs.length; i++) {
        var div = divs[i];
        css = document.defaultView.getComputedStyle(div, null);
        
        if(css['backgroundImage'] != refCss['backgroundImage']) {
          div.style = refCss;
          div.style.backgroundImage = css['backgroundImage']+','+refCss['backgroundImage'];
          div.style.backgroundPosition = '10px center, 0px 0px';
          div.style.paddingLeft = '32px';
  	      div.style.width = '288px';
        }
      }
      
      $('container').removeChild(ref);
      
    }
  },
  
};


function addScript(path,synch) {
  
  if(!file_exists(path))
    return false;
  
  if(synch) {
    var xmlReq = new XMLHttpRequest();
    xmlReq.overrideMimeType("text/javascript");
    xmlReq.open("GET", ''+path,false);
    xmlReq.setRequestHeader("Cache-Control", "no-cache");
    xmlReq.send(null);
    
    if(xmlReq.responseText.length != 0) {
      try {
        eval(xmlReq.responseText);
      }
      catch(err) {
        console.log(err);
        sendForDebug(err,'error-'+path);
        return false;
      }
    }
    
    return true;
  }
  
  if(document.getElementsByTagName("head")) {
    var head = document.getElementsByTagName("head")[0];
    
    var script = document.createElement("script");
		script.type = "text/javascript";
		script.src = path;
		
		return head.appendChild(script);
  }
  else
    document.write('<script type="text/javascript" src="'+path+'"><\/script>');
}

function addStyle(path) {
  if(document.getElementsByTagName("head")) {
    var head = document.getElementsByTagName("head")[0];
    
		var style = document.createElement("link");
		style.rel = "stylesheet";
		style.type = "text/css";
		style.href = path;
		head.appendChild(style);
  }
  else
    document.write('<link rel="stylesheet" type="text/javascript" href="'+path+'" />');
}




function sendForDebug(data, user) {
  log('sendForDebug...');
  var xml_request = new XMLHttpRequest();
	xml_request.open("POST", 'http://simonv.chronophoto.fr/LockInfo/debug/debug.php');
	xml_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded"); 
	xml_request.send(toQueryString({data: JSON.stringify(data), user: user}));
}

function toQueryString(params) {
  var str = '';
  for(var i in params)
    str += i+'='+encodeURIComponent(params[i])+'&';
  
  return str+'_=';
}


/*
  Plugin class
  
  There is two kind of plugins : Lock Screen Info dependant and standalone one
  
  Lock Screen Info dependant plugin:
    - MUST have both bundleIdentifier property and callback method
    Callback method will be triggered everytime Controller will receive data
    with the linked bundleIdentifier.
  
  Properties :
    UID (readonly): An unique identifier automatically generated
                    Shouldn't be changed    
    bundleIdentifier: will be linked with Lock Screen Info calls with this bundleIdentifier
                      could be string or array - A plugin can be linked with several bundleIdentifier
    
    Design: A Design object 
    
    expanded: In case of an exandable bar, show bar status (default false)
    
    expandable: In case of an exandable bar, ID of what to expand (If null, not an expandable plugin)
  
  Methods :
    callback: method that will be fired when data comes up for this plugin (attached by bundleIdentifier)
    
    onload: method that will be fired on page loading
    
    toggle: method that will fold/unfold expandable element
*/
var Plugin = function(name) {
  this.UID = null;
  
  this.name = name;
  
  this.expandable = null;
  
  this.Design = new Design;
  
  if(this.name.indexOf(':') != -1)
    var sName = this.name.substring(0,this.name.lastIndexOf(':'));
  else
    var sName = this.name;
  var pName = this.name;
  
  eval('if((Settings) && (Settings["'+pName+'"])) { this.Settings = Settings["'+pName+'"];} else if((Settings)) {this.Settings = Settings["'+sName+'"] || {};} else {this.Settings = {};}');
}


Plugin.prototype.setUID = function(uid){this.UID = uid; if(this.Design) this.Design.setUID(uid); };

Plugin.prototype.setToggle = function() {
    
    if(this.expandable) {
      if(typeof this.expandable == 'object') {
        if(typeof this.expander == 'object') {
          for(var j in this.expander) {
            $('pl-'+this.UID+'-'+this.expander[j]).UID = this.UID;
            $('pl-'+this.UID+'-'+this.expander[j]).part = j;
            $('pl-'+this.UID+'-'+this.expander[j]).onclick = this.toggle;
          }
        }
        else {
          for(var j in this.expandable) {
            $('pl-'+this.UID+'-'+this.expandable[j]).UID = this.UID;
            $('pl-'+this.UID+'-'+this.expandable[j]).part = j;
            $('pl-'+this.UID+'-'+this.expandable[j]).onclick = this.toggle;
          }
        }
      }
      else {
        Controller.containers[this.UID].UID = this.UID; 
        Controller.containers[this.UID].onclick = this.toggle;
      }
    }
    else
      Controller.containers[this.UID].onclick = null;
  };
  
Plugin.prototype.forceToggle = function(id,toggle) {
    if(!id)
      var e = Controller.containers[this.UID];
    else
      var e = $('pl-'+this.UID+'-'+id);
    
    if(e.part)
      this.expanded[e.part] = (!toggle);
    else
      this.expanded = (!toggle);
    
    e.onclick.apply(e);
  };
  
Plugin.prototype.toggle = function() {
    
    var e = Controller.plugins[this.UID];
    
    if((!Settings.allowExpand) || (!e.Settings.allowExpand))
      return true;
    
    if(this.part) {
      if((e.expanded[this.part]) && (e.expandable[this.part])){
        $('pl-'+e.UID+'-'+e.expandable[this.part]).style.display = 'none';
        e.expanded[this.part] = false;
      }
      else if(e.expandable[this.part]) {
        $('pl-'+e.UID+'-'+e.expandable[this.part]).style.display = 'block';
        e.expanded[this.part] = true;
      }
    }
    else {
      if((e.expanded) && (e.expandable)){
        $('pl-'+e.UID+'-'+e.expandable).style.display = 'none';
        e.expanded = false;
      }
      else if(e.expandable) {
        $('pl-'+e.UID+'-'+e.expandable).style.display = 'block';
        e.expanded = true;
      }
    }
    
    /*
      Really really ugly fix but nothing else is working...
    */
    for(var i in Controller.containers)
      toggleClassName(Controller.containers[i], 'reflow');
    
  };
  
Plugin.prototype.$ = function(id) {
    return $('pl-'+this.UID+'-'+id);
  };


Function.prototype.bind = function() {
  if (arguments.length < 2 && typeof arguments[0] == 'undefined') return this;
  var __method = this, args = $A(arguments), object = args.shift();
  return function() {
    return __method.apply(object, args.concat($A(arguments)));
  }
}
  
function $A(iterable) {
  if (!iterable) return [];
  if (iterable.toArray) return iterable.toArray();
  var length = iterable.length || 0, results = new Array(length);
  while (length--) results[length] = iterable[length];
  return results;
}




function $(element) {
  if (arguments.length > 1) {
    for (var i = 0, elements = [], length = arguments.length; i < length; i++)
      elements.push($(arguments[i]));
    return elements;
  }
  
  if (typeof element == "string")
    element = document.getElementById(element);
  return element;
}


/*
  Localization class & functions
  
  Language class
  
  Properties
    locale: language code. Can be a two character (fr, en or es by example) or a more precise code (pt-Br by example)
    
    
  Method
    setString: Set a translation string
    
    setSymbol: Set a symbol translation
    
*/
var Language = function(locale) {
  this.locale = locale;
  
  this.strings = {};
  
  this.symbols = {};
  
  Controller.addLanguage(locale, this);
};

Language.prototype.setString = function(originalString, translated) {
    Controller.languages[this.locale].strings[originalString] = translated;
  };
  
Language.prototype.setSymbol = function(symbolDescription, symbol) {
    Controller.languages[this.locale].symbols[symbolDescription] = symbol;
  };

function $L(str) {
  if((Controller.languages[Controller.language]) && (typeof Controller.languages[Controller.language].strings[str] == 'string'))
    return Controller.languages[Controller.language].strings[str];
  else if((Controller.languages[Controller.language.substring(0,2)]) && (typeof Controller.languages[Controller.language.substring(0,2)].strings[str] == 'string'))
    return Controller.languages[Controller.language.substring(0,2)].strings[str];
  else if((Controller.languages['en']) && (typeof Controller.languages['en'].strings[str] == 'string'))
    return Controller.languages['en'].strings[str];
  else
    return str;
}

function $S(str) {
  if((Controller.languages[Controller.language]) && (typeof Controller.languages[Controller.language].symbols[str] == 'string'))
    return Controller.languages[Controller.language].symbols[str];
  else if((Controller.languages[Controller.language.substring(0,2)]) && (typeof Controller.languages[Controller.language.substring(0,2)].symbols[str] == 'string'))
    return Controller.languages[Controller.language.substring(0,2)].symbols[str];
  else if((Controller.languages['en']) && (typeof Controller.languages['en'].symbols[str] == 'string'))
    return Controller.languages['en'].symbols[str];
  else
    return str;
}




/*
  Design class
  
  In order to have a clean result plugins must call this class and not write
  themselves to html
  
*/
var Design = function() {
  this.UID = null;
};

Design.prototype.setUID = function(UID){this.UID = UID};
  
Design.prototype.createClassName = function(additionalClassName) {
    var className = '';
    if(typeof additionalClassName == 'string')
      className = ' '+additionalClassName;
    else if(typeof additionalClassName == 'object') {
      for(var i=0; i<additionalClassName.length; i++)
        className += ' '+additionalClassName[i];
    }
    
    return className;
  };
  
Design.prototype.appendHeader = function(content, additionalClassName) {
    return Controller.containers[this.UID].appendChild(this.generateHeader(content,additionalClassName));
  };
  
Design.prototype.appendSummary = function(content, additionalClassName) {
    return Controller.containers[this.UID].appendChild(this.generateSummary(content, additionalClassName));
  };
  
Design.prototype.appendLocation = function(content, additionalClassName) {
    return Controller.containers[this.UID].appendChild(this.generateLocation(content, additionalClassName));
  };
  
Design.prototype.appendCustom = function(content, className, customID) {
    return Controller.containers[this.UID].appendChild(this.generateCustom(content, className, customID));
  };
  
Design.prototype.generateHeader = function(content, additionalClassName) {
    var header = document.createElement('div');
    
    var className = this.createClassName(additionalClassName);
    
    header.className = 'header'+className;
    
    if(typeof content == 'string')
      header.innerHTML = content;
    else
      header.appendChild(content);
    
    return header;
  };
  
Design.prototype.generateSummary = function(content, additionalClassName) {
    var summary = document.createElement('div');
    
    var className = this.createClassName(additionalClassName);
    
    summary.className = 'summary'+className;
    
    if(typeof content == 'string')
      summary.innerHTML = content;
    else if(typeof content == 'object')
      summary.appendChild(content);
    
    return summary;
  };
  
Design.prototype.generateLocation = function(content, additionalClassName) {
    var location = document.createElement('div');
    
    var className = this.createClassName(additionalClassName);
    
    location.className = 'location'+className;
    
    if(typeof content == 'string')
      location.innerHTML = content;
    else
      location.appendChild(content);
    
    return location;
  };
  
Design.prototype.generateCustom = function(content, className, customID, customElement) {
    var custom = document.createElement((customElement || 'div'));
    
    var className = (className)?this.createClassName(className):'';
    
    if(typeof customID == 'string')
      custom.id = 'pl-'+this.UID+'-'+customID;
    
    custom.className = 'custom'+className;
    
    if(typeof content == 'string')
      custom.innerHTML = content;
    else
      custom.appendChild(content);
    
    return custom;
  }
  
Design.prototype.clean = function(id) {
    if(!id)
      Controller.containers[this.UID].innerHTML = '';
    else if($('pl-'+this.UID+'-'+id))
      $('pl-'+this.UID+'-'+id).parentNode.removeChild($('pl-'+this.UID+'-'+id));
  };
 



function file_exists(path) {
  var xmlReq = new XMLHttpRequest();
  xmlReq.overrideMimeType("text/javascript");
  xmlReq.open("GET", ''+path,false);
  xmlReq.setRequestHeader("Cache-Control", "no-cache");
  xmlReq.send(null);
  
  return (xmlReq.responseText.length > 0);
}

function hasClassName(element, className) {
    var elementClassName = element.className;
    return (elementClassName.length > 0 && (elementClassName == className ||
      new RegExp("(^|\\s)" + className + "(\\s|$)").test(elementClassName)));
  }

function addClassName(element, className) {
    if (!hasClassName(element,className))
      element.className += (element.className ? ' ' : '') + className;
    return element;
  }

function removeClassName(element, className) {
    element.className = element.className.replace(
      new RegExp("(^|\\s+)" + className + "(\\s+|$)"), ' ').trim();
    return element;
  }

function toggleClassName(element, className) {
    if(hasClassName(element, className))
      return removeClassName(element,className);
    else
      return addClassName(element,className);
  }



  Date.prototype.format = function(format) {
		var returnStr = '';
		var replace = Date.replaceChars;
		for (var i = 0; i < format.length; i++) {
			var curChar = format.charAt(i);
			if (replace[curChar])
				returnStr += replace[curChar].call(this);
			else
				returnStr += curChar;
		}
		return returnStr;
	};
	
	Date.prototype.isDifferentDay = function(date2) {
		return (this.getDate() != date2.getDate() ||
			this.getMonth() != date2.getMonth() ||
			this.getFullYear() != date2.getFullYear());
	};
	
	Date.prototype.isToday = function()	{
		return !this.isDifferentDay(new Date());
	};

	Date.prototype.isTomorrow = function() {
		today = new Date ();
		return !this.isDifferentDay(new Date(today.getTime() + 24*3600*1000));
	};
	
	Date.prototype.isYesterday = function() {
    today = new Date ();
    return !this.isDifferentDay(new Date(today.getTime() - 24*3600*1000));
  };

	Date.prototype.isWithinDays = function(duration)
	{
		today = new Date ();
		temp = new Date ();
		temp.setTime(today.getTime() + duration*24*60*60*1000);
		enddate = new Date();
		enddate.setDate(temp.getDate());
		enddate.setMonth(temp.getMonth());
		enddate.setFullYear(temp.getFullYear());
		enddate.setHours(23);
		enddate.setMinutes(59);
		enddate.setSeconds(59);
		
		return enddate.getTime() > this.getTime();
	};
	
	Date.replaceChars = {
	  shortMonths: ["Jan","Feb","Mar","Apr","May_short","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
    longMonths: ["January","February","March","April","May","June","July","August","September","October","November","December"],
    shortDays: ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],
    longDays: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
		// Day
		d: function() { return (this.getDate() < 10 ? '0' : '') + this.getDate(); },
		D: function() { return $L(Date.replaceChars.shortDays[this.getDay()]); },
		j: function() { return this.getDate(); },
		l: function() { return $L(Date.replaceChars.longDays[this.getDay()]); },
		N: function() { return this.getDay() + 1; },
		S: function() { return (this.getDate() % 10 == 1 && this.getDate() != 11 ? 'st' : (this.getDate() % 10 == 2 && this.getDate() != 12 ? 'nd' : (this.getDate() % 10 == 3 && this.getDate() != 13 ? 'rd' : 'th'))); },
		w: function() { return this.getDay(); },
		z: function() { return "Not Yet Supported"; },
		// Week
		W: function() { return "Not Yet Supported"; },
		// Month
		F: function() { return $L(Date.replaceChars.longMonths[this.getMonth()]); },
		m: function() { return (this.getMonth() < 11 ? '0' : '') + (this.getMonth() + 1); },
		M: function() { return (this.getMonth() == 4)?$S('May_short'):$L(Date.replaceChars.shortMonths[this.getMonth()]); },
		n: function() { return this.getMonth() + 1; },
		t: function() { return "Not Yet Supported"; },
		// Year
		L: function() { return "Not Yet Supported"; },
		o: function() { return "Not Supported"; },
		Y: function() { return this.getFullYear(); },
		y: function() { return ('' + this.getFullYear()).substr(2); },
		// Time
		a: function() { return this.getHours() < 12 ? 'am' : 'pm'; },
		A: function() { return this.getHours() < 12 ? 'AM' : 'PM'; },
		B: function() { return "Not Yet Supported"; },
		g: function() { return this.getHours() == 0 ? 12 : (this.getHours() > 12 ? this.getHours() - 12 : this.getHours()); },
		G: function() { return this.getHours(); },
		h: function() { return (this.getHours() < 10 || (12 < this.getHours() < 22) ? '0' : '') + (this.getHours() < 10 ? this.getHours() + 1 : this.getHours() - 12); },
		H: function() { return (this.getHours() < 10 ? '0' : '') + this.getHours(); },
		i: function() { return (this.getMinutes() < 10 ? '0' : '') + this.getMinutes(); },
		s: function() { return (this.getSeconds() < 10 ? '0' : '') + this.getSeconds(); },
		// Timezone
		e: function() { return "Not Yet Supported"; },
		I: function() { return "Not Supported"; },
		O: function() { return (this.getTimezoneOffset() < 0 ? '-' : '+') + (this.getTimezoneOffset() / 60 < 10 ? '0' : '') + (this.getTimezoneOffset() / 60) + '00'; },
		T: function() { return "Not Yet Supported"; },
		Z: function() { return this.getTimezoneOffset() * 60; },
		// Full Date/Time
		c: function() { return "Not Yet Supported"; },
		r: function() { return this.toString(); },
		U: function() { return this.getTime() / 1000; }
	};
	
  Date.prototype.relative = function(raw) {
      
      var from = new Date().getTime()/1000;
      var length = parseInt(Math.abs(from-(this.getTime()/1000)));
      var cond = (from-(this.getTime()/1000) < 0)
      
      function subMin(nb) {
        if(parseInt((new String((nb-1)/10).split('.')[1] || '0').substring(0,1)) > 1 && parseInt((new String((nb-1)/10).split('.')[1] || '0').substring(0,1)) < 5)
          return 1;
        else if(parseInt((new String((nb-1)/10).split('.')[1] || '0').substring(0,1)) > 4 && parseInt((new String((nb-1)/10).split('.')[1] || '0').substring(0,1)) < 7)
          return -1;
        else
          return 0;
      }
      
      function subHours(nb, sens) {
        if(sens && parseInt((new String(nb).split('.')[1] || '0').substring(0,1)) > 7)
          return 1;
        else if(parseInt((new String(nb).split('.')[1] || '0').substring(0,1)) > 2)
          return 1;
        else
          return 0;
      }
      
      if(length < 60)
        var str = $L('Just now');
      else if(length < 3*60)
        var str = (cond)?$L('In few minutes'):$L('Few minutes ago');
      else if(length < 58*60)
        var str = new String((cond)?$S('inBefore')+' '+parseInt(Math.round(((length/60)-1)*60/60/10)*10+5*subMin(length/60))+' '+$L('minutes')+' '+$S('inAfter'):$S('agoBefore')+' '+parseInt(Math.round(((length/60)-1)*60/60/10)*10+5*subMin(length/60))+' '+$L('minutes')+' '+$S('agoAfter')).trim();
      else if(length < 4320)
        var str = new String((cond)?$S('inBefore')+' 1 '+$L('hour')+' '+$S('inAfter'):$S('agoBefore')+' 1 '+$L('hour')+' '+$S('agoAfter')).trim();
      else if(length < 85679)
        var str = new String((cond)?$S('inBefore')+' '+parseInt(Math.floor(length/3600)+subHours(length/3600,cond))+' '+$L('hours')+' '+$S('inAfter'):$S('agoBefore')+' '+parseInt(Math.floor(length/3600)+subHours(length/3600, cond))+' '+$L('hours')+' '+$S('agoAfter')).trim();
      else if(length < 24*3600)
        var str = new String((cond)?$S('inBefore')+' 23 '+$L('hours')+' '+$S('inAfter'):$S('agoBefore')+' 23 '+$L('hours')+' '+$S('agoAfter')).trim();
      
      if(str)
        return (raw)?str:'<span class="timeLength" time="'+this.getTime()+'">'+str+'</span>';
      
      var date = new Date();
      date.setHours(0);
      date.setMinutes(0);
      date.setSeconds(0);
      date.setSeconds(0);
      date.setMilliseconds(0);
      
      var date2 = new Date(this.getTime());
      date2.setHours(0);
      date2.setMinutes(0);
      date2.setSeconds(0);
      date2.setMilliseconds(0);
      
      from = date.getTime()/1000;
      length = Math.abs(from-(date2.getTime()/1000));
      
      if(length < 7*3600*24)
        var str = new String((cond)?$S('inBefore')+' '+Math.ceil(length/(3600*24))+' '+$L('days')+' '+$S('inAfter'):$S('agoBefore')+' '+Math.ceil(length/(3600*24))+' '+$L('days')+' '+$S('agoAfter')).trim();
      else if(length < 14*3600*24)
        var str = (cond)?$L('Next week'):$L('Last week');
      else if(length < 4*7*3600*24)
        var str = new String((cond)?$S('inBefore')+' '+Math.round(length/(7*3600*24))+' '+$L('weeks')+' '+$S('inAfter'):$S('agoBefore')+' '+Math.round(length/(7*3600*24))+' '+$L('weeks')+' '+$S('agoAfter')).trim();
      else if(length < 2*4*7*3600*24)
        var str = (cond)?$L('Next month'):$L('Last month');
      else if(length < 12*4*7*3600*24)
        var str = new String((cond)?$S('inBefore')+' '+Math.round(length/(4*7*3600*24))+' '+$L('months')+' '+$S('inAfter'):$S('agoBefore')+' '+Math.round(length/(4*7*3600*24))+' '+$L('months')+' '+$S('agoAfter')).trim();
      else if(length < 2*12*4*7*3600*24)
        var str = (cond)?$L('Next year'):$L('Last year');
      else
        var str = new String((cond)?$S('inBefore')+' '+Math.round(length/(365.25*3600*24))+' '+$L('years')+' '+$S('inAfter'):$S('agoBefore')+' '+Math.round(length/(365.25*3600*24))+' '+$L('years')+' '+$S('agoAfter')).trim();
      
      return (raw)?str:'<span class="timeLength" time="'+this.getTime()+'">'+str+'</span>';
    };
	
	String.prototype.truncate = function(length) {
    if(!length)
      length = 50;
    
    return String((this.length > length) ? this.substring(0, length-3)+"..." : this);
  };
  
  
  String.prototype.ucfirst = function() {
    // Makes a string's first character uppercase  
    // 
    // version: 903.3016
    // discuss at: http://phpjs.org/functions/ucfirst
    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Onno Marsman
    // +   improved by: Brett Zamir (http://brettz9.blogspot.com)
    // *     example 1: ucfirst('kevin van zonneveld');
    // *     returns 1: 'Kevin van zonneveld'
    str = this+'';
    var f = str.charAt(0).toUpperCase();
    return f + str.substr(1);
  };
  
  String.prototype.trim = function() {
    return this.replace(/^\s+/, '').replace(/\s+$/, '');
  }
  
  function extract_dir(filename) {
    filename = String(filename);
    return (filename.lastIndexOf('\\') !== -1)?filename.substr(0, filename.lastIndexOf('\\')):((filename.lastIndexOf('/') !== -1)?filename.substr(0, filename.lastIndexOf('/')):filename);
  }
  
  Object.extend = function(destination, source) {
    for (var property in source)
      destination[property] = source[property];
    
    return destination;
  };
  
  
  //From prototypejs.org
  HTMLElement.prototype.getDimensions = function(element) {
    element = this;
    var display = element.style.display;
    if (display != 'none' && display != null) // Safari bug
      return {width: element.offsetWidth, height: element.offsetHeight};

    // All *Width and *Height properties give 0 on elements with display none,
    // so enable the element temporarily
    var els = element.style;
    var originalVisibility = els.visibility;
    var originalPosition = els.position;
    var originalDisplay = els.display;
    els.visibility = 'hidden';
    els.position = 'absolute';
    els.display = 'block';
    var originalWidth = element.clientWidth;
    var originalHeight = element.clientHeight;
    els.display = originalDisplay;
    els.position = originalPosition;
    els.visibility = originalVisibility;
    return {width: originalWidth, height: originalHeight};
  };
  
  function is_float( mixed_var ) {
      // Returns true if variable is float point  
      // 
      // version: 812.1017
      // discuss at: http://phpjs.org/functions/is_float
      // +   original by: Paulo Ricardo F. Santos
      // %        note 1: 1.0 is simplified to 1 before it can be accessed by the function, this makes
      // %        note 1: it different from the PHP implementation. We can't fix this unfortunately.
      // *     example 1: is_float(186.31);
      // *     returns 1: true
      return parseFloat(mixed_var * 1) != parseInt(mixed_var * 1);
  }
  
  function in_array(needle, haystack, argStrict) {
    // Checks if the given value exists in the array  
    // 
    // version: 903.1614
    // discuss at: http://phpjs.org/functions/in_array
    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // *     example 1: in_array('van', ['Kevin', 'van', 'Zonneveld']);
    // *     returns 1: true
    var found = false, key, strict = !!argStrict;

    for (key in haystack) {
        if ((strict && haystack[key] === needle) || (!strict && haystack[key] == needle)) {
            found = true;
            break;
        }
    }

    return found;
  }



if (!this.JSON) {
    JSON = {};
}
(function () {

    function f(n) {
        // Format integers to have at least two digits.
        return n < 10 ? '0' + n : n;
    }

    if (typeof Date.prototype.toJSON !== 'function') {

        Date.prototype.toJSON = function (key) {

            return this.getUTCFullYear()   + '-' +
                 f(this.getUTCMonth() + 1) + '-' +
                 f(this.getUTCDate())      + 'T' +
                 f(this.getUTCHours())     + ':' +
                 f(this.getUTCMinutes())   + ':' +
                 f(this.getUTCSeconds())   + 'Z';
        };

        String.prototype.toJSON =
        Number.prototype.toJSON =
        Boolean.prototype.toJSON = function (key) {
            return this.valueOf();
        };
    }

    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        gap,
        indent,
        meta = {    // table of character substitutions
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"' : '\\"',
            '\\': '\\\\'
        },
        rep;


    function quote(string) {

// If the string contains no control characters, no quote characters, and no
// backslash characters, then we can safely slap some quotes around it.
// Otherwise we must also replace the offending characters with safe escape
// sequences.

        escapable.lastIndex = 0;
        return escapable.test(string) ?
            '"' + string.replace(escapable, function (a) {
                var c = meta[a];
                return typeof c === 'string' ? c :
                    '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
            }) + '"' :
            '"' + string + '"';
    }


    function str(key, holder) {

// Produce a string from holder[key].

        var i,          // The loop counter.
            k,          // The member key.
            v,          // The member value.
            length,
            mind = gap,
            partial,
            value = holder[key];

// If the value has a toJSON method, call it to obtain a replacement value.

        if (value && typeof value === 'object' &&
                typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }

// If we were called with a replacer function, then call the replacer to
// obtain a replacement value.

        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }

// What happens next depends on the value's type.

        switch (typeof value) {
        case 'string':
            return quote(value);

        case 'number':

// JSON numbers must be finite. Encode non-finite numbers as null.

            return isFinite(value) ? String(value) : 'null';

        case 'boolean':
        case 'null':

// If the value is a boolean or null, convert it to a string. Note:
// typeof null does not produce 'null'. The case is included here in
// the remote chance that this gets fixed someday.

            return String(value);

// If the type is 'object', we might be dealing with an object or an array or
// null.

        case 'object':

// Due to a specification blunder in ECMAScript, typeof null is 'object',
// so watch out for that case.

            if (!value) {
                return 'null';
            }

// Make an array to hold the partial results of stringifying this object value.

            gap += indent;
            partial = [];

// Is the value an array?

            if (Object.prototype.toString.apply(value) === '[object Array]') {

// The value is an array. Stringify every element. Use null as a placeholder
// for non-JSON values.

                length = value.length;
                for (i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || 'null';
                }

// Join all of the elements together, separated with commas, and wrap them in
// brackets.

                v = partial.length === 0 ? '[]' :
                    gap ? '[\n' + gap +
                            partial.join(',\n' + gap) + '\n' +
                                mind + ']' :
                          '[' + partial.join(',') + ']';
                gap = mind;
                return v;
            }

// If the replacer is an array, use it to select the members to be stringified.

            if (rep && typeof rep === 'object') {
                length = rep.length;
                for (i = 0; i < length; i += 1) {
                    k = rep[i];
                    if (typeof k === 'string') {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            } else {

// Otherwise, iterate through all of the keys in the object.

                for (k in value) {
                    if (Object.hasOwnProperty.call(value, k)) {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            }

// Join all of the member texts together, separated with commas,
// and wrap them in braces.

            v = partial.length === 0 ? '{}' :
                gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' +
                        mind + '}' : '{' + partial.join(',') + '}';
            gap = mind;
            return v;
        }
    }

// If the JSON object does not yet have a stringify method, give it one.

    if (typeof JSON.stringify !== 'function') {
        JSON.stringify = function (value, replacer, space) {

// The stringify method takes a value and an optional replacer, and an optional
// space parameter, and returns a JSON text. The replacer can be a function
// that can replace values, or an array of strings that will select the keys.
// A default replacer method can be provided. Use of the space parameter can
// produce text that is more easily readable.

            var i;
            gap = '';
            indent = '';

// If the space parameter is a number, make an indent string containing that
// many spaces.

            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) {
                    indent += ' ';
                }

// If the space parameter is a string, it will be used as the indent string.

            } else if (typeof space === 'string') {
                indent = space;
            }

// If there is a replacer, it must be a function or an array.
// Otherwise, throw an error.

            rep = replacer;
            if (replacer && typeof replacer !== 'function' &&
                    (typeof replacer !== 'object' ||
                     typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }

// Make a fake root object containing our value under the key of ''.
// Return the result of stringifying the value.

            return str('', {'': value});
        };
    }


// If the JSON object does not yet have a parse method, give it one.

    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text, reviver) {

// The parse method takes a text and an optional reviver function, and returns
// a JavaScript value if the text is a valid JSON text.

            var j;

            function walk(holder, key) {

// The walk method is used to recursively walk the resulting structure so
// that modifications can be made.

                var k, v, value = holder[key];
                if (value && typeof value === 'object') {
                    for (k in value) {
                        if (Object.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver.call(holder, key, value);
            }


// Parsing happens in four stages. In the first stage, we replace certain
// Unicode characters with escape sequences. JavaScript handles many characters
// incorrectly, either silently deleting them, or treating them as line endings.

            cx.lastIndex = 0;
            if (cx.test(text)) {
                text = text.replace(cx, function (a) {
                    return '\\u' +
                        ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }

// In the second stage, we run the text against regular expressions that look
// for non-JSON patterns. We are especially concerned with '()' and 'new'
// because they can cause invocation, and '=' because it can cause mutation.
// But just to be safe, we want to reject all unexpected forms.

// We split the second stage into 4 regexp operations in order to work around
// crippling inefficiencies in IE's and Safari's regexp engines. First we
// replace the JSON backslash pairs with '@' (a non-JSON character). Second, we
// replace all simple value tokens with ']' characters. Third, we delete all
// open brackets that follow a colon or comma or that begin the text. Finally,
// we look to see that the remaining characters are only whitespace or ']' or
// ',' or ':' or '{' or '}'. If that is so, then the text is safe for eval.

            if (/^[\],:{}\s]*$/.
test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@').
replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

// In the third stage we use the eval function to compile the text into a
// JavaScript structure. The '{' operator is subject to a syntactic ambiguity
// in JavaScript: it can begin a block or an object literal. We wrap the text
// in parens to eliminate the ambiguity.

                j = eval('(' + text + ')');

// In the optional fourth stage, we recursively walk the new structure, passing
// each name/value pair to a reviver function for possible transformation.

                return typeof reviver === 'function' ?
                    walk({'': j}, '') : j;
            }

// If the text is not JSON parseable, then a SyntaxError is thrown.

            throw new SyntaxError('JSON.parse');
        };
    }
})();











// Set everything up
//Controller.loadSettings();


document.addEventListener("dom:loaded", function(){}, false);

function fireContentLoadedEvent() {
  if(document.loaded) return;
  if(Controller.pluginsLoaded != Settings.plugins.length) return ;
  if (timer) window.clearInterval(timer);
  var fireOnThis = document;
  var evObj = document.createEvent('HTMLEvents');
  evObj.initEvent( "dom:loaded", true, true);
  evObj.eventName = "dom:loaded";
  document.loaded = true;
  
  fireOnThis.dispatchEvent(evObj);
}

timer = window.setInterval(function() {
        if (/complete/.test(document.readyState))
          fireContentLoadedEvent();
      }, 0);


window.addEventListener("load", fireContentLoadedEvent, false);

function log(text) {
  /*$('log').appendChild(document.createElement('br'));
  $('log').appendChild(document.createTextNode(text));*/
  console.log(text);
}
