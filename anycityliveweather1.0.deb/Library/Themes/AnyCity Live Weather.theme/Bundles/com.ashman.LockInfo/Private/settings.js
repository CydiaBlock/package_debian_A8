
var Settings = {
  version: '1.2',
  
  // However language will be selected automatically however you can force one of these languages
  // {'zh','nl','en','fr','de','it','pt','es','cz'}
  // Set to "default" to let the theme select language automatically
  language: 'default',
  
  // The list of Plugins that must be loaded
  // They will loaded/displayed on this order
  
  plugins: [],
  
  // The list of Bundles that must be used (located in Private/bundles folder)
  // Be careful using bundles as it could overwrite your settings
  // As in winterboard, first in list has priority on the next as it could overwrite the same settings/css
  bundles: [],
  
  // Standalone bundles must be activated in Winterboard. If you want to manually activate one
  // without using its Winterboard feature add it to the list else ignore what's next
  // 
  // The list of "Standalone" Bundles that must be loaded
  // These Bundles use Winterboard functionalities so they're not in the Private/bundles folder
  // Be careful using bundles as it could overwrite your settings
  // As in winterboard, first in list has priority on the next as it could overwrite the same settings/css
  // These bundles has priority on simple bundles located in Private/bundles folder
  // Enter names of bundles you want to activate without the ".libundle"
  sBundles: [],
  
  // Enable/Disable Expansion
  // You can specify which plugins you want be able to fold / expand their bars in their settings.js
  allowExpand: true,
  
  hideExpandDots: false,
  
  useRelative: true,
  
  nbBefore: false,
  
  marginBottom: 96,
};
