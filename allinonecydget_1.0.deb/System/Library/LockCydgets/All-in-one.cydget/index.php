<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<table><tr><td>
<a href="browser.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/safari.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Browser</font></font></CENTER>

<br>

<a href="twitter.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/twitter.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Twitter</font></font></CENTER>

<br>

<a href="bbc.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/bbc.jpg" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">BBC News</font></font></CENTER>

<br>

<a href="amazon.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/amazon.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Amazon</font></font></CENTER>
</td>


<td width="5px"></td>


<td>
<a href="maps.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/map.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Maps</font></font></CENTER>

<br>

<a href="facebook.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/facebook.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Facebook</font></font></CENTER>

<br>

<a href="cnn.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/cnn.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">CNN</font></font></CENTER>

<br>

<a href="macusercom.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/macusercom.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Macusercom</font></font></CENTER>
</td>

<td width="5px"></td>


<td>
<a href="weather.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/weather.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Weather</font></font></CENTER>

<br>

<a href="myspace.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/myspace.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">MySpace</font></font></CENTER>

<br>

<a href="ntv.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/ntv.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">N-TV</font></font></CENTER>

<br>

<a href="apfelzone.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/apfelzone.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Apfel Zone</font></font></CENTER>
</td>


<td width="5px"></td>


<td>
<a href="yahoo.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/yahoo.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Yahoo Search</font></font></CENTER>

<br>

<a href="youtube.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/youtube.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">YouTube</font></font></CENTER>

<br>

<a href="wikipedia.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/wikipedia.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">Wikipedia</font></font></CENTER>

<br>

<a href="settings.php">
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/settings.png" /></a>
<CENTER><div style="height:0px"></div><font color="white"><font size="1">About</font></font></CENTER>
</td></tr></table>
<font color="white">&copy;2009-2010 by <a href="http://www.macusercom.com/"><font color="white">Macusercom</font></a></font>
</CENTER>
</body>
</html>
