<html>
<head>
<meta name="viewport" content="width=320" scrollable="yes">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>
<br>
<CENTER>
<script language="JavaScript">
function gotourl()
{
window.location.href = document.Testform.url.value;
return false;
}
</script>
<small><small>
Respring if you have bugs
<br>NOTE:SpringBoard can crash sometimes!
<br>Respring it and everaything works again!
</small></small>
<form name="Testform" onSubmit="return gotourl()">
URL:
<input size=25% name="url" value="http://">
<input type=submit value="Go">
</form>
<img src="file:///System/Library/LockCydgets/All-in-one.cydget/images/tap.jpg" width="310" />
</CENTER>
</body>
</html>

