<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>
</CENTER>
<iframe width="320" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.ch/maps?hl=de&amp;ie=UTF8&amp;ll=46.362093,9.036255&amp;spn=4.510883,9.876709&amp;t=h&amp;z=7&amp;output=embed"></iframe>  
</body>
</html>

