<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>
</CENTER>
<iframe width="320" height="480" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0" src="http://www.bbc.co.uk/mobile/i/"></iframe> 
</body>
</html>

