<html>
<head>
<meta name="viewport" content="width=320" scrollable="no">
<meta name="apple-mobile-web-app-capable" content="yes" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>
<CENTER>
<a href="index.php"><font color="black"><font size="6">Home</font></font></a>
<br>
<br>All in one Version 1.0
<br>"All in one" is built by Macusercom
<br>(<a href="http://www.macusercom.com/">http://www.macusercom.com/</a>)
<br><br><small>Please Note: Amazon size is normal, Browser can crash, if you tap the keyboard the letters won't grown and Wikipedia can have issues. This is not my fault. It's a problem by cydget, not me!</small>
<br><br>If you have other problems, bugs or ideas tell it: <a href="mailto:support@macusercom.com?subject="All in one V1.0 Support">support@macusercom.com</a>
<br>
<br>
&copy;2009-2010 by Macusercom

</CENTER>
</body>
</html>

