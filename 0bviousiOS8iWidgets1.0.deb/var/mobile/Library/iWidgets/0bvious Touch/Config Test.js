/*
Configuration here!
Done by Dacal - Modified by Schnedi // DO NOT remove this line  //
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/

var Clock = "24h";		      // choose between "12h" or "24h".
var lang = "sp";	              // choose between "sp", "fr", "en", "de" or "it".

var gps = false; 	          // Requires WidgetWeather2.
var locale = 766537;	          // Yahoo Weather (useit if GPS does not work).
var tempUnit = "c";	          // choose between "c" or "f"
var WeatherSet = "0bvious";	  // choose between "0bvious" or "Astral"
var updateInterval = 60;       // in minutes.

var UseCityGPS = false;         // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false;    // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).


var ChangeClick = true;    // Do Not Modify.


var Slideshow = "Yes";	      // choose between "Yes" or "No"