The images that go in here are the ones that are shown in the toggles page. 

It absolutely essential to copy the Info.plist file from this folder into your custom toggles folder.