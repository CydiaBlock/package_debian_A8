When creating your own themes, it's simply a matter of creating new versions of the .png's in here, and dropping them into your theme. If an image isn't themed, then it will default to one in this folder. 

With the folders, the images in there can also be themed. Just create the relevant folder in your theme, and drop the new images into it.

The Info.plist file contains three fields - thumbnailImage, author and name. thumbnailImage is the image that will be shown in Settings as the theme's icon; here, I'm defining Icon@2x.png and Icon.png (for non-retina) to be that icon. Author is pretty self-explanatory, and name is the theme's name - you'll want this to be the same as the name of your theme's main folder.

For changing the current theme, simply go to Settings > Convergance > Themes